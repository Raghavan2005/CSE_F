# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Common Commands

```bash
# Install dependencies
flutter pub get

# Run the app
flutter run

# Code generation (Freezed models, JSON serialization) — run after adding/modifying annotated classes
flutter pub run build_runner build --delete-conflicting-outputs

# Watch mode during development
flutter pub run build_runner watch --delete-conflicting-outputs

# Static analysis
flutter analyze

# Run tests
flutter test

# Run a single test file
flutter test test/widget_test.dart
```

## Architecture

The app follows **clean architecture** organized into feature modules under `lib/`:

```
lib/
├── core/               # Cross-cutting concerns (services, router, theme, utils, widgets)
├── data/               # Shared data layer (models, network, repositories)
├── features/           # Feature modules, each with:
│   └── <feature>/
│       ├── data/       # Repository implementations, data sources
│       ├── domain/     # Entities (plain Dart classes, no framework deps)
│       └── presentation/ # Screens, Riverpod providers, widgets
└── main.dart
```

**State management:** Riverpod (`flutter_riverpod` + `hooks_riverpod`). Mutable state uses `StateNotifierProvider`. UI components use `ConsumerWidget` or `HookConsumerWidget`.

**Routing:** GoRouter configured in `lib/core/router/app_router.dart`. Navigation flow: Splash → Onboarding → Auth → Home. Protected routes redirect based on `AuthStatus` from `authProvider`.

**HTTP:** Dio client in `lib/core/services/api_service.dart`. Base URL is read from `.env` (`USER_SERVICE_URL`). Handles JWT auth with automatic token refresh on 401 and a global unauthorized callback for forced logout.

**Local storage:** `lib/core/services/storage_service.dart` wraps SharedPreferences for tokens, user profile, wishlist, bookings, theme, and onboarding state.

**Auth states:** `authenticated`, `unauthenticated`, `onboarding`, `blocked`, `inactive` — managed by `authProvider` in `lib/features/auth/presentation/providers/auth_provider.dart`.

## Code Generation

Models using `@JsonSerializable` or `@freezed` require generated files (`*.g.dart`, `*.freezed.dart`). After modifying these annotated classes, run `build_runner build`. Generated files are committed to the repo.

## Environment

The `.env` file is included as a Flutter asset and loaded at startup. The default API endpoint is `http://10.0.2.2:8000/` (Android emulator localhost). Copy `.env` and set `USER_SERVICE_URL` to point to your backend.

## Backend Services

The app talks to a Django microservices backend (`../planymo-backend`). The `.env` variable `USER_SERVICE_URL` points to the user-service (default `http://10.0.2.2:8000/` for Android emulator).

| Service | Default Port | Responsibility |
|---------|-------------|----------------|
| user-service | 8000 | Auth, JWT, OTP — primary endpoint for the app |
| vendor-service | 8001 | Vendor management |
| package-service | 8002 | Travel packages & itineraries |
| ratings-service | 8003 | Reviews & ratings |
| support-service | 8004 | Support tickets |

JWT access tokens are issued by user-service and sent as `Authorization: Bearer <token>` on every request. The Dio client in `api_service.dart` handles automatic token refresh on 401.

## Design System

- **Primary color:** Blue `#037DBB`
- **CTA color:** Orange `#EF7D0F`
- **Dark background:** `#151517`
- **Font:** Poppins (via `google_fonts`)
- Colors are centralized in `lib/core/themes/app_colors.dart`; theme configs in `lib/core/themes/app_theme.dart` (Material 3, light + dark).
