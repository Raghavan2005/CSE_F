# PLANYMO — TRAVEL PACKAGE MARKETPLACE
## Project Report

---

**Project Title:** Planymo — Travel Package Marketplace (Mobile Application)
**Platform:** Flutter (Android & iOS)
**Academic Year:** 2025–2026

---

## ABSTRACT

Planymo is a full-stack travel-package marketplace that bridges the gap between travellers seeking curated experiences and travel agencies (vendors) offering packaged tours. The platform consists of a Flutter-based cross-platform mobile application for end users, a Next.js web dashboard for vendors and administrators, and a Django-based microservices backend. Users can discover destinations, browse travel packages listed by verified vendors, review itineraries, make secure bookings with payment integration, rate completed trips, and raise support tickets — all within a single, cohesive mobile experience.

The system addresses key pain points in the existing travel-booking landscape: fragmented discovery, opaque pricing, lack of verified reviews, and poor post-booking support. Planymo consolidates these touchpoints into one platform with a clean, dark-themed Material 3 UI built around trust, simplicity, and speed. The backend employs a microservices architecture with JWT-based authentication, distributed booking locks (Redis), and event-driven communication (Kafka + Outbox Pattern) for ratings and support pipelines. The mobile application is built following Clean Architecture principles with Riverpod state management and GoRouter navigation, ensuring maintainability and testability at scale.

---

## TABLE OF CONTENTS

1. Abstract
2. Table of Contents
3. Introduction
4. Scope of the Work
5. Aim and Objectives of the Project
6. Literature Survey
7. System Design
8. Architecture Diagram
9. Use Case Diagram
10. Hardware Specifications
11. Software Specifications
12. Proposed System
13. Module Description
14. Key Benefits of the Proposed System
15. Output
16. Conclusion and Future Enhancements
17. References

---

## 1. INTRODUCTION

Travel and tourism is one of the world's largest and fastest-growing industries, contributing over 9.5% to global GDP. Despite widespread internet access, the process of discovering and booking packaged tours remains fragmented — travellers must visit multiple agency websites, negotiate over phone calls, and rely on word-of-mouth recommendations with no standardised review mechanism. Small and mid-size travel agencies lack the digital infrastructure to market their packages to a broad audience and manage bookings efficiently.

Planymo is designed to solve this structural problem through a two-sided marketplace model. On one side, travel agencies (vendors) can onboard the platform, create and publish travel packages with detailed itineraries, set pricing, and manage incoming bookings via a dedicated web dashboard. On the other side, users can discover packages from across agencies, filter by destination or category, view verified reviews, and complete the full booking lifecycle — from selection to payment to post-trip review — entirely within the Planymo mobile application.

The mobile app is developed using Flutter, enabling a single codebase to target both Android and iOS. The backend is implemented as a suite of independently deployable Django microservices, each owning its own PostgreSQL database. The system is designed for horizontal scalability, with event-driven messaging for asynchronous workflows and distributed locking for concurrency-safe bookings.

This report documents the design, architecture, implementation, and outcomes of the Planymo mobile application, covering all system components and the rationale behind key technical decisions.

---

## 2. SCOPE OF THE WORK

The scope of this project encompasses the end-to-end design and development of the Planymo travel marketplace ecosystem, with primary focus on the Flutter mobile application and its integration with the backend microservices.

**In Scope:**
- Flutter mobile application (Android & iOS) for end users
- User authentication system (JWT, OTP, password reset)
- Travel package discovery with search, categories, and banners
- Vendor browsing (agencies and their packages)
- Complete booking lifecycle with seat/room availability management
- Payment integration within the booking flow
- Ratings and review system for completed trips
- Customer support ticket management (create, view, reply)
- User profile management (edit profile, change password, settings)
- Wishlist functionality for saving preferred packages
- Django microservices backend (6 services)
- Next.js vendor/admin web dashboard
- CI/CD pipeline configuration

**Out of Scope:**
- Native iOS/Android platform-specific payment SDKs (handled via booking service abstraction)
- Multi-language localisation (planned for future)
- Offline mode (app requires internet connectivity)
- In-app chat between users and vendors (planned for future)
- Vendor mobile application

---

## 3. AIM AND OBJECTIVES OF THE PROJECT

### Aim
To develop a scalable, cross-platform travel marketplace mobile application that enables users to seamlessly discover, evaluate, and book curated travel packages from verified vendors, while providing vendors with a management interface and the platform with operational oversight tools.

### Objectives

1. **Design and implement** a Flutter mobile application following Clean Architecture principles with clear separation of data, domain, and presentation layers across all feature modules.

2. **Build a secure authentication system** using JWT access/refresh tokens, OTP-based phone verification, and stateful session tracking with automatic token renewal.

3. **Develop a package discovery engine** that presents travel packages via curated banners, popular destinations, trending sections, category filters, and a full-text search interface.

4. **Implement a concurrent-safe booking system** with Redis-based distributed locking to prevent double-booking, integrated with a payment flow.

5. **Establish a review and rating system** with an event-driven pipeline (Kafka + Outbox Pattern) to asynchronously publish review events without coupling the ratings service to the user-facing booking flow.

6. **Create a support ticketing system** allowing users to raise issues, view thread history, and receive replies, backed by an event-driven support microservice.

7. **Deliver a vendor browsing experience** allowing users to explore agencies, view their profiles and full package catalogues, and navigate to individual package details.

8. **Ensure maintainability and scalability** through microservices isolation (each service owns its database), Riverpod-based state management, and GoRouter-based declarative navigation.

9. **Deploy a CI/CD pipeline** to automate build verification and deployment on push to the main branch.

---

## 4. LITERATURE SURVEY

### 4.1 Mobile Application Development Frameworks

**Flutter (Google, 2018):** Flutter is an open-source UI toolkit by Google for building natively compiled cross-platform applications from a single codebase. It uses the Dart programming language and renders widgets directly to a canvas via its own Skia/Impeller engine, bypassing native UI components. Studies by Nawrocki et al. (2021) show Flutter achieves near-native rendering performance with significantly lower development time compared to maintaining separate native codebases. Flutter 3.x supports Android, iOS, Web, Windows, macOS, and Linux.

**React Native vs Flutter:** React Native (Meta) uses a JavaScript bridge to communicate with native components, introducing latency. Flutter's compiled Dart code and custom renderer eliminate this bridge, yielding smoother animations and more consistent behaviour across platforms — a key consideration for a marketplace app with complex list views and animations.

### 4.2 State Management in Flutter

**Riverpod (Remi Rousselet, 2021):** Riverpod is a compile-safe, testable state management library for Flutter. Unlike its predecessor Provider, Riverpod has no `BuildContext` dependency, supports multiple providers of the same type, and enables granular reactivity. Research by Flutter community contributors demonstrates Riverpod's superiority over BLoC for medium-complexity apps due to reduced boilerplate. Planymo uses `StateNotifierProvider` for mutable state and `FutureProvider` for async data fetching.

**MobX, BLoC, GetX** — alternative state management solutions reviewed but not chosen due to either excessive boilerplate (BLoC) or opaque magic that hinders testability (GetX).

### 4.3 Clean Architecture in Mobile Apps

Robert C. Martin's Clean Architecture (2012) defines concentric dependency layers: Entities → Use Cases → Interface Adapters → Frameworks. Applied to Flutter, this means: Domain (plain Dart entities, no framework imports) → Data (Dio-based datasources, repository implementations) → Presentation (Riverpod providers, screens). This separation enables unit testing of domain logic without a running Flutter engine and swapping data sources without touching UI code.

### 4.4 Microservices Architecture

Microservices architecture (Newman, 2015) decomposes a monolithic application into small, independently deployable services, each owning its data store. Planymo's backend follows this model with six services across six PostgreSQL databases. The key trade-off is operational complexity (more services to run, monitor, and deploy) vs. independent scalability and fault isolation. The ratings-service and support-service use the Outbox Pattern (Kleppmann, 2017) to guarantee at-least-once delivery of domain events to Kafka without distributed transactions.

### 4.5 JWT Authentication

JSON Web Tokens (RFC 7519) are a compact, URL-safe means of representing claims between parties. Planymo's user-service issues short-lived access tokens (stateless) and stateful refresh tokens tracked by user-agent and IP. On 401, the Dio interceptor transparently refreshes the token and replays the failed request — a pattern documented by Auth0 as "silent refresh" for SPAs and mobile apps.

### 4.6 Existing Travel Marketplace Systems

| Platform | Model | Gap Addressed by Planymo |
|----------|-------|--------------------------|
| MakeMyTrip | OTA (flight + hotel) | No curated package marketplace; no vendor-facing tools |
| TripAdvisor | Review aggregator | No booking capability; no vendor onboarding |
| Airbnb Experiences | Activity booking | Limited to experiences, not multi-day packages |
| Viator (TripAdvisor) | Tour aggregator | Web-first; no dedicated vendor dashboard |

Planymo differentiates by combining discovery, booking, reviews, and support in one mobile-native experience with a paired vendor management dashboard.

---

## 5. SYSTEM DESIGN

### 5.1 Overall System Architecture

Planymo is a **three-tier distributed system**:

**Tier 1 — Client Layer**
- Flutter mobile app (users): Android & iOS
- Next.js web app (vendors/admins): `planymo-admin-web`
- Next.js internal dashboard (support team): `support-dash-planymo`
- Static marketing website (Firebase Hosting)

**Tier 2 — Application Layer (Django Microservices)**
- user-service (Port 8000): Authentication, JWT, OTP, user profiles
- vendor-service (Port 8001): Vendor onboarding, lifecycle management
- package-service (Port 8002): Travel packages, itineraries, media (calls vendor-service via HTTP)
- ratings-service (Port 8003): Reviews & ratings, Kafka producer
- support-service (Port 8004): Support tickets, Kafka producer
- booking_service (standalone): Bookings, payments, Redis locking

**Tier 3 — Data Layer**
- PostgreSQL (one database per service, separate ports 5433–5437)
- Redis (distributed locking for booking_service)
- Apache Kafka (async event bus for ratings + support)

### 5.2 Authentication Flow

```
User opens app
  → SplashScreen checks stored JWT
  → If valid: Home
  → If expired: Token Interceptor calls /auth/refresh
    → If refresh succeeds: replay request → Home
    → If refresh fails: forceLogout → Auth screen
  → If no token: Onboarding (first time) or Auth screen
```

### 5.3 Booking Flow

```
User selects package
  → TripDetailsScreen → "Book Now"
  → BookingDetail: select dates, travellers, room type
  → Confirm → booking_service API
    → Redis lock acquired (prevents double booking)
    → Availability checked → Booking record created
    → Payment initiated
    → On payment success: booking status = CONFIRMED
    → Redis lock released
  → BookingSuccessScreen
```

### 5.4 Review Flow (Event-Driven)

```
User on Bookings tab
  → COMPLETED booking → "Write Review"
  → WriteReviewSheet: star rating + comment
  → Submit → ratings-service API
    → Review saved to DB
    → Outbox record written (same transaction)
    → Background publisher reads Outbox → publishes to Kafka topic "reviews"
    → Kafka consumers process downstream (notifications, analytics)
```

### 5.5 Data Flow Between Services

- The mobile app authenticates via **user-service** (port 8000) — the only service the app directly authenticates against.
- Gateway injects headers `x-user-id`, `x-user-role`, `x-vendor-id` for all other service calls.
- **package-service** calls **vendor-service** via HTTP using a `SERVICE_TOKEN` (Bearer token) to enrich package responses with vendor details.
- Cross-service calls never share databases — only UUIDs are passed as foreign references.

### 5.6 Database Design (Key Entities)

**user-service:** `User` (id, phone, email, name, role, status), `RefreshToken` (token, user, ip, user_agent, expires)

**vendor-service:** `Vendor` (id, name, description, logo, status, owner_user_id), `VendorDocument`

**package-service:** `Package` (id, vendor_id, title, description, price, duration, capacity, status), `Itinerary` (day-wise), `PackageMedia` (images)

**booking_service:** `Booking` (id, user_id, package_id, status, travellers, total_price), `Payment` (id, booking_id, gateway_ref, status)

**ratings-service:** `Review` (id, user_id, package_id, booking_id, rating, comment), `Outbox` (event_type, payload, published)

**support-service:** `Ticket` (id, user_id, subject, status), `Message` (ticket_id, sender_id, content), `Outbox`

---

## 6. ARCHITECTURE DIAGRAM

```
┌─────────────────────────────────────────────────────────────────────┐
│                        CLIENT LAYER                                  │
│                                                                       │
│  ┌────────────────────┐   ┌──────────────────┐   ┌───────────────┐  │
│  │   Flutter App      │   │  planymo-admin-  │   │ support-dash  │  │
│  │  (Users, Mobile)   │   │  web (Next.js16) │   │ (Next.js 15)  │  │
│  └────────┬───────────┘   └────────┬─────────┘   └───────┬───────┘  │
└───────────┼────────────────────────┼─────────────────────┼──────────┘
            │ HTTPS/REST + JWT        │ HTTPS + HttpOnly    │
            │                         │ Cookies             │
┌───────────▼─────────────────────────▼─────────────────────▼──────────┐
│                        APPLICATION LAYER                               │
│                                                                         │
│  ┌─────────────┐  ┌─────────────┐  ┌──────────────┐  ┌────────────┐  │
│  │user-service │  │vendor-svc   │  │package-svc   │  │booking_svc │  │
│  │  :8000      │  │  :8001      │  │  :8002       │  │ standalone │  │
│  │ JWT, OTP    │  │Vendor CRUD  │  │Packages, CMS │  │Redis lock  │  │
│  └──────┬──────┘  └──────┬──────┘  └──────┬───────┘  └─────┬──────┘  │
│         │                │                 │ HTTP→:8001      │         │
│  ┌──────▼──────┐  ┌──────▼──────┐          │                 │         │
│  │ratings-svc  │  │support-svc  │          │                 │         │
│  │  :8003      │  │  :8004      │          │                 │         │
│  │Kafka+Outbox │  │Kafka+Outbox │          │                 │         │
│  └──────┬──────┘  └──────┬──────┘          │                 │         │
└─────────┼───────────────┼─────────────────┼─────────────────┼─────────┘
          │               │                  │                 │
┌─────────▼───────────────▼──────────────────▼─────────────────▼──────┐
│                          DATA LAYER                                   │
│                                                                        │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌───────────┐  │
│  │PostgreSQL│ │PostgreSQL│ │PostgreSQL│ │PostgreSQL│ │  Redis    │  │
│  │:5433     │ │:5434     │ │:5436     │ │:5437     │ │(booking)  │  │
│  │user_svc  │ │vendor_svc│ │ratingsdb │ │supportdb │ └───────────┘  │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘                │
│                                                                        │
│  ┌────────────────────────────────────────────┐                       │
│  │              Apache Kafka                  │                       │
│  │  Topics: "reviews" | "support-tickets"     │                       │
│  └────────────────────────────────────────────┘                       │
└───────────────────────────────────────────────────────────────────────┘
```

### Flutter App Internal Architecture

```
main.dart
  └── ProviderScope (Riverpod)
        └── MaterialApp (GoRouter)
              ├── /splash          → SplashScreen
              ├── /onboarding      → OnboardingScreen
              ├── /auth/*          → Login, Signup, OTP, ForgotPassword
              └── /home (guarded)
                    ├── Discovery Tab  → HomeScreen, TripDetails, BookingSuccess
                    ├── Search Tab     → SearchScreen
                    ├── Vendors Tab    → VendorsScreen, VendorDetail
                    ├── Wishlist Tab   → WishlistTab
                    ├── Bookings Tab   → BookingsTab, BookingDetail
                    ├── Profile Tab    → ProfileScreen, EditProfile
                    └── Support        → SupportTickets, TicketDetail
```

---

## 7. USE CASE DIAGRAM

```
                        ┌────────────────────────────────────────────────────┐
                        │                  PLANYMO SYSTEM                    │
                        │                                                     │
  ┌─────────┐           │  ┌─────────────────────────────────────────────┐   │
  │         │──────────►│  │ Register / Login / OTP Verification         │   │
  │         │           │  └─────────────────────────────────────────────┘   │
  │         │──────────►│  ┌─────────────────────────────────────────────┐   │
  │         │           │  │ Discover Travel Packages (Home Feed)         │   │
  │         │           │  └─────────────────────────────────────────────┘   │
  │         │──────────►│  ┌─────────────────────────────────────────────┐   │
  │         │           │  │ Search Packages / Destinations               │   │
  │         │           │  └─────────────────────────────────────────────┘   │
  │  USER   │──────────►│  ┌─────────────────────────────────────────────┐   │
  │ (Mobile │           │  │ View Trip Details & Itinerary                │   │
  │   App)  │           │  └─────────────────────────────────────────────┘   │
  │         │──────────►│  ┌─────────────────────────────────────────────┐   │
  │         │           │  │ Wishlist Package                             │   │
  │         │           │  └─────────────────────────────────────────────┘   │
  │         │──────────►│  ┌─────────────────────────────────────────────┐   │
  │         │           │  │ Book Package (Dates, Travellers, Payment)    │   │
  │         │           │  └─────────────────────────────────────────────┘   │
  │         │──────────►│  ┌─────────────────────────────────────────────┐   │
  │         │           │  │ View Booking History & Details               │   │
  │         │           │  └─────────────────────────────────────────────┘   │
  │         │──────────►│  ┌─────────────────────────────────────────────┐   │
  │         │           │  │ Write Review (Completed Bookings Only)       │   │
  │         │           │  └─────────────────────────────────────────────┘   │
  │         │──────────►│  ┌─────────────────────────────────────────────┐   │
  │         │           │  │ Browse Vendors / View Agency Profile         │   │
  │         │           │  └─────────────────────────────────────────────┘   │
  │         │──────────►│  ┌─────────────────────────────────────────────┐   │
  │         │           │  │ Raise / View / Reply Support Ticket          │   │
  │         │           │  └─────────────────────────────────────────────┘   │
  │         │──────────►│  ┌─────────────────────────────────────────────┐   │
  └─────────┘           │  │ Edit Profile / Change Password / Settings    │   │
                        │  └─────────────────────────────────────────────┘   │
                        │                                                     │
  ┌──────────┐          │  ┌─────────────────────────────────────────────┐   │
  │          │─────────►│  │ Create / Edit / Delete Packages              │   │
  │  VENDOR  │─────────►│  │ View & Manage Bookings                       │   │
  │  (Web    │─────────►│  │ View Reviews for Packages                    │   │
  │   App)   │─────────►│  │ View Vendor Analytics Dashboard              │   │
  └──────────┘          │  └─────────────────────────────────────────────┘   │
                        │                                                     │
  ┌──────────┐          │  ┌─────────────────────────────────────────────┐   │
  │  ADMIN   │─────────►│  │ Approve / Suspend Vendors                    │   │
  │  (Web    │─────────►│  │ Moderate Packages                            │   │
  │   App)   │─────────►│  │ Manage Users                                 │   │
  └──────────┘          │  └─────────────────────────────────────────────┘   │
                        └────────────────────────────────────────────────────┘
```

---

## 8. HARDWARE SPECIFICATIONS

### Development Environment

| Component | Specification |
|-----------|--------------|
| Processor | Intel Core i5 / AMD Ryzen 5 or higher |
| RAM | Minimum 8 GB (16 GB recommended for running Docker + emulator simultaneously) |
| Storage | 50 GB free SSD space (Flutter SDK, Android SDK, Docker images) |
| Operating System | Ubuntu 22.04 LTS / Windows 10+ / macOS 12+ |
| Display | 1920×1080 minimum |
| Network | Stable broadband (for Kafka, PostgreSQL containers, API calls) |

### Test Devices

| Device Type | Specification |
|-------------|--------------|
| Android Emulator | Pixel 6 API 33 (Android 13), 4 GB RAM, x86_64 ABI |
| Physical Android | Android 11+ with USB debugging enabled |
| iOS Simulator | iPhone 14 / iOS 16+ (macOS required for Xcode) |

### Server / Deployment (Production Target)

| Component | Specification |
|-----------|--------------|
| Cloud Provider | AWS / GCP / DigitalOcean |
| App Server | 2 vCPU, 4 GB RAM per microservice (minimum) |
| Database | PostgreSQL 15 (RDS or managed, 20 GB+ per service) |
| Redis | ElastiCache / managed Redis, 1 GB |
| Kafka | Confluent Cloud or self-managed (3-broker cluster) |
| Container | Docker 24+, Docker Compose (dev), Kubernetes (prod target) |

---

## 9. SOFTWARE SPECIFICATIONS

### Mobile Application

| Component | Technology | Version |
|-----------|-----------|---------|
| Framework | Flutter | SDK ^3.10.8 |
| Language | Dart | ^3.0 |
| State Management | Riverpod | 2.4.9 |
| Hooks | flutter_hooks | 0.20.4 |
| Navigation | GoRouter | 13.1.0 |
| HTTP Client | Dio | 5.4.0 |
| Local Storage | SharedPreferences | 2.5.2 |
| Code Generation | freezed / json_serializable | 2.4.6 / 6.7.1 |
| Code Generation Runner | build_runner | 2.4.7 |
| Image Loading | cached_network_image | 3.4.1 |
| SVG | flutter_svg | 2.0.9 |
| Animations | flutter_animate | 4.5.0 |
| Environment | flutter_dotenv | 5.1.0 |
| Fonts | google_fonts (Poppins) | latest |
| Dates / i18n | intl | 0.19.0 |
| IDE | VS Code / Android Studio | Latest |

### Backend Services

| Component | Technology | Version |
|-----------|-----------|---------|
| Language | Python | 3.11+ |
| Framework | Django | 4.2+ |
| REST API | Django REST Framework | 3.14+ |
| API Docs | drf-spectacular (Swagger) | latest |
| Auth | djangorestframework-simplejwt | latest |
| Database | PostgreSQL | 15 |
| Message Broker | Apache Kafka | 3.x |
| Distributed Lock | Redis | 7.x |
| Containerisation | Docker / Docker Compose | 24+ |

### Web Dashboard (Admin & Vendor)

| Component | Technology | Version |
|-----------|-----------|---------|
| Framework | Next.js (App Router) | 16.x |
| Language | TypeScript | 5.x |
| Styling | Tailwind CSS | 4.x |
| Components | shadcn/ui, Radix UI | latest |
| Data Fetching | TanStack Query | v5 |
| HTTP | Axios | latest |
| Forms | React Hook Form + Zod | latest |
| Animations | Framer Motion | latest |
| Icons | Lucide React | latest |

### DevOps / CI-CD

| Component | Technology |
|-----------|-----------|
| Version Control | Git + GitHub |
| CI/CD | GitHub Actions |
| Container Registry | Docker Hub / GitHub Container Registry |
| Static Site Hosting | Firebase Hosting |

---

## 10. PROPOSED SYSTEM

### 10.1 Problem Statement

Current travel booking solutions suffer from:

1. **Fragmentation:** Users must visit multiple agency websites to compare packages.
2. **Opacity:** Pricing and inclusions are often unclear; no standardised itinerary format.
3. **Trust deficit:** Reviews are scattered across platforms; no booking-verified review system.
4. **Poor vendor tooling:** Small agencies lack digital infrastructure to list packages and manage bookings.
5. **Weak post-booking support:** No unified channel for users to raise issues related to their booking.

### 10.2 Proposed Solution

Planymo proposes a **centralised, mobile-first travel marketplace** with the following design principles:

**1. Marketplace Model:**
Vendors onboard and list packages; users discover and book. The platform earns a commission per confirmed booking. This creates network effects — more vendors → more packages → more users → more bookings.

**2. Booking-Verified Reviews:**
Only users who have completed a booking with status `COMPLETED` can submit a review for that package. This eliminates fake or unverified reviews, building trust in the rating system.

**3. Microservices for Scalability:**
Each domain (auth, vendors, packages, bookings, ratings, support) is an independent service with its own database. Services can be scaled independently based on load.

**4. Event-Driven Async Workflows:**
Rating submission and support ticket creation trigger Kafka events via the Outbox Pattern, decoupling downstream processing (notifications, analytics) from the user-facing API response.

**5. Concurrency-Safe Bookings:**
Redis distributed locks ensure that when two users simultaneously attempt to book the last available slot in a package, only one succeeds — preventing overselling.

**6. Clean Architecture on Mobile:**
The Flutter app is structured so that business logic (domain layer) is completely independent of Flutter or Dio. This enables unit testing without a running device and easy replacement of data sources.

### 10.3 System Workflow

```
New User Journey:
Install App → Splash (token check) → Onboarding (first time) → Register (phone + OTP)
→ Home (Discovery) → Browse / Search Packages → View Trip Details
→ Wishlist OR Book Now → Booking Form → Payment → Booking Confirmed
→ [Post-trip] Write Review → View Booking History → Raise Support Ticket if needed

Returning User Journey:
Open App → Splash → JWT auto-refresh → Home (Discovery) → Continue browsing
```

---

## 11. MODULE DESCRIPTION

### Module 1: Authentication (`features/auth`)

**Purpose:** Manages the complete user identity lifecycle.

**Sub-features:**
- **Registration:** Phone number + email + name; OTP sent via SMS to verify phone
- **OTP Verification:** 6-digit time-limited OTP; resend capability
- **Login:** Phone/email + password; returns JWT access + refresh token pair
- **Forgot Password:** OTP-based identity verification → password reset
- **Reset Password:** New password set after OTP verification
- **Auto Token Refresh:** `TokenInterceptor` (Dio interceptor) silently refreshes expired access tokens; on refresh failure, triggers global `forceLogout`
- **Auth States:** `authenticated`, `unauthenticated`, `onboarding`, `blocked`, `inactive` — managed by `authProvider`; GoRouter redirects based on state

**Key files:**
- `lib/features/auth/presentation/providers/auth_provider.dart`
- `lib/core/api/token_interceptor.dart`
- `lib/core/services/storage_service.dart`

---

### Module 2: Discovery (`features/discovery`)

**Purpose:** The primary content feed — the home screen of the application.

**Sub-features:**
- **Banner Slider:** Auto-scrolling promotional banners fetched from the package-service CMS
- **Popular Destinations:** Horizontal scrollable cards for top destination categories
- **Trending Now:** Curated package slider based on booking counts
- **Travel Tips / Articles:** Listicle-format travel tips and article previews
- **Search:** Full-text search bar with debounced API calls; real-time results list
- **Wishlist Tab:** Locally and server-synced list of saved packages
- **Bookings Tab:** List of all user bookings (PENDING, CONFIRMED, COMPLETED, CANCELLED) with navigation to booking detail

**Key files:**
- `lib/features/discovery/presentation/screens/home_screen.dart`
- `lib/features/discovery/presentation/providers/discovery_provider.dart`
- `lib/features/discovery/data/datasources/package_data_source.dart`

---

### Module 3: Trip Details

**Purpose:** Full detail view for a travel package.

**Content:**
- Hero image gallery (cached images)
- Package title, agency name, pricing, duration, capacity
- Day-by-day itinerary accordion
- Package inclusions and exclusions
- Ratings summary with star breakdown
- User reviews list (fetched from ratings-service)
- Sticky "Book Now" CTA button

**Key file:** `lib/features/discovery/presentation/screens/trip_details_screen.dart`

---

### Module 4: Booking (`features/booking`)

**Purpose:** End-to-end booking lifecycle management.

**Sub-features:**
- **Booking Form:** Date range picker, traveller count selector, room/variant selection
- **Price Breakdown:** Real-time price calculation based on traveller count and dates
- **Booking Confirmation:** Calls booking_service API with Redis lock; handles concurrency
- **Payment Flow:** Integrated within booking_service; payment status tracked
- **Booking Success Screen:** Confirmation with booking ID and summary
- **Booking History:** List view with status badges; deep link to booking detail
- **Booking Detail:** Full booking summary with dates, travellers, package, payment status

**Key files:**
- `lib/features/booking/presentation/screens/booking_detail_screen.dart`
- `lib/features/discovery/presentation/providers/booking_provider.dart`

---

### Module 5: Vendor Browsing (`features/vendor`)

**Purpose:** Allows users to explore travel agencies on the platform.

**Sub-features:**
- **Vendors List:** Paginated list of all verified vendors with search
- **Vendor Detail:** Agency profile page — description, logo, contact, rating
- **Vendor Packages:** All packages offered by the vendor with navigation to individual trip details
- **Quick Access:** Discovery tab contains an "Agencies" section for fast vendor discovery

**Key files:**
- `lib/features/vendor/presentation/screens/vendors_screen.dart`
- `lib/features/vendor/presentation/screens/vendor_detail_screen.dart`

---

### Module 6: Reviews (`features/review`)

**Purpose:** Booking-verified review submission and display.

**Sub-features:**
- **Write Review Sheet:** Bottom sheet triggered from COMPLETED bookings only; star rating widget + comment text field
- **Submit Review:** Posts to ratings-service; triggers Kafka event via Outbox Pattern
- **Package Reviews List:** Shows all reviews for a package on the Trip Details screen; includes reviewer name, rating, date, and comment

**Key file:** `lib/features/review/presentation/widgets/write_review_sheet.dart`

---

### Module 7: Support (`features/support`)

**Purpose:** Customer support ticketing system.

**Sub-features:**
- **Tickets List:** All tickets for the logged-in user with status badges (OPEN, IN_PROGRESS, RESOLVED)
- **Create Ticket:** Bottom sheet with subject and description fields; linked to booking if applicable
- **Ticket Detail:** Thread view showing full message history between user and support agent
- **Reply:** User can reply to a ticket thread; message appended and event published to Kafka

**Key files:**
- `lib/features/support/presentation/screens/support_tickets_screen.dart`
- `lib/features/support/presentation/screens/ticket_detail_screen.dart`
- `lib/features/support/presentation/widgets/create_ticket_sheet.dart`

---

### Module 8: Profile (`features/profile`)

**Purpose:** User account management.

**Sub-features:**
- **Profile Screen:** User avatar, name, phone, email; menu links to sub-settings
- **Edit Profile:** Update name, email, profile photo
- **Change Password:** Current password + new password with confirmation
- **Settings Detail:** App preferences (theme toggle, notification settings)
- **Theme Provider:** Light/dark mode toggle persisted via SharedPreferences

**Key files:**
- `lib/features/profile/presentation/screens/profile_screen.dart`
- `lib/features/profile/presentation/providers/user_provider.dart`
- `lib/core/providers/theme_provider.dart`

---

### Module 9: Core Infrastructure (`core/`)

**Purpose:** Shared services and utilities used across all features.

| Component | File | Responsibility |
|-----------|------|----------------|
| API Service | `core/services/api_service.dart` | Dio client, base URL from `.env` |
| Token Interceptor | `core/api/token_interceptor.dart` | JWT refresh on 401 |
| Storage Service | `core/services/storage_service.dart` | SharedPreferences wrapper |
| App Router | `core/router/app_router.dart` | GoRouter config, auth redirects |
| App Colors | `core/themes/app_colors.dart` | Design tokens |
| App Theme | `core/themes/app_theme.dart` | Material 3 light + dark |
| App Button | `core/widgets/app_button.dart` | Branded primary button |
| App Text Field | `core/widgets/app_text_field.dart` | Consistent input styling |
| Trip Card | `core/widgets/trip_card.dart` | Reusable package card widget |
| Category Chip | `core/widgets/category_chip.dart` | Filter chip component |
| Validators | `core/utils/validators.dart` | Form validation functions |

---

## 12. KEY BENEFITS OF THE PROPOSED SYSTEM

### 1. Unified Travel Marketplace
A single platform for discovering, comparing, and booking packages from multiple agencies — eliminating the need to visit multiple websites and make manual inquiries.

### 2. Booking-Verified Trust
Reviews can only be submitted after completing a booked trip. This is a structural guarantee against fake reviews, significantly increasing the credibility of ratings compared to open-submission platforms.

### 3. Real-Time Concurrent Booking Safety
Redis distributed locking in the booking service ensures zero double-bookings even under high concurrent load, protecting vendor inventory and user experience simultaneously.

### 4. Cross-Platform Mobile App (Single Codebase)
Flutter delivers a native-quality experience on both Android and iOS from one codebase, reducing development and maintenance effort by roughly 40% compared to separate native apps.

### 5. Scalable Microservices Backend
Each domain service scales independently. During peak travel seasons, the package-service and booking_service can be scaled out horizontally without touching the ratings or support services.

### 6. Event-Driven Async Processing
Kafka + Outbox Pattern decouples review and support event publishing from the user-facing API response. Users get instant feedback; downstream processing (notifications, analytics, ML pipelines) happens asynchronously.

### 7. Clean Architecture for Maintainability
The Flutter app's three-layer architecture (data / domain / presentation) means domain logic can be unit-tested without a device, and data sources can be swapped without touching UI code.

### 8. Vendor Empowerment
The companion Next.js vendor dashboard gives travel agencies — including small operators — professional-grade tools to manage packages, track bookings, and view performance analytics.

### 9. Automatic JWT Token Management
Silent token refresh via Dio interceptor means users are never interrupted by login prompts mid-session, delivering a seamless, uninterrupted experience.

### 10. Dark-First Material 3 Design
The `#151517` dark background with `#037DBB` blue and `#EF7D0F` orange accents creates a premium, travel-inspired aesthetic. Material 3's dynamic theming supports both light and dark modes with user-controlled preference persistence.

---

## 13. OUTPUT

The following screens represent the primary outputs of the Planymo mobile application:

### Screen 1: Splash Screen
- Planymo logo centred on dark background
- Token validation in progress; navigates to Home or Auth based on JWT validity

### Screen 2: Onboarding Screen
- Multi-page swiper with travel imagery and value propositions
- "Get Started" CTA leads to Registration

### Screen 3: Auth Screens
- Login: Phone/email input + password + "Forgot Password" link
- Register: Name, phone, email, password with live validation
- OTP Verification: 6-digit OTP input with countdown timer and resend option

### Screen 4: Home Screen (Discovery Tab)
- Full-width banner carousel at top
- "Popular Destinations" horizontal scroll section
- "Trending Now" package cards slider
- "Travel Tips" article previews
- Bottom navigation bar: Discovery | Search | Vendors | Wishlist | Profile

### Screen 5: Search Screen
- Search bar with real-time debounced results
- Package cards with thumbnail, title, price, rating

### Screen 6: Trip Details Screen
- Hero image with gradient overlay
- Title, vendor name, rating, price per person, duration
- Day-by-day itinerary accordion
- Inclusions/exclusions bullet lists
- Reviews section with star distribution
- Sticky "Book Now" button

### Screen 7: Booking Detail Screen
- Date range selector
- Traveller count stepper
- Room/variant selector
- Price breakdown (base price × travellers + taxes)
- "Confirm & Pay" button

### Screen 8: Booking Success Screen
- Animated checkmark confirmation
- Booking ID, package name, dates, total paid
- "View Booking" and "Go Home" actions

### Screen 9: Vendors Screen
- Search bar for agencies
- Vendor cards (logo, name, package count, rating)

### Screen 10: Vendor Detail Screen
- Agency banner and logo
- About section
- All packages by this vendor in a scrollable grid

### Screen 11: Bookings Tab
- Status-grouped booking list (Upcoming, Completed, Cancelled)
- Booking card: package thumbnail, name, date, status badge
- "Write Review" button visible on COMPLETED bookings only

### Screen 12: Write Review Sheet
- Bottom sheet overlay
- Star rating widget (1–5 stars)
- Comment text area
- Submit button

### Screen 13: Support Tickets Screen
- Ticket list with status chips (OPEN / IN_PROGRESS / RESOLVED)
- Floating "+" button to create new ticket

### Screen 14: Ticket Detail Screen
- Thread-style message bubbles (user vs. support agent)
- Reply input pinned at bottom

### Screen 15: Profile Screen
- User avatar, name, email
- Menu items: Edit Profile, Change Password, My Bookings, Support, Settings
- Logout button

---

## 14. CONCLUSION AND FUTURE ENHANCEMENTS

### Conclusion

Planymo successfully delivers a full-stack travel marketplace platform that addresses the core fragmentation and trust problems in the travel package booking domain. The Flutter mobile application provides a polished, performant, cross-platform experience for end users through a well-structured Clean Architecture codebase. The Django microservices backend ensures domain isolation, independent scalability, and reliable event-driven workflows. The companion Next.js dashboard empowers vendors with the tools to manage their catalogue and bookings professionally.

Key technical achievements include:
- Zero-interruption JWT refresh with Dio interceptors
- Booking-verified review integrity through business-rule enforcement in the API
- Concurrency-safe booking with Redis distributed locks
- Event-driven decoupling of rating and support workflows via Kafka + Outbox Pattern
- A maintainable Flutter codebase with Clean Architecture and Riverpod that scales from a small team to multiple feature squads

The platform is production-deployable with CI/CD pipelines in place and Docker-based infrastructure ready for cloud provisioning.

### Future Enhancements

| Enhancement | Description | Priority |
|-------------|-------------|----------|
| In-App Chat | Real-time chat between users and vendors using WebSockets (Django Channels) | High |
| AI-Powered Recommendations | Personalised package suggestions based on booking history and wishlist using collaborative filtering | High |
| Push Notifications | Firebase Cloud Messaging for booking confirmations, status updates, and promotional alerts | High |
| Admin Analytics Dashboard | Real-time revenue, booking volume, and vendor performance metrics | High |
| Multi-Language Support | Regional language support using Flutter's `intl` and `flutter_localizations` packages | Medium |
| Offline Mode | Cache discovered packages locally (Hive/SQLite) for browsing without internet | Medium |
| Vendor Mobile App | Dedicated Flutter app for vendors to manage bookings and packages on the go | Medium |
| Group Bookings | Coordinated booking for groups with split-payment support | Medium |
| Dynamic Pricing | Pricing engine that adjusts package price based on demand, season, and booking lead time | High |
| Loyalty / Rewards | Points-based loyalty programme rewarding frequent bookers with discounts | Medium |
| Social Sharing | Share trips/packages to WhatsApp, Instagram with deep-link back to the package | Low |
| Itinerary PDF Export | Users can download/share their booked itinerary as a formatted PDF | Low |
| Augmented Reality Previews | AR-based destination previews using Flutter ARCore/ARKit plugins | Future |

---

## 15. REFERENCES

1. Martin, R. C. (2012). *Clean Architecture: A Craftsman's Guide to Software Structure and Design*. Prentice Hall.

2. Newman, S. (2015). *Building Microservices: Designing Fine-Grained Systems*. O'Reilly Media.

3. Kleppmann, M. (2017). *Designing Data-Intensive Applications*. O'Reilly Media.

4. Flutter Documentation. (2024). *Flutter — Build apps for any screen*. https://flutter.dev/docs

5. Rousselet, R. (2021). *Riverpod — A Reactive Caching and Data-Binding Framework*. https://riverpod.dev

6. Google. (2024). *Material Design 3 — Design System*. https://m3.material.io

7. Internet Engineering Task Force. (2015). *RFC 7519 — JSON Web Token (JWT)*. https://datatracker.ietf.org/doc/html/rfc7519

8. Nawrocki, P., Wrona, K., Marczak, A., & Jarzębowicz, A. (2021). *A Comparison of Native and Cross-platform Frameworks for Mobile Application Development*. Computer Science and Information Systems, 18(1), 73–100.

9. Auth0. (2023). *Refresh Tokens: When to Use Them and How They Interact with JWTs*. https://auth0.com/blog/refresh-tokens-what-are-they-and-when-to-use-them

10. Django REST Framework Documentation. (2024). *Django REST Framework*. https://www.django-rest-framework.org

11. Apache Kafka Documentation. (2024). *Apache Kafka — A Distributed Streaming Platform*. https://kafka.apache.org/documentation

12. Redis Documentation. (2024). *Redis — The Open Source, In-Memory Data Structure Store*. https://redis.io/docs

13. Vercel. (2024). *Next.js Documentation — App Router*. https://nextjs.org/docs

14. Docker Documentation. (2024). *Docker — Containerization Platform*. https://docs.docker.com

15. Google. (2024). *GoRouter — A Declarative Routing Package for Flutter*. https://pub.dev/packages/go_router

16. TanStack. (2024). *TanStack Query v5 — Powerful Asynchronous State Management*. https://tanstack.com/query/latest

17. World Travel & Tourism Council. (2024). *Economic Impact Report 2024*. https://wttc.org/research/economic-impact

18. Fowler, M. (2020). *Outbox Pattern*. https://microservices.io/patterns/data/transactional-outbox.html

---

*Report prepared for academic submission — Planymo Travel Marketplace Project, 2025–2026.*
