# PLANMYO – Mobile App UI/UX & Feature Specification

## Overview

PLANMYO is a **mobile travel planning platform** designed to help users discover, plan, and book curated trips quickly.

### Target Audience

- Gen Z travelers
- Couples
- Families
- Solo travelers

### Core Value Proposition

- Book curated trips in minutes
- Access verified travel agents
- Personalized trip discovery
- Seamless trip booking experience

---

# 🎨 Color Palette & Theming

The application uses a vibrant, high-contrast palette designed to appeal to Gen Z, couples, and families.

## Core Palette

| Usage | Hex Code | Description |
|------|------|------|
| Primary Blue | #037DBB | Used for backgrounds, branding, and primary UI elements |
| Action Orange | #EF7D0F | Used for CTA buttons like Next, Continue, Book Now |
| Text/Dark | #151517 | Used for headings and dark backgrounds |
| Background Light | #F5F7FA | Main screen background |
| Card Surface | #FFFFFF | Card containers |

---

## Accent Colors

| Usage | Hex |
|------|------|
| Success | #28A745 |
| Warning | #FFC107 |
| Error | #DC3545 |
| Info | #17A2B8 |

---

# 🌙 Dark Mode Strategy

To implement Dark Mode effectively:

| Element | Light Mode | Dark Mode |
|------|------|------|
| Background | #F5F7FA | #151517 |
| Cards | #FFFFFF | #242426 |
| Primary Text | #151517 | #F5F7FA |
| Secondary Text | #6C757D | #C2C2C2 |
| CTA Buttons | #EF7D0F | #EF7D0F |

### Dark Mode Design Rules

- Maintain orange CTA buttons for accessibility
- Use elevated grey cards for depth
- Avoid pure black backgrounds
- Maintain contrast ratio > 4.5:1

---

# Typography

Recommended fonts:

Primary Font


Poppins


Alternative Fonts


Inter
SF Pro
Roboto


### Typography Scale

| Type | Size |
|------|------|
| App Title | 28px |
| Section Title | 22px |
| Body | 16px |
| Caption | 14px |
| Micro Text | 12px |

---

# App Navigation Flow


Splash Screen
↓
Onboarding
↓
Login / Sign Up
↓
OTP Verification
↓
Profile Setup
↓
Home Dashboard
↓
Trip Discovery
↓
Trip Details
↓
Booking
↓
Payment
↓
Confirmation


---

# 📱 Page-by-Page Feature Extraction

---

# 1. Splash Screen

Purpose: Introduce brand identity.

### Components

- PLANMYO logo
- Travel-themed illustration
- Brand background color

### Behavior

- Automatically transitions after 2 seconds
- Redirects to onboarding

---

# 2. Onboarding & Brand Intro

### Screen 1

Message


Book curated trips in minutes


Components

- Travel assistant illustration
- Next button
- Skip option
- Progress indicator

---

### Screen 2

Message


Verified agents. Real reviews.


Features

- Verified travel agencies
- Real traveler reviews

---

### Screen 3

Message


Designed for Gen Z, Couples & Families


CTA


Let's begin the journey →


---

# Navigation

| Action | Result |
|------|------|
| Next | Go to next onboarding screen |
| Skip | Jump to Login |

---

# 3. Authentication

---

# Login Flow

### Fields

| Field | Type |
|------|------|
| Mobile Number | Phone input |
| Password | Password input |

### Features

- Country code selector
- Password visibility toggle
- Forgot password recovery
- Continue button

---

# Validation Rules

### Mobile Number

- Required
- 10 digits
- Numeric only

### Password

- Minimum 6 characters

---

# Error Handling

### Incorrect Password


Incorrect password
Try again or reset password


### Account Not Found


No user account found
Please sign up


UI Behavior

- Field border turns red
- Inline error message appears

---

# Sign-Up Flow

### Step 1

Enter mobile number


Verify your number


---

# OTP Verification

### Input

4 digit OTP

### Options

| Option | Purpose |
|------|------|
| Resend SMS | Request new OTP |
| Call Me | Receive OTP via call |

---

# Account Creation

Fields

| Field | Description |
|------|------|
| Name | Full name |
| Date of Birth | Calendar picker |
| Password | Account password |
| Confirm Password | Re-enter password |

---

# 4. Discovery & Search

---

# Home Dashboard

Greeting


Hi USER NAME
Where are we dreaming of going today?


---

# Features

### Personalized Recommendations

Example


Because you searched for "Hills"


### Category Filters

| Category |
|------|
| Temple |
| Hill Station |
| Beaches |
| Snow |

---

# Search Interface

Advanced search fields:

| Field | Description |
|------|------|
| Destination | Location input |
| Travel Dates | Start and end date |
| Number of Travelers | Adults / Children |
| Tourist Type | Solo, Couple, Family |

---

# Search Results

Trip cards display:

- Destination image
- Rating
- Price per person
- Duration
- Favorite button

Example


₹1500 / person
Ooty
Trending now


---

# 5. Trip Details & Booking

---

# Trip Detail Page

Content includes:

- Destination overview
- Travel highlights
- Gallery images
- Package description

Example


Kodaikanal – Princess of Hill Stations


---

# Partner Transparency

Displays

- Travel agency name

Example


Green Valley Travels


- Rating

Example


4.8 ⭐


---

# Booking Form

Primary traveler info:

| Field |
|------|
| First Name |
| Last Name |
| Email |
| Date of Birth |

---

# Co-Traveler Details

Additional traveler form.

Includes validation warnings such as:


Aadhaar name mismatch warning


---

# Price Summary

Breakdown includes:

| Item |
|------|
| Package Price |
| Taxes |
| Service Fees |
| Coupon Discounts |

---

# 6. Management & Support

---

# Wish List

Users can save trips for later.

Features

- Add/remove favorites
- Quick booking from saved trips

---

# My Trips

Two sections:

| Section |
|------|
| Upcoming Trips |
| Past Trips |

---

# Support Center

Features

- 24/7 Chat Support
- Raise query
- FAQ section

Example topics:

- Agency reliability
- Refund policies
- Booking support

---

# 7. Post Purchase

---

# Booking Confirmation

Displayed after payment.

Message


Payment Confirmed


---

# Order Summary

Displays:

- Trip destination
- Travel dates
- Total amount paid
- Agency partner details

---

# Key UI Components

Reusable components:

- Trip cards
- Search bars
- Category chips
- OTP input boxes
- CTA buttons
- Booking forms
- Bottom navigation bar

---

# Bottom Navigation

Main tabs:

| Tab |
|------|
| Home |
| Wishlist |
| My Trips |
| Support |
| Profile |

---

# Future Feature Suggestions

- AI trip planner
- Smart itinerary generator
- Budget optimizer
- Social travel groups
- AI chatbot travel assistant

---
