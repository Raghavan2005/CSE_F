# Planymo — User Service Frontend Integration Guide

---

## Overview

The User Service is the **single authentication authority** for the Planymo platform.
It handles all user identity, OTP verification, JWT token lifecycle, and profile management.

| Item | Value |
|---|---|
| Base URL (dev) | `http://10.0.2.2:8000` (Android emulator) |
| Base URL (local browser) | `http://localhost:8000` |
| Content-Type | `application/json` |
| Auth scheme | `Bearer <access_token>` in `Authorization` header |

---

## Table of Contents

1. [Auth Flow Overview](#1-auth-flow-overview)
2. [Token Management](#2-token-management)
3. [Password Rules](#3-password-rules)
4. [Dev Notes](#4-dev-notes)
5. [Endpoints](#5-endpoints)
   - [5.1 Request OTP](#51-request-otp)
   - [5.2 Register](#52-register)
   - [5.3 Login](#53-login)
   - [5.4 Refresh Token](#54-refresh-token)
   - [5.5 Logout](#55-logout)
   - [5.6 Get Profile](#56-get-profile)
   - [5.7 Update Profile](#57-update-profile)
   - [5.8 Change Password](#58-change-password)
   - [5.9 Forgot Password — Request OTP](#59-forgot-password--request-otp)
   - [5.10 Forgot Password — Reset](#510-forgot-password--reset)
6. [Validation Rules](#6-validation-rules)
7. [Error Handling](#7-error-handling)
8. [Complete Flow Walkthroughs](#8-complete-flow-walkthroughs)
9. [Mobile Code Examples](#9-mobile-code-examples)
   - [9.1 Flutter (Dart)](#91-flutter-dart)
   - [9.2 React Native (JavaScript)](#92-react-native-javascript)

---

## 1. Auth Flow Overview

### Registration

```
┌─────────────────┐     ┌──────────────────────────────┐     ┌───────────┐
│  Request OTP    │────▶│  Register (OTP + user info)  │────▶│   Login   │
│  POST /request- │     │  POST /register/             │     │  POST     │
│  otp/           │     │  verifies OTP internally     │     │  /login/  │
└─────────────────┘     └──────────────────────────────┘     └───────────┘
```

### Login & Token Lifecycle

```
┌─────────┐    access_token (15 min)    ┌───────────────────┐
│  Login  │───────────────────────────▶│  Protected Routes │
│         │    refresh_token (30 days)  │  GET /profile/    │
└─────────┘                             │  PUT /profile/    │
     ▲                                  │  POST /logout/    │
     │                                  └───────────────────┘
     │          access expired?
     │    ┌──────────────────────────┐
     └────│  POST /refresh/          │
          │  swap refresh → new JWT  │
          └──────────────────────────┘
```

### Forgot Password

```
┌──────────────────────┐     ┌────────────────────────┐     ┌───────────┐
│  Request Reset OTP   │────▶│  Reset Password        │────▶│   Login   │
│  POST /forgot-       │     │  POST /forgot-password │     │  (again)  │
│  password/request/   │     │  /reset/               │     │           │
└──────────────────────┘     └────────────────────────┘     └───────────┘
```

---

## 2. Token Management

### Token Types

| Token | Format | Expiry | Purpose |
|---|---|---|---|
| `access_token` | JWT (HS256) | 15 minutes | Authenticate every protected API call |
| `refresh_token` | UUID v4 string | 30 days | Get a new access token without re-login |

### Storage Recommendation

| Platform | access_token | refresh_token |
|---|---|---|
| Android | In-memory (ViewModel) | EncryptedSharedPreferences |
| Web | JS memory / state | httpOnly cookie or localStorage |

### How to attach the access token

Every protected request must include:

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNTUwZ...
```

### Token refresh strategy (interceptor pattern)

```
Request fails with 401
        │
        ▼
POST /auth/user/refresh/  { refresh_token }
        │
   ┌────┴────┐
200 OK     401 Unauthorized
   │             │
   ▼             ▼
Store new    Clear tokens
access_token  → redirect to login
Retry original request
```

### When all tokens are invalidated

The server revokes **all** refresh tokens on:
- Logout
- Change password
- Forgot password reset

Always clear both tokens from storage and redirect to login after these actions.

---

## 3. Password Rules

Enforce these on the frontend before submitting to give instant feedback:

| Rule | Detail |
|---|---|
| Minimum length | 8 characters |
| Uppercase required | At least one A–Z character |
| Digit required | At least one 0–9 character |

**Valid examples:** `Secret1`, `Hello123`, `Pass9word`

**Invalid examples:** `password` (no uppercase, no digit), `PASSWORD1` (no lowercase is fine), `Short1` (too short)

---

## 4. Validation Rules (Client Side)

Enforce these on the frontend using `AuthValidator` to give instant feedback:

| Field | Rule | Error Message |
| --- | --- | --- |
| **Name** | Min 2 characters | Name must be at least 2 characters |
| **Phone** | Exactly 10 digits | Enter a valid 10 digit mobile number |
| **Password** | Min 8 chars, 1 Upper, 1 Digit | Password must contain at least... |
| **OTP** | Exactly 6 digits | OTP must be exactly 6 digits |

---

## 5. Dev Notes

| Note | Detail |
|---|---|
| Static OTP | In development, all OTPs are always `123456` |
| `otp_debug` field | Both OTP endpoints return the OTP code in the response body for dev — this will be removed in production |
| No SMS | OTPs are not actually sent via SMS in dev |

---

## 6. Endpoints

---

### 5.1 Request OTP

Generates a 6-digit OTP for the given phone number. Must be called before registration or forgot password.

```
POST /auth/user/request-otp/
```

**Request Body**

| Field | Type | Required | Constraints |
|---|---|---|---|
| `phone` | string | yes | max 15 chars |

```json
{
  "phone": "9876543210"
}
```

**Success Response** — `200 OK`

```json
{
  "message": "OTP sent successfully",
  "otp_debug": "123456"
}
```

**Error Responses**

| Status | Body | Reason |
|---|---|---|
| `400` | `{ "phone": ["This field is required."] }` | Missing phone field |

> OTP expires after **5 minutes**. If expired, call this endpoint again to get a new one.

---

### 5.2 Register

Creates a new user account. Verifies the OTP as part of this request — no separate verify step needed.

```
POST /auth/user/register/
```

**Request Body**

| Field | Type | Required | Constraints |
|---|---|---|---|
| `name` | string | yes | max 120 chars |
| `phone` | string | yes | max 15 chars |
| `otp` | string | yes | exactly 6 chars |
| `password` | string | yes | min 8 chars, 1 uppercase, 1 digit |

```json
{
  "name": "John Doe",
  "phone": "9876543210",
  "otp": "123456",
  "password": "Secret123"
}
```

**Success Response** — `201 Created`

```json
{
  "user_id": "550e8400-e29b-41d4-a716-446655440000",
  "message": "User registered successfully"
}
```

**Error Responses**

| Status | Body | Reason |
|---|---|---|
| `400` | `{ "error": "Invalid OTP" }` | OTP code is wrong |
| `400` | `{ "error": "OTP expired" }` | OTP is older than 5 minutes |
| `400` | `{ "error": "Password must be at least 8 characters" }` | Weak password |
| `400` | `{ "error": "Password must contain at least one uppercase letter" }` | Weak password |
| `400` | `{ "error": "Password must contain at least one digit" }` | Weak password |
| `409` | `{ "error": "User already exists" }` | Phone already registered |
| `400` | `{ "phone": ["This field is required."] }` | DRF validation — missing field |

> After successful registration, call [Login](#53-login) to get tokens. Register does **not** return tokens.

---

### 5.3 Login

Authenticates a registered user and returns both tokens.

```
POST /auth/user/login/
```

**Request Body**

| Field | Type | Required | Constraints |
|---|---|---|---|
| `phone` | string | yes | max 15 chars |
| `password` | string | yes | — |

```json
{
  "phone": "9876543210",
  "password": "Secret123"
}
```

**Success Response** — `200 OK`

```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNTUwZTg0MDAtZTI5Yi00MWQ0LWE3MTYtNDQ2NjU1NDQwMDAwIiwidHlwZSI6ImFjY2VzcyIsImlhdCI6MTcwNTMxMjIwMCwiZXhwIjoxNzA1MzEzMTAwfQ.abc123",
  "refresh_token": "550e8400-e29b-41d4-a716-446655440000"
}
```

**Error Responses**

| Status | Body | Reason |
|---|---|---|
| `401` | `{ "error": "Invalid credentials" }` | Wrong phone or password |

> Store `access_token` in memory and `refresh_token` in secure persistent storage.

---

### 5.4 Refresh Token

Exchanges a valid refresh token for a new access token. Use this silently when the access token expires.

```
POST /auth/user/refresh/
```

**Request Body**

| Field | Type | Required | Constraints |
|---|---|---|---|
| `refresh_token` | string | yes | UUID string |

```json
{
  "refresh_token": "550e8400-e29b-41d4-a716-446655440000"
}
```

**Success Response** — `200 OK`

```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNTUwZTg0MDAtZTI5Yi00MWQ0LWE3MTYtNDQ2NjU1NDQwMDAwIiwidHlwZSI6ImFjY2VzcyIsImlhdCI6MTcwNTMxMjgwMCwiZXhwIjoxNzA1MzEzNzAwfQ.xyz789"
}
```

**Error Responses**

| Status | Body | Reason |
|---|---|---|
| `401` | `{ "error": "Invalid refresh token" }` | Token not found or already revoked |
| `401` | `{ "error": "Refresh token expired" }` | Token is older than 30 days |

> If this returns `401`, the session is dead — clear both tokens and redirect to login.

---

### 5.5 Logout

Revokes the refresh token server-side. The access token will naturally expire after 15 minutes.

```
POST /auth/user/logout/
```

**Headers**

```
Authorization: Bearer <access_token>
```

**Request Body**

| Field | Type | Required | Constraints |
|---|---|---|---|
| `refresh_token` | string | yes | UUID string |

```json
{
  "refresh_token": "550e8400-e29b-41d4-a716-446655440000"
}
```

**Success Response** — `200 OK`

```json
{
  "message": "Logged out successfully"
}
```

**Error Responses**

| Status | Body | Reason |
|---|---|---|
| `401` | `{ "error": "Unauthorized" }` | Missing or invalid access token |

> Always clear both tokens from local storage after calling this, regardless of the response.

---

### 5.6 Get Profile

Returns the authenticated user's profile data.

```
GET /auth/user/profile/
```

**Headers**

```
Authorization: Bearer <access_token>
```

**No Request Body**

**Success Response** — `200 OK`

```json
{
  "user_id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "9876543210",
  "created_at": "2024-01-15T10:30:00.000000Z"
}
```

| Field | Type | Notes |
|---|---|---|
| `user_id` | UUID string | Permanent unique identifier |
| `name` | string | — |
| `email` | string or `null` | Optional — not set at registration |
| `phone` | string | — |
| `created_at` | ISO 8601 datetime | UTC timezone |

**Error Responses**

| Status | Body | Reason |
|---|---|---|
| `401` | `{ "error": "Unauthorized" }` | Missing, expired, or invalid access token |

---

### 5.7 Update Profile

Updates the user's name and/or email. Both fields are optional — only send what needs to change.

```
PUT /auth/user/profile/update/
```

**Headers**

```
Authorization: Bearer <access_token>
```

**Request Body**

| Field | Type | Required | Constraints |
|---|---|---|---|
| `name` | string | no | max 120 chars |
| `email` | string | no | valid email format |

```json
{
  "name": "Jane Doe",
  "email": "jane@example.com"
}
```

You can also send just one field:

```json
{
  "email": "newemail@example.com"
}
```

**Success Response** — `200 OK`

```json
{
  "user_id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "Jane Doe",
  "email": "jane@example.com",
  "phone": "9876543210"
}
```

**Error Responses**

| Status | Body | Reason |
|---|---|---|
| `401` | `{ "error": "Unauthorized" }` | Missing or invalid access token |
| `400` | `{ "email": ["Enter a valid email address."] }` | Invalid email format |

---

### 5.8 Change Password

Changes the password for the currently authenticated user. Revokes **all** active sessions on success.

```
POST /auth/user/change-password/
```

**Headers**

```
Authorization: Bearer <access_token>
```

**Request Body**

| Field | Type | Required | Constraints |
|---|---|---|---|

| `current_password` | string | yes | — |
| `new_password` | string | yes | min 8 chars, 1 uppercase, 1 digit |

```json
{
  "current_password": "OldSecret123",
  "new_password": "NewSecret456"
}
```

**Success Response** — `200 OK`

```json
{
  "message": "Password changed successfully. All sessions revoked."
}
```

**Error Responses**

| Status | Body | Reason |
|---|---|---|
| `400` | `{ "error": "Current password is incorrect" }` | Wrong current password |
| `400` | `{ "error": "Password must be at least 8 characters" }` | Weak new password |
| `400` | `{ "error": "Password must contain at least one uppercase letter" }` | Weak new password |
| `400` | `{ "error": "Password must contain at least one digit" }` | Weak new password |
| `401` | `{ "error": "Unauthorized" }` | Missing or invalid access token |

> On success, clear both tokens from storage and redirect to login — all sessions including the current one are invalidated.

---

### 5.9 Forgot Password — Request OTP

Sends a password reset OTP to the phone number. The user does **not** need to be logged in.

```
POST /auth/user/forgot-password/request/
```

**Request Body**

| Field | Type | Required | Constraints |
|---|---|---|---|
| `phone` | string | yes | max 15 chars |

```json
{
  "phone": "9876543210"
}
```

**Success Response** — `200 OK`

```json
{
  "message": "OTP sent for password reset",
  "otp_debug": "123456"
}
```

**Error Responses**

| Status | Body | Reason |
|---|---|---|
| `400` | `{ "phone": ["This field is required."] }` | Missing phone |

> There is no "phone not found" error — the response is always `200` to prevent phone number enumeration.

---

### 5.10 Forgot Password — Reset

Resets the password using the OTP. Revokes **all** active sessions on success.

```
POST /auth/user/forgot-password/reset/
```

**Request Body**

| Field | Type | Required | Constraints |
|---|---|---|---|
| `phone` | string | yes | max 15 chars |
| `otp` | string | yes | exactly 6 chars |
| `new_password` | string | yes | min 8 chars, 1 uppercase, 1 digit |

```json
{
  "phone": "9876543210",
  "otp": "123456",
  "new_password": "NewSecret456"
}
```

**Success Response** — `200 OK`

```json
{
  "message": "Password reset successful. All sessions revoked."
}
```

**Error Responses**

| Status | Body | Reason |
|---|---|---|
| `400` | `{ "error": "Invalid OTP" }` | OTP code is wrong |
| `400` | `{ "error": "OTP expired" }` | OTP is older than 5 minutes |
| `400` | `{ "error": "Password must be at least 8 characters" }` | Weak password |
| `400` | `{ "error": "Password must contain at least one uppercase letter" }` | Weak password |
| `400` | `{ "error": "Password must contain at least one digit" }` | Weak password |

> After success, redirect to login. Any previously stored tokens are now invalid.

---

## 7. Error Handling

### HTTP Status Code Reference

| Code | Meaning |
|---|---|
| `200` | Success |
| `201` | Resource created successfully |
| `400` | Bad request — validation error or business rule violation |
| `401` | Unauthorized — token missing, expired, or invalid |
| `409` | Conflict — resource already exists (e.g. phone already registered) |

### Two Error Formats

The API returns errors in two different shapes depending on where the error originates.

**Format 1 — Business logic error** (from service layer)
```json
{
  "error": "Invalid credentials"
}
```

**Format 2 — Field validation error** (from DRF serializer)
```json
{
  "phone": ["This field is required."],
  "password": ["Ensure this field has at least 8 characters."]
}
```

Handle both in a single utility function on your frontend:

```
function extractError(response):
  if response.error → show response.error
  else → join all field error arrays and show them
```

### Common Mistakes

| Mistake | Result | Fix |
|---|---|---|
| Forgetting `Authorization` header | `401 Unauthorized` | Add `Bearer <token>` header |
| Access token expired, not refreshed | `401 Unauthorized` | Call `/refresh/` then retry |
| OTP older than 5 minutes | `400 OTP expired` | Call request-otp again |
| Phone already registered | `409 Conflict` | Redirect to login screen |
| Password missing uppercase or digit | `400` | Validate before submitting |

---

## 8. Complete Flow Walkthroughs

---

### New User Registration

```
Step 1 — Request OTP
POST /auth/user/request-otp/
Body:  { "phone": "9876543210" }
Expect: 200 { "message": "OTP sent successfully", "otp_debug": "123456" }

Step 2 — Register (OTP verified here)
POST /auth/user/register/
Body:  { "name": "John Doe", "phone": "9876543210", "otp": "123456", "password": "Secret123" }
Expect: 201 { "user_id": "...", "message": "User registered successfully" }

Step 3 — Login
POST /auth/user/login/
Body:  { "phone": "9876543210", "password": "Secret123" }
Expect: 200 { "access_token": "...", "refresh_token": "..." }
Action: Store both tokens

Step 4 — Access protected routes
GET /auth/user/profile/
Header: Authorization: Bearer <access_token>
Expect: 200 { "user_id": "...", "name": "John Doe", ... }
```

---

### Returning User Login

```
Step 1 — Login
POST /auth/user/login/
Body:  { "phone": "9876543210", "password": "Secret123" }
Expect: 200 { "access_token": "...", "refresh_token": "..." }
Action: Store both tokens

Step 2 — Use access token for all protected requests
Header: Authorization: Bearer <access_token>
```

---

### Silent Token Refresh (Interceptor)

```
Step 1 — Any protected API call returns 401

Step 2 — Refresh
POST /auth/user/refresh/
Body:  { "refresh_token": "<stored_refresh_token>" }

  If 200 OK:
    → Update stored access_token
    → Retry the original failed request

  If 401:
    → Clear both tokens from storage
    → Redirect user to login screen
```

---

### Forgot Password

```
Step 1 — Request OTP (no login required)
POST /auth/user/forgot-password/request/
Body:  { "phone": "9876543210" }
Expect: 200 { "message": "OTP sent for password reset", "otp_debug": "123456" }

Step 2 — Reset password
POST /auth/user/forgot-password/reset/
Body:  { "phone": "9876543210", "otp": "123456", "new_password": "NewSecret456" }
Expect: 200 { "message": "Password reset successful. All sessions revoked." }

Step 3 — Login with new password
POST /auth/user/login/
Body:  { "phone": "9876543210", "password": "NewSecret456" }
```

---

### Change Password (Logged In)

```
Step 1 — Change password
POST /auth/user/change-password/
Header: Authorization: Bearer <access_token>
Body:   { "current_password": "Secret123", "new_password": "NewSecret456" }
Expect: 200 { "message": "Password changed successfully. All sessions revoked." }

Step 2 — Clear both tokens from storage

Step 3 — Redirect to login
```

---

### Logout

```
Step 1 — Logout
POST /auth/user/logout/
Header: Authorization: Bearer <access_token>
Body:   { "refresh_token": "<stored_refresh_token>" }
Expect: 200 { "message": "Logged out successfully" }

Step 2 — Clear both tokens from storage (do this even if the request fails)

Step 3 — Redirect to login
```
