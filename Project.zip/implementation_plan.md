## Feature Implementation Roadmap

### Phase 1: Onboarding & UI Foundation
1.  **Onboarding Carousel**:
    *   Implement [OnboardingScreen](file:///f:/Planymo/planymo-app/lib/features/onboarding/presentation/screens/onboarding_screen.dart#4-29) with a 3-page `PageView`.
    *   Add custom progress indicators and "Next/Skip" logic.
    *   Use `flutter_animate` for smooth entry animations.
2.  **UI Kit Development**:
    *   Create reusable `AppButton` (Primary/Secondary styles).
    *   Create `AppTextField` with custom validation styling.
    *   Implement `CategoryChip` and `TripCard` components.

### Phase 2: Authentication Flow
1.  **Login & Multi-step Signup**:
    *   Build Mobile Number input screen with country code selector.
    *   Implement OTP Verification screen (4-digit input).
    *   Create Account Creation form (Name, DOB, Password).
2.  **Auth State Management**:
    *   Set up Riverpod providers for `authStatus` and `currentUser`.
    *   Implement dummy authentication service for integration.

### Phase 3: Discovery & Search
1.  **Home Dashboard**:
    *   Implement personalized greeting and "Dreaming of?" header.
    *   Build horizontal category filter list (Temple, Hill Station, etc.).
    *   Implement "Trending" and "Recommended" trip carousels.
2.  **Search Interface**:
    *   Create advanced search screen (Destination, Dates, Travelers, Guest Type).
    *   Implement Search Results page with filtering/sorting.

### Phase 4: Trip Details & Booking
1.  **Trip Detail Page**:
    *   Build collapsible headers with destination images.
    *   Implement "Gallery", "Highlights", and "Package Info" sections.
2.  **Booking Logic**:
    *   Multi-step booking form (Primary traveler + Co-travelers).
    *   Dynamic Price Summary calculation.
    *   Booking Confirmation splash after "payment".

### Phase 5: User Profile & Management
1.  **Wishlist & My Trips**:
    *   Implement favorites management with Riverpod.
    *   Create "Upcoming" and "Past" trip lists.
2.  **Support & Settings**:
    *   Build FAQ section and "Raise Query" form.
    *   User profile edit and account settings.

## Execution Strategy
We will implement one feature at a time, following the **Feature-First** architecture. Each feature will follow this internal loop:
1.  **Domain**: Define entities and provider interfaces.
2.  **Data**: Implement repository (mocked initially).
3.  **Presentation**: Build UI components and integrate state.
4.  **Verification**: Manual UI check and `flutter analyze`.
