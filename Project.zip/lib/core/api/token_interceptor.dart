import 'package:dio/dio.dart';

class TokenInterceptor extends Interceptor {
  final Dio dio;

  TokenInterceptor({required this.dio});

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) async {
    if (err.response?.statusCode == 401) {
      final refreshToken = await _getRefreshToken();
      if (refreshToken != null) {
        try {
          final newAccessToken = await _refreshAccessToken(refreshToken);
          if (newAccessToken != null) {
            // Retry the original request
            final options = err.requestOptions;
            options.headers['Authorization'] = 'Bearer $newAccessToken';
            final response = await dio.fetch(options);
            return handler.resolve(response);
          }
        } catch (e) {
          // Refresh failed, maybe redirect to login or just propagate the error
          // We'll let the UI handle the 401 if refresh fails
        }
      }
    }
    return handler.next(err);
  }

  @override
  void onRequest(
    RequestOptions options,
    RequestInterceptorHandler handler,
  ) async {
    // Only add token if it's not a public endpoint
    final publicPaths = [
      '/auth/user/login/',
      '/auth/user/register/',
      '/auth/user/request-otp/',
      '/auth/user/verify-otp/',
      '/auth/user/refresh/',
      '/auth/user/forgot-password/request/',
      '/auth/user/forgot-password/reset/',
    ];

    if (!publicPaths.contains(options.path)) {
      final accessToken = await _getAccessToken();
      if (accessToken != null) {
        options.headers['Authorization'] = 'Bearer $accessToken';
      }
    }
    return handler.next(options);
  }

  Future<String?> _getAccessToken() async {
    // This will be implemented when we have the AuthToken model and storage logic
    // For now, let's assume we store it in StorageService or similar
    return null;
  }

  Future<String?> _getRefreshToken() async {
    return null;
  }

  Future<String?> _refreshAccessToken(String refreshToken) async {
    try {
      final response = await dio.post(
        '/auth/user/refresh/',
        data: {'refresh_token': refreshToken},
      );
      if (response.statusCode == 200) {
        final newAccessToken = response.data['access_token'];
        // Save new token
        return newAccessToken;
      }
    } catch (e) {
      return null;
    }
    return null;
  }
}
