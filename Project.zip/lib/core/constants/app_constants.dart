class AppConstants {
  static const String appName = 'PLANMYO';
  
  // API Endpoints (Placeholders for now)
  static const String baseUrl = 'https://api.planmyo.com/v1';
  static const String loginEndpoint = '/auth/login';
  static const String signupEndpoint = '/auth/signup';
  static const String tripsEndpoint = '/trips';
  
  // Storage Keys
  static const String tokenKey = 'auth_token';
  static const String userKey = 'user_data';
  
  // Asset Paths
  static const String logoPath = 'assets/images/logo.png';
  static const String illustrationPath = 'assets/illustrations/';
}
