import 'package:code/features/auth/presentation/screens/forgot_password_screen.dart';
import 'package:code/features/auth/presentation/screens/login_screen.dart';
import 'package:code/features/auth/presentation/screens/otp_screen.dart';
import 'package:code/features/auth/presentation/screens/reset_password_screen.dart';
import 'package:code/features/auth/presentation/screens/signup_screen.dart';
import 'package:code/features/discovery/presentation/screens/article_details_screen.dart';
import 'package:code/features/discovery/presentation/screens/booking_success_screen.dart';
import 'package:code/features/discovery/presentation/screens/home_screen.dart';
import 'package:code/features/discovery/presentation/screens/notifications_screen.dart';
import 'package:code/features/discovery/presentation/screens/trip_details_screen.dart';
import 'package:code/features/discovery/presentation/widgets/wishlist_tab.dart';
import 'package:code/features/onboarding/presentation/screens/onboarding_screen.dart';
import 'package:code/features/profile/presentation/screens/change_password_screen.dart';
import 'package:code/features/profile/presentation/screens/edit_profile_screen.dart';
import 'package:code/features/support/presentation/screens/support_tickets_screen.dart';
import 'package:code/features/vendor/presentation/screens/vendors_screen.dart';
import 'package:code/features/splash/presentation/screens/splash_screen.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

final appRouter = GoRouter(
  initialLocation: '/splash',
  routes: [
    GoRoute(
      path: '/splash',
      name: 'splash',
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
      path: '/onboarding',
      name: 'onboarding',
      builder: (context, state) => const OnboardingScreen(),
    ),
    // Auth Routes
    GoRoute(
      path: '/auth/login',
      name: 'login',
      builder: (context, state) => const LoginScreen(),
    ),
    GoRoute(
      path: '/auth/otp',
      name: 'otp',
      builder: (context, state) {
        final extra = state.extra as Map<String, dynamic>?;
        return OtpScreen(registrationData: extra);
      },
    ),
    GoRoute(
      path: '/auth/signup',
      name: 'signup',
      builder: (context, state) => const SignupScreen(),
    ),
    GoRoute(
      path: '/auth/forgot-password',
      name: 'forgot_password',
      builder: (context, state) => const ForgotPasswordScreen(),
    ),
    GoRoute(
      path: '/auth/reset-password',
      name: 'reset_password',
      builder: (context, state) {
        final extra = state.extra as Map<String, dynamic>;
        return ResetPasswordScreen(phone: extra['phone']!);
      },
    ),
    GoRoute(
      path: '/',
      name: 'home',
      builder: (context, state) => const HomeScreen(),
    ),
    GoRoute(
      path: '/trip-details/:id',
      name: 'trip_details',
      builder: (context, state) {
        final id = state.pathParameters['id']!;
        return TripDetailsScreen(tripId: id);
      },
    ),
    GoRoute(
      path: '/article-details/:id',
      name: 'article_details',
      builder: (context, state) {
        final id = state.pathParameters['id']!;
        return ArticleDetailsScreen(articleId: id);
      },
    ),
    GoRoute(
      path: '/notifications',
      name: 'notifications',
      builder: (context, state) => const NotificationsScreen(),
    ),
    GoRoute(
      path: '/booking-success',
      name: 'booking_success',
      builder: (context, state) => const BookingSuccessScreen(),
    ),
    GoRoute(
      path: '/edit-profile',
      name: 'edit_profile',
      builder: (context, state) => const EditProfileScreen(),
    ),
    GoRoute(
      path: '/change-password',
      name: 'change_password',
      builder: (context, state) => const ChangePasswordScreen(),
    ),
    GoRoute(
      path: '/wishlist',
      name: 'wishlist',
      builder: (context, state) => const WishlistTab(),
    ),
    GoRoute(
      path: '/support',
      name: 'support',
      builder: (context, state) => const SupportTicketsScreen(),
    ),
    GoRoute(
      path: '/vendors',
      name: 'vendors',
      builder: (context, state) => const VendorsScreen(),
    ),
  ],
  errorBuilder: (context, state) =>
      Scaffold(body: Center(child: Text('No route defined for ${state.uri}'))),
);
