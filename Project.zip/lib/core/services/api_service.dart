import 'package:dio/dio.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

import 'storage_service.dart';

class ApiService {
  static void Function()? onUnauthorized;

  static final Dio _dio = Dio(
    BaseOptions(
      baseUrl: dotenv.get(
        'USER_SERVICE_URL',
        fallback: 'http://localhost:8000',
      ),
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    ),
  );

  static Dio get dio {
    _dio.interceptors.clear();
    _dio.interceptors.add(
      LogInterceptor(
        requestBody: true,
        responseBody: true,
        logPrint: (object) => print('DIO_DEBUG: $object'),
      ),
    );
    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          final token = await StorageService.getAccessToken();
          if (token != null) {
            options.headers['Authorization'] = 'Bearer $token';
          }
          return handler.next(options);
        },
        onError: (DioException e, handler) async {
          if (e.response?.statusCode == 401) {
            // Token expired, handle silent refresh
            final refreshToken = await StorageService.getRefreshToken();
            if (refreshToken != null) {
              try {
                final response = await _dio.post(
                  '/auth/user/refresh/',
                  data: {'refresh_token': refreshToken},
                );
                final newToken = response.data['access_token'];
                await StorageService.saveTokens(
                  accessToken: newToken,
                  refreshToken: refreshToken,
                );

                // Retry the original request
                final options = e.requestOptions;
                options.headers['Authorization'] = 'Bearer $newToken';
                final retryResponse = await _dio.fetch(options);
                return handler.resolve(retryResponse);
              } catch (refreshError) {
                // Refresh failed, logout
                await StorageService.clearTokens();
                onUnauthorized?.call();
              }
            }
          }
          return handler.next(e);
        },
      ),
    );
    return _dio;
  }

  /// Extracts error messages from API responses.
  /// Handles both Format 1 (business logic) and Format 2 (field validation)
  /// as defined in the Frontend Integration Guide.
  static String extractError(dynamic response) {
    if (response == null) return 'Connection error or server unreachable';
    
    if (response is Map<String, dynamic>) {
      // Format 1: { "error": "Message" }
      if (response.containsKey('error') && response['error'] != null) {
        return response['error'].toString();
      }
      
      // Format 2: Field validation errors { "field": ["Error1", "Error2"] }
      final errors = <String>[];
      response.forEach((key, value) {
        if (value is List) {
          // Join list values: "field: error1, error2"
          errors.add('$key: ${value.join(', ')}');
        } else if (value is Map) {
           // Handle nested objects if any
           errors.add('$key: ${extractError(value)}');
        } else if (value != null) {
          errors.add('$key: $value');
        }
      });
      
      if (errors.isNotEmpty) {
        return errors.join('\n');
      }

      // Fallback for message field
      if (response.containsKey('message') && response['message'] != null) {
        return response['message'].toString();
      }
    }
    
    if (response is String && response.isNotEmpty) {
      return response;
    }

    return 'An unexpected error occurred';
  }
}
