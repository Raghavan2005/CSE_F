import 'dart:convert';

import 'package:code/features/auth/domain/entities/auth_token.dart';
import 'package:code/features/discovery/domain/entities/trip.dart';
import 'package:code/features/profile/domain/entities/user_profile.dart';
import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static const String _wishlistKey = 'wishlist';
  static const String _bookingsKey = 'bookings';
  static const String _userKey = 'user_profile';
  static const String _themeModeKey = 'theme_mode';
  static const String _tokenKey = 'auth_token';
  static const String _onboardingKey = 'onboarding_seen';

  static Future<void> clearTokens() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
  }

  static Future<String?> getAccessToken() async {
    final token = await loadAuthToken();
    return token?.accessToken;
  }

  static Future<String?> getRefreshToken() async {
    final token = await loadAuthToken();
    return token?.refreshToken;
  }

  static Future<AuthToken?> loadAuthToken() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = prefs.getString(_tokenKey);
    if (jsonString == null) return null;
    return AuthToken.fromJson(jsonDecode(jsonString));
  }

  static Future<List<Trip>> loadBookings() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = prefs.getString(_bookingsKey);
    if (jsonString == null) return [];
    final List<dynamic> jsonList = jsonDecode(jsonString);
    return jsonList.map((j) => Trip.fromJson(j)).toList();
  }

  static Future<bool?> loadThemeMode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_themeModeKey);
  }

  static Future<UserProfile?> loadUser() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = prefs.getString(_userKey);
    if (jsonString == null) return null;
    return UserProfile.fromJson(jsonDecode(jsonString));
  }

  static Future<List<Trip>> loadWishlist() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = prefs.getString(_wishlistKey);
    if (jsonString == null) return [];
    final List<dynamic> jsonList = jsonDecode(jsonString);
    return jsonList.map((j) => Trip.fromJson(j)).toList();
  }

  static Future<void> saveAuthToken(AuthToken token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, jsonEncode(token.toJson()));
  }

  static Future<void> saveBookings(List<Trip> trips) async {
    final prefs = await SharedPreferences.getInstance();
    final jsonList = trips.map((t) => t.toJson()).toList();
    await prefs.setString(_bookingsKey, jsonEncode(jsonList));
  }

  static Future<void> saveThemeMode(bool isDarkMode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_themeModeKey, isDarkMode);
  }

  static Future<void> saveTokens({
    required String accessToken,
    required String refreshToken,
  }) async {
    final token = AuthToken(
      accessToken: accessToken,
      refreshToken: refreshToken,
    );
    await saveAuthToken(token);
  }

  static Future<void> saveUser(UserProfile user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_userKey, jsonEncode(user.toJson()));
  }

  static Future<void> saveWishlist(List<Trip> trips) async {
    final prefs = await SharedPreferences.getInstance();
    final jsonList = trips.map((t) => t.toJson()).toList();
    await prefs.setString(_wishlistKey, jsonEncode(jsonList));
  }

  static Future<void> saveOnboardingSeen() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_onboardingKey, true);
  }

  static Future<bool> hasSeenOnboarding() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_onboardingKey) ?? false;
  }
}
