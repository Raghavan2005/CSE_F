import 'package:flutter/material.dart';

class AppColors {
  // Primary Palette
  static const Color primaryBlue = Color(0xFF037DBB);
  static const Color actionOrange = Color(0xFFEF7D0F);
  static const Color textDark = Color(0xFF151517);
  static const Color backgroundLight = Color(0xFFF5F7FA);
  static const Color cardSurface = Colors.white;

  // Accent Colors
  static const Color success = Color(0xFF28A745);
  static const Color warning = Color(0xFFFFC107);
  static const Color error = Color(0xFFDC3545);
  static const Color info = Color(0xFF17A2B8);

  // Dark Mode Palette
  static const Color backgroundDark = Color(0xFF151517);
  static const Color cardDark = Color(0xFF242426);
  static const Color textLight = Color(0xFFF5F7FA);
  static const Color textSecondaryDark = Color(0xFFC2C2C2);
  static const Color greySecondary = Color(0xFF6C757D);
}
