import '../../../../core/services/api_service.dart';

class AuthDataSource {
  AuthDataSource();

  Future<Map<String, dynamic>> forgotPasswordRequest(String phone) async {
    final response = await ApiService.dio.post(
      '/auth/user/forgot-password/request/',
      data: {'phone': phone},
    );
    return response.data;
  }

  Future<Map<String, dynamic>> forgotPasswordReset({
    required String phone,
    required String otp,
    required String newPassword,
  }) async {
    final response = await ApiService.dio.post(
      '/auth/user/forgot-password/reset/',
      data: {'phone': phone, 'otp': otp, 'new_password': newPassword},
    );
    return response.data;
  }

  Future<Map<String, dynamic>> login(String phone, String password) async {
    final response = await ApiService.dio.post(
      '/auth/user/login/',
      data: {'phone': phone, 'password': password},
    );
    return response.data;
  }

  Future<void> logout(String refreshToken) async {
    await ApiService.dio.post(
      '/auth/user/logout/',
      data: {'refresh_token': refreshToken},
    );
  }

  Future<Map<String, dynamic>> refreshToken(String refreshToken) async {
    final response = await ApiService.dio.post(
      '/auth/user/refresh/',
      data: {'refresh_token': refreshToken},
    );
    return response.data;
  }

  Future<Map<String, dynamic>> register({
    required String name,
    required String phone,
    required String password,
    required String otp,
  }) async {
    final response = await ApiService.dio.post(
      '/auth/user/register/',
      data: {
        'name': name,
        'phone': phone,
        'password': password,
        'otp': otp,
      },
    );
    return response.data;
  }

  Future<Map<String, dynamic>> deactivate() async {
    final response = await ApiService.dio.post('/auth/user/deactivate/');
    return response.data;
  }

  Future<Map<String, dynamic>> reactivate({
    required String phone,
    required String otp,
  }) async {
    final response = await ApiService.dio.post(
      '/auth/user/reactivate/',
      data: {'phone': phone, 'otp': otp},
    );
    return response.data;
  }

  Future<Map<String, dynamic>> requestOtp(String phone) async {
    final response = await ApiService.dio.post(
      '/auth/user/request-otp/',
      data: {'phone': phone},
    );
    return response.data;
  }

  Future<Map<String, dynamic>> verifyOtp(String phone, String otp) async {
    final response = await ApiService.dio.post(
      '/auth/user/verify-otp/',
      data: {'phone': phone, 'otp': otp},
    );
    return response.data;
  }
}
