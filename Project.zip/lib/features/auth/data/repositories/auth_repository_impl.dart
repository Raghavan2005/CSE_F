import '../../../../core/services/storage_service.dart';
import '../../domain/entities/auth_token.dart';
import '../data_sources/auth_data_source.dart';

class AuthRepositoryImpl {
  final AuthDataSource dataSource;

  AuthRepositoryImpl(this.dataSource);

  Future<void> deactivate() async {
    await dataSource.deactivate();
    await StorageService.clearTokens();
  }

  Future<void> reactivate({
    required String phone,
    required String otp,
  }) async {
    await dataSource.reactivate(phone: phone, otp: otp);
  }

  Future<void> forgotPasswordRequest(String phone) async {
    await dataSource.forgotPasswordRequest(phone);
  }

  Future<void> forgotPasswordReset({
    required String phone,
    required String otp,
    required String newPassword,
  }) async {
    await dataSource.forgotPasswordReset(
      phone: phone,
      otp: otp,
      newPassword: newPassword,
    );
  }

  Future<AuthToken> login(String phone, String password) async {
    final data = await dataSource.login(phone, password);
    final token = AuthToken.fromJson(data);
    await StorageService.saveTokens(
      accessToken: token.accessToken,
      refreshToken: token.refreshToken,
    );
    return token;
  }

  Future<void> logout(String refreshToken) async {
    try {
      await dataSource.logout(refreshToken);
    } catch (e) {
      // Log error but continue clearing local storage
    }
    await StorageService.clearTokens();
  }

  Future<AuthToken?> refreshToken() async {
    final token = await StorageService.loadAuthToken();
    if (token != null) {
      final data = await dataSource.refreshToken(token.refreshToken);
      final newToken = AuthToken(
        accessToken: data['access_token'],
        refreshToken:
            token.refreshToken, // Reuse old refresh token if not provided
      );
      await StorageService.saveAuthToken(newToken);
      return newToken;
    }
    return null;
  }

  Future<void> register({
    required String name,
    required String phone,
    required String password,
    required String otp,
  }) async {
    await dataSource.register(
      name: name,
      phone: phone,
      password: password,
      otp: otp,
    );
  }

  Future<void> requestOtp(String phone) async {
    await dataSource.requestOtp(phone);
  }

  Future<void> verifyOtp(String phone, String otp) async {
    await dataSource.verifyOtp(phone, otp);
  }
}
