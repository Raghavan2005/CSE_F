import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/services/api_service.dart';
import '../../../../core/services/storage_service.dart';
import '../../../../features/profile/data/data_sources/profile_data_source.dart';
import '../../../../features/profile/data/repositories/profile_repository_impl.dart';
import '../../../../features/profile/domain/entities/user_profile.dart';
import '../../data/repositories/auth_repository_impl.dart';
import 'auth_providers.dart';

final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  final repository = ref.watch(authRepositoryProvider);
  return AuthNotifier(repository);
});

class AuthNotifier extends StateNotifier<AuthState> {
  final AuthRepositoryImpl _repository;

  AuthNotifier(this._repository)
    : super(AuthState(status: AuthStatus.onboarding));

  Future<void> completeOnboarding() async {
    await StorageService.saveOnboardingSeen();
    state = state.copyWith(status: AuthStatus.unauthenticated);
  }

  Future<bool> forgotPasswordRequest(String phone) async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      await _repository.forgotPasswordRequest(phone);
      state = state.copyWith(isLoading: false);
      return true;
    } on DioException catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: ApiService.extractError(e.response?.data),
      );
      return false;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Failed to send OTP. Please try again.',
      );
      return false;
    }
  }

  Future<bool> forgotPasswordReset({
    required String phone,
    required String otp,
    required String newPassword,
  }) async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      await _repository.forgotPasswordReset(
        phone: phone,
        otp: otp,
        newPassword: newPassword,
      );
      state = state.copyWith(isLoading: false);
      return true;
    } on DioException catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: ApiService.extractError(e.response?.data),
      );
      return false;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Failed to reset password. Please try again.',
      );
      return false;
    }
  }

  Future<void> login(String phone, String password) async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    print('AUTH_DEBUG: Attempting login for $phone');
    try {
      await _repository.login(phone, password);
      print('AUTH_DEBUG: Login successful for $phone');
      // Fetch and persist user profile so userId is available for API calls
      try {
        final profileRepo = ProfileRepositoryImpl(ProfileDataSource());
        await profileRepo.getProfile();
      } catch (_) {}
      state = state.copyWith(
        status: AuthStatus.authenticated,
        phoneNumber: phone,
        isLoading: false,
      );
    } on DioException catch (e) {
      final errorData = e.response?.data;
      final errorMessage = ApiService.extractError(errorData);

      if (e.response?.statusCode == 403) {
        if (errorMessage.toLowerCase().contains('blocked')) {
          state = state.copyWith(
            isLoading: false,
            errorMessage: 'Your account has been suspended. Contact support.',
            status: AuthStatus.blocked,
          );
          return;
        } else if (errorMessage.toLowerCase().contains('inactive')) {
          state = state.copyWith(
            isLoading: false,
            errorMessage: 'Account inactive.',
            status: AuthStatus.inactive,
            phoneNumber: phone,
          );
          return;
        }
      }

      state = state.copyWith(
        isLoading: false,
        errorMessage: errorMessage,
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Invalid credentials or connection error',
      );
    }
  }

  Future<void> logout() async {
    final token = await StorageService.getRefreshToken();
    if (token != null) {
      await _repository.logout(token);
    }
    await StorageService.clearTokens();
    state = state.copyWith(
      status: AuthStatus.unauthenticated,
      phoneNumber: null,
    );
  }

  Future<void> deactivateAccount() async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      await _repository.deactivate();
      state = state.copyWith(
        status: AuthStatus.unauthenticated,
        phoneNumber: null,
        isLoading: false,
      );
    } on DioException catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: ApiService.extractError(e.response?.data),
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Failed to deactivate account.',
      );
    }
  }

  Future<bool> reactivateAccount(String phone, String otp) async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      await _repository.reactivate(phone: phone, otp: otp);
      state = state.copyWith(isLoading: false);
      return true;
    } on DioException catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: ApiService.extractError(e.response?.data),
      );
      return false;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Failed to reactivate account.',
      );
      return false;
    }
  }

  void forceLogout() {
    state = state.copyWith(
      status: AuthStatus.unauthenticated,
      phoneNumber: null,
    );
  }

  Future<void> register({
    required String name,
    required String phone,
    required String password,
    required String otp,
  }) async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    print('AUTH_DEBUG: Attempting registration for $phone');
    try {
      await _repository.register(
        name: name,
        phone: phone,
        password: password,
        otp: otp,
      );
      print('AUTH_DEBUG: Registration successful, logging in...');
      // After registration, login automatically
      await login(phone, password);
    } on DioException catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: ApiService.extractError(e.response?.data),
      );
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Registration failed. Please try again.',
      );
    }
  }

  Future<bool> verifyOtp(String phone, String otp) async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      await _repository.verifyOtp(phone, otp);
      state = state.copyWith(isLoading: false);
      return true;
    } on DioException catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: ApiService.extractError(e.response?.data),
      );
      return false;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Invalid OTP. Please try again.',
      );
      return false;
    }
  }

  Future<bool> requestOtp(String phone) async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      await _repository.requestOtp(phone);
      state = state.copyWith(isLoading: false);
      return true;
    } on DioException catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: ApiService.extractError(e.response?.data),
      );
      return false;
    } catch (e) {
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Failed to request OTP.',
      );
      return false;
    }
  }
}

class AuthState {
  final AuthStatus status;
  final String? phoneNumber;
  final String? errorMessage;
  final bool isLoading;

  AuthState({
    required this.status,
    this.phoneNumber,
    this.errorMessage,
    this.isLoading = false,
  });

  AuthState copyWith({
    AuthStatus? status,
    String? phoneNumber,
    String? errorMessage,
    bool? isLoading,
  }) {
    return AuthState(
      status: status ?? this.status,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      errorMessage: errorMessage, // Reset error if not provided
      isLoading: isLoading ?? this.isLoading,
    );
  }
}

enum AuthStatus {
  authenticated,
  unauthenticated,
  onboarding,
  blocked,
  inactive
}
