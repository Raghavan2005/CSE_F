import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/data_sources/auth_data_source.dart';
import '../../data/repositories/auth_repository_impl.dart';

final authDataSourceProvider = Provider<AuthDataSource>((ref) {
  return AuthDataSource();
});

final authRepositoryProvider = Provider<AuthRepositoryImpl>((ref) {
  final dataSource = ref.watch(authDataSourceProvider);
  return AuthRepositoryImpl(dataSource);
});
