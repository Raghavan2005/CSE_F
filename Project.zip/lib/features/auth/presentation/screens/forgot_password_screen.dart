import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../core/themes/app_colors.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../providers/providers.dart';
import '../utils/auth_validator.dart';

class ForgotPasswordScreen extends HookConsumerWidget {
  const ForgotPasswordScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final formKey = useMemoized(() => GlobalKey<FormState>());
    final phoneController = useTextEditingController();
    final authState = ref.watch(authProvider);

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textDark),
          onPressed: () => context.pop(),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Forgot Password',
                style: GoogleFonts.poppins(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textDark,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Enter your mobile number to receive a reset OTP.',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  color: AppColors.greySecondary,
                ),
              ),
              const SizedBox(height: 40),
              if (authState.errorMessage != null)
                Container(
                  padding: const EdgeInsets.all(12),
                  margin: const EdgeInsets.only(bottom: 24),
                  decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.red.shade200),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.error_outline, color: Colors.red),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          authState.errorMessage!,
                          style: GoogleFonts.poppins(
                            color: Colors.red.shade700,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              Form(
                key: formKey,
                child: AppTextField(
                  controller: phoneController,
                  label: 'Mobile Number',
                  hint: 'Enter your 10 digit number',
                  keyboardType: TextInputType.phone,
                  prefixIcon: Icons.phone_android_rounded,
                  validator: AuthValidator.validatePhone,
                  maxLength: 10,
                ),
              ),
              const SizedBox(height: 40),
               AppButton(
                text: 'Send OTP',
                isLoading: authState.isLoading,
                onPressed: () {
                  if (formKey.currentState?.validate() ?? false) {
                    final phone = phoneController.text;
                    ref
                        .read(authProvider.notifier)
                        .forgotPasswordRequest(phone)
                        .then((success) {
                          if (success && context.mounted) {
                            context.push(
                              '/auth/reset-password',
                              extra: {'phone': phone},
                            );
                          }
                        });
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
