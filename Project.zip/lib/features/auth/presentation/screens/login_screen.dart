import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../core/themes/app_colors.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../providers/providers.dart';
import '../utils/auth_validator.dart';

class LoginScreen extends HookConsumerWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final formKey = useMemoized(() => GlobalKey<FormState>());
    final phoneController = useTextEditingController();
    final passwordController = useTextEditingController();
    final authState = ref.watch(authProvider);

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textDark),
          onPressed: () => context.pop(),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Welcome Back',
                style: GoogleFonts.poppins(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textDark,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Login to continue planning your next adventure.',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  color: AppColors.greySecondary,
                ),
              ),
              const SizedBox(height: 40),
              if (authState.errorMessage != null)
                Container(
                  padding: const EdgeInsets.all(12),
                  margin: const EdgeInsets.only(bottom: 24),
                  decoration: BoxDecoration(
                    color: authState.status == AuthStatus.blocked || 
                           authState.status == AuthStatus.inactive
                        ? Colors.orange.shade50 
                        : Colors.red.shade50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: authState.status == AuthStatus.blocked || 
                             authState.status == AuthStatus.inactive
                          ? Colors.orange.shade200 
                          : Colors.red.shade200,
                    ),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Icon(
                            authState.status == AuthStatus.blocked || 
                            authState.status == AuthStatus.inactive
                                ? Icons.warning_amber_rounded
                                : Icons.error_outline,
                            color: authState.status == AuthStatus.blocked || 
                                   authState.status == AuthStatus.inactive
                                ? Colors.orange.shade800
                                : Colors.red,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              authState.errorMessage!,
                              style: GoogleFonts.poppins(
                                color: authState.status == AuthStatus.blocked || 
                                       authState.status == AuthStatus.inactive
                                    ? Colors.orange.shade900
                                    : Colors.red.shade700,
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                      if (authState.status == AuthStatus.inactive) ...[
                        const SizedBox(height: 12),
                        AppButton(
                          text: 'Reactivate Account',
                          isLoading: authState.isLoading,
                          onPressed: () {
                            final phone = phoneController.text;
                            if (phone.isNotEmpty) {
                              ref.read(authProvider.notifier).requestOtp(phone).then((success) {
                                if (success && context.mounted) {
                                  context.push('/auth/otp', extra: {
                                    'phone': phone,
                                    'isReactivation': true,
                                  });
                                }
                              });
                            }
                          },
                        ),
                      ],
                    ],
                  ),
                ),
              Form(
                key: formKey,
                child: Column(
                  children: [
                    AppTextField(
                      controller: phoneController,
                      label: 'Mobile Number',
                      hint: 'Enter your 10 digit number',
                      keyboardType: TextInputType.phone,
                      prefixIcon: Icons.phone_android_rounded,
                      validator: AuthValidator.validatePhone,
                      maxLength: 10,
                    ),
                    const SizedBox(height: 20),
                    AppTextField(
                      controller: passwordController,
                      label: 'Password',
                      hint: 'Enter your password',
                      isPassword: true,
                      prefixIcon: Icons.lock_outline_rounded,
                      validator: (val) => (val == null || val.isEmpty) ? 'Password is required' : null,
                    ),
                  ],
                ),
              ),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () => context.push('/auth/forgot-password'),
                  child: Text(
                    'Forgot Password?',
                    style: GoogleFonts.poppins(
                      color: AppColors.actionOrange,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 40),
              AppButton(
                text: 'Continue',
                isLoading: authState.isLoading,
                onPressed: () {
                  if (formKey.currentState?.validate() ?? false) {
                    ref
                        .read(authProvider.notifier)
                        .login(phoneController.text, passwordController.text)
                        .then((_) {
                          if (context.mounted &&
                              ref.read(authProvider).status ==
                                  AuthStatus.authenticated) {
                            context.go('/');
                          }
                        });
                  }
                },
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Don't have an account? ",
                    style: GoogleFonts.poppins(color: AppColors.greySecondary),
                  ),
                  GestureDetector(
                    onTap: () => context.push('/auth/signup'),
                    child: Text(
                      'Sign Up',
                      style: GoogleFonts.poppins(
                        color: AppColors.primaryBlue,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
