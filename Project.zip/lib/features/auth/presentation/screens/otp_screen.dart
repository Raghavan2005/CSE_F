import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../core/themes/app_colors.dart';
import '../../../../core/widgets/app_button.dart';
import '../providers/providers.dart';
import 'dart:async';

class OtpScreen extends HookConsumerWidget {
  final Map<String, dynamic>? registrationData;

  const OtpScreen({super.key, this.registrationData});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final otpControllers = List.generate(6, (_) => useTextEditingController());
    final focusNodes = List.generate(6, (_) => useFocusNode());
    final authState = ref.watch(authProvider);
    
    // Timer state for resend OTP
    final resendTimer = useState(0);
    final timerRef = useRef<Timer?>(null);

    void startTimer() {
      resendTimer.value = 30;
      timerRef.value?.cancel();
      timerRef.value = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (resendTimer.value > 0) {
          resendTimer.value--;
        } else {
          timer.cancel();
        }
      });
    }

    useEffect(() {
      return () => timerRef.value?.cancel();
    }, []);

    String getOtp() => otpControllers.map((c) => c.text).join();

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textDark),
          onPressed: () => context.pop(),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Verify Your Number',
                style: GoogleFonts.poppins(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textDark,
                ),
              ),
              const SizedBox(height: 8),
              if (authState.errorMessage != null)
                Container(
                  padding: const EdgeInsets.all(12),
                  margin: const EdgeInsets.only(bottom: 24),
                  decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.red.shade200),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.error_outline, color: Colors.red),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          authState.errorMessage!,
                          style: GoogleFonts.poppins(
                            color: Colors.red.shade700,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              Text(
                'Enter the 6-digit code sent to your mobile number.',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  color: AppColors.greySecondary,
                ),
              ),
              const SizedBox(height: 48),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: List.generate(6, (index) {
                  return SizedBox(
                        width: 48,
                        height: 56,
                        child: TextField(
                          controller: otpControllers[index],
                          focusNode: focusNodes[index],
                          onChanged: (value) {
                            if (value.isNotEmpty && index < 5) {
                              focusNodes[index + 1].requestFocus();
                            } else if (value.isEmpty && index > 0) {
                              focusNodes[index - 1].requestFocus();
                            }
                          },
                          textAlign: TextAlign.center,
                          keyboardType: TextInputType.number,
                          maxLength: 1,
                          style: GoogleFonts.poppins(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                          decoration: InputDecoration(
                            counterText: "",
                            filled: true,
                            fillColor: Colors.white,
                            contentPadding: EdgeInsets.zero,
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(
                                color: Colors.grey.shade300,
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: const BorderSide(
                                color: AppColors.primaryBlue,
                                width: 2,
                              ),
                            ),
                          ),
                        ),
                      )
                      .animate()
                      .fadeIn(delay: Duration(milliseconds: 100 * index))
                      .slideY(begin: 0.2);
                }),
              ),
              const SizedBox(height: 48),
              AppButton(
                text: 'Verify OTP',
                isLoading: authState.isLoading,
                onPressed: () {
                  final otp = getOtp();
                  if (otp.length == 6) {
                    final phone = registrationData?['phone'] ?? '';
                    final isReactivation = registrationData?['isReactivation'] ?? false;

                    if (isReactivation) {
                      ref
                          .read(authProvider.notifier)
                          .reactivateAccount(phone, otp)
                          .then((success) {
                        if (success && context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text(
                                'Account reactivated! Please login.',
                              ),
                              backgroundColor: Colors.green,
                            ),
                          );
                          context.go('/auth/login');
                        }
                      });
                    } else if (registrationData != null && registrationData!.containsKey('password')) {
                      // Unified registration: OTP + User data in one shot
                      ref
                          .read(authProvider.notifier)
                          .register(
                            name: registrationData!['name'],
                            phone: registrationData!['phone'],
                            password: registrationData!['password'],
                            otp: otp,
                          )
                          .then((_) {
                            if (ref.read(authProvider).status ==
                                AuthStatus.authenticated) {
                              if (context.mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text(
                                      'Registration successful! Welcome.',
                                    ),
                                    backgroundColor: Colors.green,
                                  ),
                                );
                                context.go('/');
                              }
                            }
                          });
                    } else {
                      // Just verify phone if no further data
                      ref
                          .read(authProvider.notifier)
                          .verifyOtp(phone, otp)
                          .then((success) {
                            if (success && context.mounted) {
                              context.go('/');
                            }
                          });
                    }
                  }
                },
              ),
              const SizedBox(height: 24),
              Center(
                child: TextButton(
                  onPressed: (resendTimer.value == 0 && !authState.isLoading)
                      ? () {
                          if (registrationData != null) {
                            ref
                                .read(authProvider.notifier)
                                .requestOtp(registrationData!['phone'])
                                .then((success) {
                              if (success && context.mounted) {
                                startTimer();
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('OTP resent successfully'),
                                  ),
                                );
                              }
                            });
                          }
                        }
                      : null,
                  child: Text(
                    resendTimer.value > 0
                        ? "Resend code in ${resendTimer.value}s"
                        : "Didn't receive code? Resend",
                    style: GoogleFonts.poppins(
                      color: resendTimer.value > 0
                          ? AppColors.greySecondary
                          : AppColors.primaryBlue,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
