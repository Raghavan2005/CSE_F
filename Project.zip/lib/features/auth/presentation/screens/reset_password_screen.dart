import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../core/themes/app_colors.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../providers/providers.dart';
import '../utils/auth_validator.dart';

class ResetPasswordScreen extends HookConsumerWidget {
  final String phone;

  const ResetPasswordScreen({super.key, required this.phone});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final formKey = useMemoized(() => GlobalKey<FormState>());
    final otpController = useTextEditingController();
    final passwordController = useTextEditingController();
    final confirmPasswordController = useTextEditingController();
    final authState = ref.watch(authProvider);

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textDark),
          onPressed: () => context.pop(),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Reset Password',
                style: GoogleFonts.poppins(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textDark,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Enter the OTP sent to $phone and your new password.',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  color: AppColors.greySecondary,
                ),
              ),
              const SizedBox(height: 40),
              if (authState.errorMessage != null)
                Container(
                  padding: const EdgeInsets.all(12),
                  margin: const EdgeInsets.only(bottom: 24),
                  decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.red.shade200),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.error_outline, color: Colors.red),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          authState.errorMessage!,
                          style: GoogleFonts.poppins(
                            color: Colors.red.shade700,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              Form(
                key: formKey,
                child: Column(
                  children: [
                    AppTextField(
                      controller: otpController,
                      label: 'OTP',
                      hint: 'Enter 6-digit OTP',
                      keyboardType: TextInputType.number,
                      prefixIcon: Icons.lock_clock_outlined,
                      validator: AuthValidator.validateOtp,
                      maxLength: 6,
                    ),
                    const SizedBox(height: 20),
                    AppTextField(
                      controller: passwordController,
                      label: 'New Password',
                      hint: 'Enter at least 8 chars, 1 uppercase, 1 digit',
                      isPassword: true,
                      prefixIcon: Icons.lock_outline_rounded,
                      validator: AuthValidator.validatePassword,
                    ),
                    const SizedBox(height: 20),
                    AppTextField(
                      controller: confirmPasswordController,
                      label: 'Confirm Password',
                      hint: 'Repeat new password',
                      isPassword: true,
                      prefixIcon: Icons.lock_outline_rounded,
                      validator: (val) => AuthValidator.validateConfirmPassword(
                        val,
                        passwordController.text,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 40),
              AppButton(
                text: 'Reset Password',
                isLoading: authState.isLoading,
                onPressed: () {
                  if (formKey.currentState?.validate() ?? false) {
                    ref
                        .read(authProvider.notifier)
                        .forgotPasswordReset(
                          phone: phone,
                          otp: otpController.text,
                          newPassword: passwordController.text,
                        )
                        .then((success) {
                          if (success && context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                  'Password reset successful! Please login.',
                                ),
                                backgroundColor: Colors.green,
                              ),
                            );
                            context.go('/auth/login');
                          }
                        });
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
