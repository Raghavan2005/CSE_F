import 'package:dio/dio.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:code/core/services/storage_service.dart';

class BookingDataSource {
  static Dio get _dio => Dio(BaseOptions(
        baseUrl: dotenv.get('BOOKING_SERVICE_URL', fallback: 'http://10.0.2.2:8005'),
        connectTimeout: const Duration(seconds: 15),
        receiveTimeout: const Duration(seconds: 30),
      ));

  Future<Options> _userOptions() async {
    final user = await StorageService.loadUser();
    final userId = user?.userId ?? '';
    return Options(headers: {
      'x-user-id': userId,
      'x-user-role': 'user',
    });
  }

  Future<Map<String, dynamic>> createBooking({
    required String packageId,
    required String dateOfTravel,
    required int membersCount,
  }) async {
    final options = await _userOptions();
    final response = await _dio.post(
      '/api/bookings/',
      data: {
        'package_id': packageId,
        'date_of_travel': dateOfTravel,
        'members_count': membersCount,
      },
      options: options,
    );
    return response.data;
  }

  Future<List<Map<String, dynamic>>> listBookings() async {
    final options = await _userOptions();
    final response = await _dio.get('/api/bookings/all/', options: options);
    return List<Map<String, dynamic>>.from(response.data);
  }

  Future<Map<String, dynamic>> cancelBooking(String bookingId) async {
    final options = await _userOptions();
    final response = await _dio.post(
      '/api/bookings/$bookingId/cancel/',
      options: options,
    );
    return response.data;
  }
}
