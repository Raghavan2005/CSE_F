import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:code/features/booking/data/datasources/booking_data_source.dart';
import 'package:code/features/booking/domain/entities/booking.dart';

class BookingRepository {
  final BookingDataSource _dataSource;

  BookingRepository(this._dataSource);

  Future<Booking> createBooking({
    required String packageId,
    required String dateOfTravel,
    required int membersCount,
  }) async {
    final json = await _dataSource.createBooking(
      packageId: packageId,
      dateOfTravel: dateOfTravel,
      membersCount: membersCount,
    );
    return Booking.fromJson(json);
  }

  Future<List<Booking>> listBookings() async {
    final list = await _dataSource.listBookings();
    return list.map((j) => Booking.fromJson(j)).toList();
  }

  Future<void> cancelBooking(String bookingId) async {
    await _dataSource.cancelBooking(bookingId);
  }
}

final bookingRepositoryProvider = Provider<BookingRepository>((ref) {
  return BookingRepository(BookingDataSource());
});
