class Booking {
  final String bookingId;
  final String packageId;
  final String status;
  final String totalPrice;
  final String currency;
  final String dateOfTravel;
  final int membersCount;
  final String createdAt;
  final Map<String, dynamic> packageSnapshot;
  final Map<String, dynamic> pricingSnapshot;

  Booking({
    required this.bookingId,
    required this.packageId,
    required this.status,
    required this.totalPrice,
    required this.currency,
    required this.dateOfTravel,
    required this.membersCount,
    required this.createdAt,
    required this.packageSnapshot,
    required this.pricingSnapshot,
  });

  String get packageTitle => packageSnapshot['title'] ?? '';
  String get packageLocation => packageSnapshot['location'] ?? '';
  String get packageImageUrl => packageSnapshot['cover_image_url'] ?? '';
  int get days => packageSnapshot['days'] ?? 0;
  int get nights => packageSnapshot['nights'] ?? 0;

  factory Booking.fromJson(Map<String, dynamic> json) => Booking(
        bookingId: json['booking_id'].toString(),
        packageId: json['package_id'].toString(),
        status: json['status'] ?? '',
        totalPrice: json['total_price'].toString(),
        currency: json['currency'] ?? 'INR',
        dateOfTravel: json['date_of_travel'].toString(),
        membersCount: json['members_count'] ?? 1,
        createdAt: json['created_at']?.toString() ?? '',
        packageSnapshot: Map<String, dynamic>.from(json['package_snapshot'] ?? {}),
        pricingSnapshot: Map<String, dynamic>.from(json['pricing_snapshot'] ?? {}),
      );
}
