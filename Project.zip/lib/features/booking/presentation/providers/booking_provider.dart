import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:code/features/booking/data/repositories/booking_repository.dart';
import 'package:code/features/booking/domain/entities/booking.dart';

final userBookingsProvider = FutureProvider<List<Booking>>((ref) async {
  return ref.read(bookingRepositoryProvider).listBookings();
});

final bookingCreationProvider =
    StateNotifierProvider<BookingCreationNotifier, AsyncValue<Booking?>>((ref) {
  return BookingCreationNotifier(ref.read(bookingRepositoryProvider));
});

class BookingCreationNotifier extends StateNotifier<AsyncValue<Booking?>> {
  final BookingRepository _repository;

  BookingCreationNotifier(this._repository) : super(const AsyncValue.data(null));

  Future<Booking?> createBooking({
    required String packageId,
    required String dateOfTravel,
    required int membersCount,
  }) async {
    state = const AsyncValue.loading();
    try {
      final booking = await _repository.createBooking(
        packageId: packageId,
        dateOfTravel: dateOfTravel,
        membersCount: membersCount,
      );
      state = AsyncValue.data(booking);
      return booking;
    } catch (e, st) {
      // ignore: avoid_print
      print('[BookingError] $e');
      state = AsyncValue.error(e, st);
      return null;
    }
  }

  Future<void> cancelBooking(String bookingId) async {
    await _repository.cancelBooking(bookingId);
  }

  void reset() => state = const AsyncValue.data(null);
}
