import 'package:cached_network_image/cached_network_image.dart';
import 'package:code/core/themes/app_colors.dart';
import 'package:code/features/booking/domain/entities/booking.dart';
import 'package:code/features/booking/presentation/providers/booking_provider.dart';
import 'package:code/features/review/presentation/providers/review_provider.dart';
import 'package:code/features/review/presentation/widgets/write_review_sheet.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class BookingDetailScreen extends ConsumerWidget {
  final Booking booking;
  const BookingDetailScreen({super.key, required this.booking});

  Color get _statusColor {
    switch (booking.status) {
      case 'CONFIRMED':
        return Colors.green;
      case 'COMPLETED':
        return AppColors.primaryBlue;
      case 'CANCELLED':
      case 'EXPIRED':
        return Colors.red;
      case 'PAYMENT_FAILED':
        return Colors.orange;
      default:
        return AppColors.greySecondary;
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final myReviews = ref.watch(myReviewsProvider);
    final alreadyReviewed = myReviews.valueOrNull
            ?.any((r) => r.bookingId == booking.bookingId) ??
        false;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: booking.packageImageUrl.isNotEmpty ? 220 : 0,
            pinned: true,
            backgroundColor: AppColors.primaryBlue,
            leading: Padding(
              padding: const EdgeInsets.all(8),
              child: CircleAvatar(
                backgroundColor: Colors.white,
                child: IconButton(
                  icon: const Icon(Icons.arrow_back, color: AppColors.textDark, size: 20),
                  onPressed: () => context.pop(),
                ),
              ),
            ),
            flexibleSpace: booking.packageImageUrl.isNotEmpty
                ? FlexibleSpaceBar(
                    background: CachedNetworkImage(
                      imageUrl: booking.packageImageUrl,
                      fit: BoxFit.cover,
                      errorWidget: (_, __, ___) => Container(
                        color: AppColors.primaryBlue.withOpacity(0.3),
                      ),
                    ),
                  )
                : null,
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title + status
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Text(
                          booking.packageTitle,
                          style: GoogleFonts.poppins(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: AppColors.textDark,
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: _statusColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          booking.status.replaceAll('_', ' '),
                          style: GoogleFonts.poppins(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: _statusColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(Icons.location_on, size: 14, color: AppColors.primaryBlue),
                      const SizedBox(width: 4),
                      Text(
                        booking.packageLocation,
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          color: AppColors.greySecondary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // Booking info card
                  _InfoCard(
                    children: [
                      _InfoRow(Icons.confirmation_number_outlined, 'Booking ID',
                          booking.bookingId.substring(0, 8).toUpperCase()),
                      _InfoRow(Icons.calendar_today_outlined, 'Travel Date', booking.dateOfTravel),
                      _InfoRow(Icons.people_outline, 'Travelers', '${booking.membersCount} person(s)'),
                      _InfoRow(Icons.nights_stay_outlined, 'Duration',
                          '${booking.days} days / ${booking.nights} nights'),
                      _InfoRow(Icons.currency_rupee, 'Total Amount', '₹${booking.totalPrice}',
                          valueColor: AppColors.actionOrange),
                    ],
                  ),

                  const SizedBox(height: 20),

                  // Pricing breakdown
                  _InfoCard(
                    title: 'Pricing Breakdown',
                    children: [
                      _InfoRow(Icons.person_outline, 'Per Person',
                          '₹${booking.pricingSnapshot['price_per_person'] ?? '-'}'),
                      _InfoRow(Icons.people_outline, 'Members',
                          '${booking.pricingSnapshot['members_count'] ?? '-'}'),
                      _InfoRow(Icons.currency_rupee, 'Total',
                          '₹${booking.pricingSnapshot['total_price'] ?? booking.totalPrice}',
                          valueColor: AppColors.actionOrange),
                    ],
                  ),

                  const SizedBox(height: 24),

                  // Cancel button
                  if (booking.status == 'CONFIRMED') ...[
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: () => _confirmCancel(context, ref),
                        icon: const Icon(Icons.cancel_outlined, size: 18),
                        label: Text(
                          'Cancel Booking',
                          style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
                        ),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.red,
                          side: const BorderSide(color: Colors.red),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                      ),
                    ),
                  ],

                  // Write review button
                  if (booking.status == 'COMPLETED' && !alreadyReviewed) ...[
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () {
                          showModalBottomSheet(
                            context: context,
                            isScrollControlled: true,
                            backgroundColor: Colors.transparent,
                            builder: (_) => WriteReviewSheet(
                              bookingId: booking.bookingId,
                              packageTitle: booking.packageTitle,
                              onSuccess: () {
                                ref.invalidate(myReviewsProvider);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Review submitted!'),
                                    backgroundColor: Colors.green,
                                  ),
                                );
                              },
                            ),
                          );
                        },
                        icon: const Icon(Icons.star_rounded, size: 18),
                        label: Text(
                          'Write a Review',
                          style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.actionOrange,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                          elevation: 0,
                        ),
                      ),
                    ),
                  ],

                  if (booking.status == 'COMPLETED' && alreadyReviewed) ...[
                    Row(
                      children: [
                        const Icon(Icons.check_circle, size: 16, color: Colors.green),
                        const SizedBox(width: 6),
                        Text(
                          'You have reviewed this trip',
                          style: GoogleFonts.poppins(
                            fontSize: 13,
                            color: Colors.green,
                          ),
                        ),
                      ],
                    ),
                  ],

                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _confirmCancel(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Cancel Booking', style: GoogleFonts.poppins(fontWeight: FontWeight.bold)),
        content: Text(
          'Are you sure you want to cancel this booking?',
          style: GoogleFonts.poppins(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text('No', style: GoogleFonts.poppins()),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(ctx);
              await ref.read(bookingCreationProvider.notifier).cancelBooking(booking.bookingId);
              ref.invalidate(userBookingsProvider);
              if (context.mounted) context.pop();
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: Text('Yes, Cancel', style: GoogleFonts.poppins(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String? title;
  final List<Widget> children;
  const _InfoCard({this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (title != null) ...[
            Text(
              title!,
              style: GoogleFonts.poppins(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: AppColors.textDark,
              ),
            ),
            const Divider(height: 20),
          ],
          ...children,
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color? valueColor;
  const _InfoRow(this.icon, this.label, this.value, {this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, size: 16, color: AppColors.primaryBlue),
          const SizedBox(width: 10),
          Text(
            label,
            style: GoogleFonts.poppins(fontSize: 13, color: AppColors.greySecondary),
          ),
          const Spacer(),
          Text(
            value,
            style: GoogleFonts.poppins(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: valueColor ?? AppColors.textDark,
            ),
          ),
        ],
      ),
    );
  }
}
