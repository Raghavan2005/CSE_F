import 'package:dio/dio.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class PackageDataSource {
  static final Dio _dio = Dio(
    BaseOptions(
      baseUrl: dotenv.get('PACKAGE_SERVICE_URL', fallback: 'http://10.0.2.2:8002'),
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
      headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
    ),
  );

  Future<List<Map<String, dynamic>>> getPackages({
    String? location,
    double? minPrice,
    double? maxPrice,
    String? vendorId,
  }) async {
    final queryParams = <String, dynamic>{};
    if (location != null && location.isNotEmpty) queryParams['location'] = location;
    if (minPrice != null) queryParams['min_price'] = minPrice;
    if (maxPrice != null) queryParams['max_price'] = maxPrice;
    if (vendorId != null && vendorId.isNotEmpty) queryParams['vendor_id'] = vendorId;

    final response = await _dio.get('/api/package/packages', queryParameters: queryParams);
    final data = response.data;

    if (data is List) return List<Map<String, dynamic>>.from(data);
    if (data is Map && data['results'] is List) {
      return List<Map<String, dynamic>>.from(data['results']);
    }
    return [];
  }

  Future<Map<String, dynamic>> getPackage(String packageId) async {
    final response = await _dio.get('/api/package/packages/$packageId');
    return Map<String, dynamic>.from(response.data);
  }

  Future<List<Map<String, dynamic>>> getBanners() async {
    final response = await _dio.get('/api/package/banners/');
    return List<Map<String, dynamic>>.from(response.data);
  }

  Future<List<Map<String, dynamic>>> getCategories() async {
    final response = await _dio.get('/api/package/categories/');
    return List<Map<String, dynamic>>.from(response.data);
  }

  Future<List<Map<String, dynamic>>> getDestinations() async {
    final response = await _dio.get('/api/package/destinations/');
    return List<Map<String, dynamic>>.from(response.data);
  }

  Future<Map<String, dynamic>> getPromoBanner() async {
    final response = await _dio.get('/api/package/promo-banner/');
    return Map<String, dynamic>.from(response.data);
  }

  Future<List<Map<String, dynamic>>> getArticles() async {
    final response = await _dio.get('/api/package/articles/');
    return List<Map<String, dynamic>>.from(response.data);
  }
}
