import 'package:code/features/discovery/data/datasources/package_data_source.dart';
import 'package:code/features/discovery/domain/entities/banner_item.dart';
import 'package:code/features/discovery/domain/entities/destination.dart';
import 'package:code/features/discovery/domain/entities/travel_article.dart';
import 'package:code/features/discovery/domain/entities/trip.dart';

class PackageRepository {
  final PackageDataSource _dataSource;

  PackageRepository({PackageDataSource? dataSource})
      : _dataSource = dataSource ?? PackageDataSource();

  Future<List<Trip>> getPackages({String? location, double? minPrice, double? maxPrice}) async {
    final raw = await _dataSource.getPackages(
      location: location,
      minPrice: minPrice,
      maxPrice: maxPrice,
    );
    return raw.map((json) => Trip.fromApi(json)).toList();
  }

  Future<Trip> getPackage(String packageId) async {
    final raw = await _dataSource.getPackage(packageId);
    return Trip.fromApi(raw);
  }

  Future<List<Trip>> getPackagesByVendor(String vendorId) async {
    final raw = await _dataSource.getPackages(vendorId: vendorId);
    return raw.map((json) => Trip.fromApi(json)).toList();
  }

  Future<List<BannerItem>> getBanners() async {
    final raw = await _dataSource.getBanners();
    return raw.map((json) => BannerItem.fromJson(json)).toList();
  }

  Future<List<Category>> getCategories() async {
    final raw = await _dataSource.getCategories();
    return raw.map((json) => Category.fromJson(json)).toList();
  }

  Future<List<Destination>> getDestinations() async {
    final raw = await _dataSource.getDestinations();
    return raw.map((json) => Destination.fromJson(json)).toList();
  }

  Future<Map<String, dynamic>> getPromoBanner() async {
    return _dataSource.getPromoBanner();
  }

  Future<List<TravelArticle>> getArticles() async {
    final raw = await _dataSource.getArticles();
    return raw.map((json) => TravelArticle.fromJson(json)).toList();
  }
}