class BannerItem {
  final String id;
  final String title;
  final String subtitle;
  final String imageUrl;
  final String? ctaText;

  BannerItem({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.imageUrl,
    this.ctaText,
  });

  factory BannerItem.fromJson(Map<String, dynamic> json) => BannerItem(
        id: json['id'].toString(),
        title: json['title'] ?? '',
        subtitle: json['subtitle'] ?? '',
        imageUrl: json['image_url'] ?? '',
      );
}
