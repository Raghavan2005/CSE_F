class Destination {
  final String id;
  final String name;
  final String imageUrl;
  final String tripCount;

  Destination({
    required this.id,
    required this.name,
    required this.imageUrl,
    required this.tripCount,
  });

  factory Destination.fromJson(Map<String, dynamic> json) => Destination(
        id: json['id'].toString(),
        name: json['name'] ?? '',
        imageUrl: json['image_url'] ?? '',
        tripCount: json['trip_count_label'] ?? '',
      );
}
