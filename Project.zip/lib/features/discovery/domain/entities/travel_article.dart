class TravelArticle {
  final String id;
  final String title;
  final String snippet;
  final String imageUrl;
  final String readTime;
  final String author;
  final String content;

  TravelArticle({
    required this.id,
    required this.title,
    required this.snippet,
    required this.imageUrl,
    required this.readTime,
    required this.author,
    required this.content,
  });

  factory TravelArticle.fromJson(Map<String, dynamic> json) => TravelArticle(
        id: json['id'].toString(),
        title: json['title'] ?? '',
        snippet: json['snippet'] ?? '',
        imageUrl: json['image_url'] ?? '',
        readTime: json['read_time'] ?? '',
        author: json['author'] ?? '',
        content: json['content'] ?? '',
      );
}
