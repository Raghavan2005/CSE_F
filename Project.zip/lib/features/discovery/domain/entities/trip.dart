class Trip {
  final String id;
  final String title;
  final String location;
  final String description;
  final String price;
  final double pricePerPerson;
  final String rating;
  final String imageUrl;
  final String category;
  final bool isTrending;
  final int days;
  final int nights;

  Trip({
    required this.id,
    required this.title,
    required this.location,
    this.description = '',
    required this.price,
    this.pricePerPerson = 0.0,
    required this.rating,
    required this.imageUrl,
    this.category = '',
    this.isTrending = false,
    this.days = 0,
    this.nights = 0,
  });

  factory Trip.fromApi(Map<String, dynamic> json) {
    final pricePerPerson = double.tryParse(json['price_per_person'].toString()) ?? 0.0;
    final ratingAvg = (json['rating_avg'] ?? 0.0) as num;

    return Trip(
      id: json['id'].toString(),
      title: json['title'] ?? '',
      location: json['location'] ?? '',
      description: json['description'] ?? '',
      price: _formatPrice(pricePerPerson),
      pricePerPerson: pricePerPerson,
      rating: ratingAvg.toStringAsFixed(1),
      imageUrl: json['cover_image_url'] ?? '',
      days: json['days'] ?? 0,
      nights: json['nights'] ?? 0,
    );
  }

  static String _formatPrice(double price) {
    if (price >= 100000) {
      return '${(price / 100000).toStringAsFixed(1)}L';
    } else if (price >= 1000) {
      final thousands = price ~/ 1000;
      final remainder = (price % 1000).toInt();
      if (remainder == 0) return '${thousands}K';
      return '${thousands},${remainder.toString().padLeft(3, '0')}';
    }
    return price.toStringAsFixed(0);
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'location': location,
        'description': description,
        'category': category,
        'price': price,
        'pricePerPerson': pricePerPerson,
        'rating': rating,
        'imageUrl': imageUrl,
        'isTrending': isTrending,
        'days': days,
        'nights': nights,
      };

  factory Trip.fromJson(Map<String, dynamic> json) => Trip(
        id: json['id'],
        title: json['title'],
        location: json['location'],
        description: json['description'] ?? '',
        price: json['price'],
        pricePerPerson: (json['pricePerPerson'] ?? 0.0).toDouble(),
        rating: json['rating'],
        imageUrl: json['imageUrl'],
        category: json['category'] ?? '',
        isTrending: json['isTrending'] ?? false,
        days: json['days'] ?? 0,
        nights: json['nights'] ?? 0,
      );
}

class Category {
  final String id;
  final String name;

  Category({required this.id, required this.name});

  factory Category.fromJson(Map<String, dynamic> json) => Category(
        id: json['id'].toString(),
        name: json['name'] ?? '',
      );
}
