import 'package:code/features/discovery/data/repositories/package_repository.dart';
import 'package:code/features/discovery/domain/entities/banner_item.dart';
import 'package:code/features/discovery/domain/entities/destination.dart';
import 'package:code/features/discovery/domain/entities/travel_article.dart';
import 'package:code/features/discovery/domain/entities/trip.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

final packageRepositoryProvider = Provider<PackageRepository>(
  (ref) => PackageRepository(),
);

/// All packages from the API
final packagesProvider = FutureProvider<List<Trip>>((ref) async {
  return ref.read(packageRepositoryProvider).getPackages();
});

/// Single package by ID
final packageDetailProvider =
    FutureProvider.family<Trip, String>((ref, packageId) async {
  return ref.read(packageRepositoryProvider).getPackage(packageId);
});

final bannersProvider = FutureProvider<List<BannerItem>>((ref) async {
  return ref.read(packageRepositoryProvider).getBanners();
});

final categoriesProvider = FutureProvider<List<Category>>((ref) async {
  return ref.read(packageRepositoryProvider).getCategories();
});

final destinationsProvider = FutureProvider<List<Destination>>((ref) async {
  return ref.read(packageRepositoryProvider).getDestinations();
});

final promoBannerProvider = FutureProvider<Map<String, dynamic>>((ref) async {
  return ref.read(packageRepositoryProvider).getPromoBanner();
});

final articlesProvider = FutureProvider<List<TravelArticle>>((ref) async {
  return ref.read(packageRepositoryProvider).getArticles();
});
