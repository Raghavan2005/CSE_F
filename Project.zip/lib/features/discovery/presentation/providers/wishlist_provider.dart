import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:code/features/discovery/domain/entities/trip.dart';
import 'package:code/core/services/storage_service.dart';

final wishlistProvider = StateNotifierProvider<WishlistNotifier, List<Trip>>((ref) {
  return WishlistNotifier();
});

class WishlistNotifier extends StateNotifier<List<Trip>> {
  WishlistNotifier() : super([]) {
    _loadWishlist();
  }

  Future<void> _loadWishlist() async {
    state = await StorageService.loadWishlist();
  }

  void toggleWishlist(Trip trip) {
    if (state.any((t) => t.id == trip.id)) {
      state = state.where((t) => t.id != trip.id).toList();
    } else {
      state = [...state, trip];
    }
    StorageService.saveWishlist(state);
  }

  bool isFavorite(String tripId) {
    return state.any((t) => t.id == tripId);
  }
}
