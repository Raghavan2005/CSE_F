import 'package:cached_network_image/cached_network_image.dart';
import 'package:code/core/themes/app_colors.dart';
import 'package:code/core/widgets/app_button.dart';
import 'package:code/features/booking/presentation/providers/booking_provider.dart';
import 'package:code/features/discovery/domain/entities/trip.dart';
import 'package:code/features/discovery/presentation/providers/discovery_provider.dart';
import 'package:code/features/discovery/presentation/providers/wishlist_provider.dart';
import 'package:code/features/review/presentation/widgets/package_reviews_list.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:intl/intl.dart';

class TripDetailsScreen extends ConsumerWidget {
  final String tripId;

  const TripDetailsScreen({super.key, required this.tripId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tripAsync = ref.watch(packageDetailProvider(tripId));

    return tripAsync.when(
      loading: () => const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (e, _) => Scaffold(body: Center(child: Text('Failed to load package: $e'))),
      data: (trip) => _TripDetailsBody(trip: trip),
    );
  }
}

class _TripDetailsBody extends HookConsumerWidget {
  final Trip trip;
  const _TripDetailsBody({required this.trip});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      body: Stack(
        children: [
          CustomScrollView(
            slivers: [
              SliverAppBar(
                expandedHeight: 400,
                pinned: true,
                backgroundColor: AppColors.primaryBlue,
                leading: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: CircleAvatar(
                    backgroundColor: Colors.white,
                    child: IconButton(
                      icon: const Icon(
                        Icons.arrow_back,
                        color: AppColors.textDark,
                      ),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ),
                ),
                actions: [
                  IconButton(
                    icon: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: const BoxDecoration(
                        color: Colors.white24,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        ref.watch(wishlistProvider).any((t) => t.id == trip.id)
                            ? Icons.favorite_rounded
                            : Icons.favorite_border_rounded,
                        color:
                            ref
                                .watch(wishlistProvider)
                                .any((t) => t.id == trip.id)
                            ? Colors.red
                            : Colors.white,
                        size: 20,
                      ),
                    ),
                    onPressed: () => ref
                        .read(wishlistProvider.notifier)
                        .toggleWishlist(trip),
                  ),
                  const SizedBox(width: 8),
                ],
                flexibleSpace: FlexibleSpaceBar(
                  background: CachedNetworkImage(
                    imageUrl: trip.imageUrl,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  trip.title,
                                  style: GoogleFonts.poppins(
                                    fontSize: 26,
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.textDark,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.location_on,
                                      size: 16,
                                      color: AppColors.primaryBlue,
                                    ),
                                    const SizedBox(width: 4),
                                    Text(
                                      trip.location,
                                      style: GoogleFonts.poppins(
                                        color: AppColors.greySecondary,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: AppColors.actionOrange.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Row(
                              children: [
                                const Icon(
                                  Icons.star,
                                  color: AppColors.actionOrange,
                                  size: 20,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  trip.rating,
                                  style: GoogleFonts.poppins(
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.actionOrange,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),
                      Text(
                        'About Destination',
                        style: GoogleFonts.poppins(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textDark,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        trip.description.isNotEmpty
                            ? trip.description
                            : 'Experience the breathtaking beauty of ${trip.location}. This curated package offers a perfect blend of relaxation and adventure.',
                        style: GoogleFonts.poppins(
                          fontSize: 15,
                          color: AppColors.greySecondary,
                          height: 1.6,
                        ),
                      ),
                      const SizedBox(height: 24),
                      Text(
                        'Package Includes',
                        style: GoogleFonts.poppins(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textDark,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _buildInclusionItem(Icons.hotel_outlined, 'Hotel'),
                          _buildInclusionItem(
                            Icons.restaurant_outlined,
                            'Food',
                          ),
                          _buildInclusionItem(
                            Icons.directions_car_outlined,
                            'Transport',
                          ),
                          _buildInclusionItem(
                            Icons.camera_alt_outlined,
                            'Tours',
                          ),
                        ],
                      ),
                      const SizedBox(height: 32),
                      Text(
                        'Traveler Reviews',
                        style: GoogleFonts.poppins(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textDark,
                        ),
                      ),
                      const SizedBox(height: 12),
                      PackageReviewsList(packageId: trip.id),
                      const SizedBox(height: 100), // Space for bottom bar
                    ],
                  ),
                ),
              ),
            ],
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 20,
                    offset: const Offset(0, -5),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Price starts at',
                        style: GoogleFonts.poppins(
                          fontSize: 12,
                          color: AppColors.greySecondary,
                        ),
                      ),
                      Text(
                        '₹${trip.price}',
                        style: GoogleFonts.poppins(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: AppColors.actionOrange,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(width: 24),
                  Expanded(
                    child: AppButton(
                      text: 'Book Now',
                      onPressed: () => _showBookingModal(context, ref, trip),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInclusionItem(IconData icon, String label) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.grey.shade100,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: AppColors.primaryBlue),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: GoogleFonts.poppins(fontSize: 12, color: AppColors.textDark),
        ),
      ],
    );
  }

  void _showBookingModal(BuildContext context, WidgetRef ref, Trip trip) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _BookingModal(trip: trip),
    );
  }
}

class _BookingModal extends HookConsumerWidget {
  final Trip trip;
  const _BookingModal({required this.trip});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedDate = useState<DateTime?>(null);
    final membersCount = useState(1);
    final isLoading = useState(false);
    final errorMsg = useState<String?>(null);

    final dateLabel = selectedDate.value != null
        ? DateFormat('dd MMM yyyy').format(selectedDate.value!)
        : 'Select Date';

    final totalPrice = trip.pricePerPerson > 0
        ? (trip.pricePerPerson * membersCount.value)
        : 0.0;

    final formattedTotal = totalPrice > 0 ? '₹${_formatPrice(totalPrice)}' : '₹${trip.price}';

    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Booking Details',
              style: GoogleFonts.poppins(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: AppColors.textDark,
              ),
            ),
            const SizedBox(height: 24),
            // Date Picker Row
            GestureDetector(
              onTap: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now().add(const Duration(days: 1)),
                  firstDate: DateTime.now().add(const Duration(days: 1)),
                  lastDate: DateTime.now().add(const Duration(days: 365)),
                );
                if (picked != null) selectedDate.value = picked;
              },
              child: _buildSelectionBox(
                'Travel Date',
                dateLabel,
                Icons.calendar_today_rounded,
              ),
            ),
            const SizedBox(height: 16),
            // Members Count Row
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey.shade50,
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: Colors.grey.shade200),
              ),
              child: Row(
                children: [
                  const Icon(Icons.people_outline_rounded, color: AppColors.primaryBlue),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      'Travelers',
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                        color: AppColors.greySecondary,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.remove_circle_outline, color: AppColors.primaryBlue),
                    onPressed: membersCount.value > 1
                        ? () => membersCount.value--
                        : null,
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Text(
                      '${membersCount.value}',
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textDark,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.add_circle_outline, color: AppColors.primaryBlue),
                    onPressed: membersCount.value < 20
                        ? () => membersCount.value++
                        : null,
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Total Amount',
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    color: AppColors.greySecondary,
                  ),
                ),
                Text(
                  formattedTotal,
                  style: GoogleFonts.poppins(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: AppColors.actionOrange,
                  ),
                ),
              ],
            ),
            if (errorMsg.value != null) ...[
              const SizedBox(height: 12),
              Text(
                errorMsg.value!,
                style: GoogleFonts.poppins(color: Colors.red, fontSize: 13),
              ),
            ],
            const SizedBox(height: 24),
            AppButton(
              text: 'Confirm & Pay',
              isLoading: isLoading.value,
              onPressed: () async {
                if (isLoading.value) return;
                      if (selectedDate.value == null) {
                        errorMsg.value = 'Please select a travel date.';
                        return;
                      }
                      errorMsg.value = null;
                      isLoading.value = true;

                      final dateStr = DateFormat('yyyy-MM-dd').format(selectedDate.value!);
                      final booking = await ref
                          .read(bookingCreationProvider.notifier)
                          .createBooking(
                            packageId: trip.id,
                            dateOfTravel: dateStr,
                            membersCount: membersCount.value,
                          );

                      isLoading.value = false;

                      if (booking != null && context.mounted) {
                        ref.invalidate(userBookingsProvider);
                        Navigator.pop(context);
                        GoRouter.of(context).push('/booking-success');
                      } else if (context.mounted) {
                        final err = ref.read(bookingCreationProvider).error;
                        errorMsg.value = err?.toString() ?? 'Booking failed. Please try again.';
                      }
                    },
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildSelectionBox(String title, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        children: [
          Icon(icon, color: AppColors.primaryBlue),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.poppins(
                  fontSize: 12,
                  color: AppColors.greySecondary,
                ),
              ),
              Text(
                value,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textDark,
                ),
              ),
            ],
          ),
          const Spacer(),
          const Icon(
            Icons.keyboard_arrow_down_rounded,
            color: AppColors.greySecondary,
          ),
        ],
      ),
    );
  }

  static String _formatPrice(double price) {
    if (price >= 100000) {
      return '${(price / 100000).toStringAsFixed(1)}L';
    } else if (price >= 1000) {
      final thousands = price ~/ 1000;
      final remainder = (price % 1000).toInt();
      if (remainder == 0) return '${thousands}K';
      return '${thousands},${remainder.toString().padLeft(3, '0')}';
    }
    return price.toStringAsFixed(0);
  }
}
