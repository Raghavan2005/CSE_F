import 'package:cached_network_image/cached_network_image.dart';
import 'package:code/core/providers/navigation_provider.dart';
import 'package:code/core/providers/theme_provider.dart';
import 'package:code/core/themes/app_colors.dart';
import 'package:code/features/booking/domain/entities/booking.dart';
import 'package:code/features/booking/presentation/providers/booking_provider.dart';
import 'package:code/features/booking/presentation/screens/booking_detail_screen.dart';
import 'package:code/features/review/presentation/providers/review_provider.dart';
import 'package:code/features/review/presentation/widgets/write_review_sheet.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class BookingsTab extends ConsumerWidget {
  const BookingsTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final bookingsAsync = ref.watch(userBookingsProvider);
    final isDarkMode = ref.watch(themeProvider) == ThemeMode.dark;

    return Scaffold(
      backgroundColor: isDarkMode
          ? AppColors.backgroundDark
          : AppColors.backgroundLight,
      appBar: AppBar(
        title: Text(
          'My Bookings',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: isDarkMode ? AppColors.textLight : AppColors.textDark,
          ),
        ),
        backgroundColor: isDarkMode ? AppColors.backgroundDark : Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            color: isDarkMode ? AppColors.textLight : AppColors.textDark,
            onPressed: () => ref.invalidate(userBookingsProvider),
          ),
        ],
      ),
      body: bookingsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 48, color: AppColors.greySecondary),
              const SizedBox(height: 12),
              Text(
                'Failed to load bookings',
                style: GoogleFonts.poppins(color: AppColors.greySecondary),
              ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: () => ref.invalidate(userBookingsProvider),
                child: Text(
                  'Retry',
                  style: GoogleFonts.poppins(color: AppColors.primaryBlue),
                ),
              ),
            ],
          ),
        ),
        data: (bookings) => bookings.isEmpty
            ? _EmptyBookings(isDarkMode: isDarkMode)
            : ListView.builder(
                padding: const EdgeInsets.all(24),
                itemCount: bookings.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 20),
                    child: _BookingCard(booking: bookings[index], isDarkMode: isDarkMode),
                  );
                },
              ),
      ),
    );
  }
}

class _BookingCard extends ConsumerWidget {
  final Booking booking;
  final bool isDarkMode;

  const _BookingCard({required this.booking, required this.isDarkMode});

  Color get _statusColor {
    switch (booking.status) {
      case 'CONFIRMED':
        return Colors.green;
      case 'COMPLETED':
        return AppColors.primaryBlue;
      case 'CANCELLED':
      case 'EXPIRED':
        return Colors.red;
      case 'PAYMENT_FAILED':
        return Colors.orange;
      default:
        return AppColors.greySecondary;
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final myReviews = ref.watch(myReviewsProvider);
    final alreadyReviewed = myReviews.valueOrNull
            ?.any((r) => r.bookingId == booking.bookingId) ??
        false;

    return InkWell(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => BookingDetailScreen(booking: booking),
        ),
      ),
      borderRadius: BorderRadius.circular(20),
      child: Container(
      decoration: BoxDecoration(
        color: isDarkMode ? AppColors.cardDark : Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(isDarkMode ? 0.2 : 0.06),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (booking.packageImageUrl.isNotEmpty)
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              child: CachedNetworkImage(
                imageUrl: booking.packageImageUrl,
                height: 160,
                width: double.infinity,
                fit: BoxFit.cover,
                errorWidget: (_, __, ___) => Container(
                  height: 160,
                  color: AppColors.primaryBlue.withOpacity(0.1),
                  child: const Icon(Icons.landscape, color: AppColors.primaryBlue, size: 48),
                ),
              ),
            ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        booking.packageTitle,
                        style: GoogleFonts.poppins(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: isDarkMode ? AppColors.textLight : AppColors.textDark,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: _statusColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        booking.status.replaceAll('_', ' '),
                        style: GoogleFonts.poppins(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: _statusColor,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    const Icon(Icons.location_on, size: 14, color: AppColors.primaryBlue),
                    const SizedBox(width: 4),
                    Text(
                      booking.packageLocation,
                      style: GoogleFonts.poppins(
                        fontSize: 13,
                        color: AppColors.greySecondary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    _infoChip(Icons.calendar_today_outlined, booking.dateOfTravel),
                    const SizedBox(width: 12),
                    _infoChip(Icons.people_outline, '${booking.membersCount} travelers'),
                    const SizedBox(width: 12),
                    _infoChip(
                      Icons.currency_rupee,
                      booking.totalPrice,
                      color: AppColors.actionOrange,
                    ),
                  ],
                ),
                if (booking.status == 'COMPLETED' && !alreadyReviewed) ...[
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () {
                        showModalBottomSheet(
                          context: context,
                          isScrollControlled: true,
                          backgroundColor: Colors.transparent,
                          builder: (_) => WriteReviewSheet(
                            bookingId: booking.bookingId,
                            packageTitle: booking.packageTitle,
                            onSuccess: () {
                              ref.invalidate(myReviewsProvider);
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Review submitted!'),
                                  backgroundColor: Colors.green,
                                ),
                              );
                            },
                          ),
                        );
                      },
                      icon: const Icon(Icons.star_outline_rounded, size: 16),
                      label: Text(
                        'Write a Review',
                        style: GoogleFonts.poppins(fontSize: 13, fontWeight: FontWeight.w500),
                      ),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppColors.actionOrange,
                        side: const BorderSide(color: AppColors.actionOrange),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 8),
                      ),
                    ),
                  ),
                ],
                if (booking.status == 'COMPLETED' && alreadyReviewed) ...[
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.check_circle, size: 14, color: Colors.green),
                      const SizedBox(width: 4),
                      Text(
                        'Review submitted',
                        style: GoogleFonts.poppins(
                          fontSize: 12,
                          color: Colors.green,
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    ),
    );
  }

  Widget _infoChip(IconData icon, String label, {Color? color}) {
    final c = color ?? AppColors.greySecondary;
    return Row(
      children: [
        Icon(icon, size: 13, color: c),
        const SizedBox(width: 3),
        Text(
          label,
          style: GoogleFonts.poppins(fontSize: 12, color: c),
        ),
      ],
    );
  }
}

class _EmptyBookings extends ConsumerWidget {
  final bool isDarkMode;
  const _EmptyBookings({required this.isDarkMode});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Center(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 40),
            Icon(
              Icons.confirmation_num_outlined,
              size: 64,
              color: AppColors.primaryBlue.withOpacity(0.5),
            ),
            const SizedBox(height: 16),
            Text(
              'No bookings yet',
              style: GoogleFonts.poppins(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: isDarkMode ? AppColors.textLight : AppColors.textDark,
              ),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                'Your next adventure is just a few clicks away. Explore our curated trips and start planning!',
                textAlign: TextAlign.center,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  color: AppColors.greySecondary,
                ),
              ),
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                ref.read(navigationProvider.notifier).state = 0;
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBlue,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 0,
              ),
              child: Text(
                'Explore Destinations',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}
