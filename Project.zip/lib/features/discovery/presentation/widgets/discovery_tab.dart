import 'package:code/core/providers/navigation_provider.dart';
import 'package:code/core/providers/theme_provider.dart';
import 'package:code/core/themes/app_colors.dart';
import 'package:code/core/widgets/category_chip.dart';
import 'package:code/core/widgets/trip_card.dart';
import 'package:code/features/discovery/presentation/providers/discovery_provider.dart';
import 'package:code/features/discovery/presentation/providers/wishlist_provider.dart';
import 'package:code/features/discovery/presentation/widgets/home_banner_slider.dart';
import 'package:code/features/discovery/presentation/widgets/popular_destinations_slider.dart';
import 'package:code/features/discovery/presentation/widgets/travel_tips_list.dart';
import 'package:code/features/discovery/presentation/widgets/trending_now_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class DiscoveryTab extends HookConsumerWidget {
  const DiscoveryTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedCategory = useState('All');
    final searchQuery = useState('');
    final isDarkMode = ref.watch(themeProvider) == ThemeMode.dark;

    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.all(24.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Hello, Explorer!',
                          style: GoogleFonts.poppins(
                            fontSize: 16,
                            color: AppColors.greySecondary,
                          ),
                        ),
                        Text(
                          'Where to next?',
                          style: GoogleFonts.poppins(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: isDarkMode
                                ? AppColors.textLight
                                : AppColors.textDark,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                      color: isDarkMode ? AppColors.cardDark : Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(
                            isDarkMode ? 0.2 : 0.05,
                          ),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: IconButton(
                      onPressed: () => context.push('/notifications'),
                      icon: Icon(
                        Icons.notifications_none_rounded,
                        color: isDarkMode
                            ? AppColors.textLight
                            : AppColors.textDark,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Search Bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: Hero(
                tag: 'search_bar',
                child: Material(
                  color: Colors.transparent,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: isDarkMode ? AppColors.cardDark : Colors.white,
                      borderRadius: BorderRadius.circular(15),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.02),
                          blurRadius: 10,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: TextField(
                      style: GoogleFonts.poppins(
                        color: isDarkMode
                            ? AppColors.textLight
                            : AppColors.textDark,
                      ),
                      readOnly: true,
                      onTap: () {
                        // Navigate to Travel/Search Tab (index 1)
                        ref.read(navigationProvider.notifier).state = 1;
                      },
                      decoration: InputDecoration(
                        hintText: 'Search destinations...',
                        border: InputBorder.none,
                        icon: const Icon(
                          Icons.search,
                          color: AppColors.greySecondary,
                        ),
                        hintStyle: GoogleFonts.poppins(
                          color: AppColors.greySecondary,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Quick Actions Row
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: Row(
                children: [
                  Expanded(
                    child: _QuickActionChip(
                      icon: Icons.store_rounded,
                      label: 'Browse Agencies',
                      onTap: () => context.push('/vendors'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _QuickActionChip(
                      icon: Icons.confirmation_num_outlined,
                      label: 'My Bookings',
                      onTap: () => ref.read(navigationProvider.notifier).state = 2,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Banner Slider
            if (searchQuery.value.isEmpty) ...[
              ref.watch(bannersProvider).when(
                data: (banners) => banners.isEmpty
                    ? const SizedBox()
                    : HomeBannerSlider(banners: banners),
                loading: () => const SizedBox(
                  height: 200,
                  child: Center(child: CircularProgressIndicator()),
                ),
                error: (_, __) => const SizedBox(),
              ),
              const SizedBox(height: 24),
            ],

            // Categories
            ref.watch(categoriesProvider).when(
              data: (categories) {
                final cats = categories.isEmpty ? <dynamic>[] : categories;
                return SizedBox(
                  height: 45,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    itemCount: cats.length,
                    itemBuilder: (context, index) {
                      final category = cats[index];
                      return Padding(
                        padding: const EdgeInsets.only(right: 12),
                        child: CategoryChip(
                          label: category.name,
                          isSelected: selectedCategory.value == category.name,
                          onTap: () => selectedCategory.value = category.name,
                        ),
                      );
                    },
                  ),
                );
              },
              loading: () => const SizedBox(height: 45),
              error: (_, __) => const SizedBox(height: 45),
            ),

            const SizedBox(height: 32),

            // Popular Destinations
            if (selectedCategory.value == 'All' &&
                searchQuery.value.isEmpty) ...[
              const PopularDestinationsSlider(),
              const SizedBox(height: 32),
            ],

            const SizedBox(height: 32),

            // Trending Now Section (Modular)
            TrendingNowSlider(
              selectedCategory: selectedCategory.value,
              searchQuery: searchQuery.value,
            ),

            const SizedBox(height: 32),

            // Promo Banner
            ref.watch(promoBannerProvider).when(
              data: (data) {
                if (data['active'] == false) return const SizedBox();
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.08),
                          blurRadius: 10,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Stack(
                        children: [
                          Image.network(
                            data['image_url'] ?? '',
                            height: 100,
                            width: double.infinity,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) =>
                                Container(
                              color: AppColors.primaryBlue,
                              height: 100,
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.black.withOpacity(0.6),
                                  Colors.transparent,
                                ],
                                begin: Alignment.bottomRight,
                                end: Alignment.topLeft,
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  data['title'] ?? '',
                                  style: GoogleFonts.poppins(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                Text(
                                  data['subtitle'] ?? '',
                                  style: GoogleFonts.poppins(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
              loading: () => const SizedBox(),
              error: (_, __) => const SizedBox(),
            ),

            const SizedBox(height: 32),

            // Recommended Section
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: Text(
                'Recommended for You',
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: isDarkMode ? AppColors.textLight : AppColors.textDark,
                ),
              ),
            ),

            const SizedBox(height: 16),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: ref.watch(packagesProvider).when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (_, __) => const Center(child: Text('Failed to load packages')),
                data: (trips) {
                  final filtered = trips.where((t) {
                    final matchesCategory = selectedCategory.value == 'All' ||
                        t.location.toLowerCase().contains(selectedCategory.value.toLowerCase());
                    final matchesSearch = searchQuery.value.isEmpty ||
                        t.title.toLowerCase().contains(searchQuery.value.toLowerCase()) ||
                        t.location.toLowerCase().contains(searchQuery.value.toLowerCase());
                    return matchesCategory && matchesSearch;
                  }).skip(5).toList();

                  return ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: filtered.length,
                    itemBuilder: (context, index) {
                      final trip = filtered[index];
                      final isFavorite = ref.watch(wishlistProvider).any((t) => t.id == trip.id);
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 20),
                        child: TripCard(
                          title: trip.title,
                          location: trip.location,
                          price: trip.price,
                          rating: trip.rating,
                          imageUrl: trip.imageUrl,
                          isFavorite: isFavorite,
                          onTap: () => context.push('/trip-details/${trip.id}'),
                          onFavoriteTap: () => ref.read(wishlistProvider.notifier).toggleWishlist(trip),
                        ),
                      );
                    },
                  );
                },
              ),
            ),

            const SizedBox(height: 32),

            // Travel Articles (Modular)
            if (selectedCategory.value == 'All' &&
                searchQuery.value.isEmpty) ...[
              const TravelTipsList(),
            ],

            const SizedBox(height: 60),

            // Footer Section
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      vertical: 20,
                      horizontal: 24,
                    ),
                    decoration: BoxDecoration(
                      color: isDarkMode
                          ? AppColors.cardDark
                          : AppColors.primaryBlue.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Column(
                      children: [
                        const Icon(
                          Icons.verified_user_rounded,
                          color: AppColors.actionOrange,
                          size: 32,
                        ),
                        const SizedBox(height: 12),
                        Text(
                          'You are in safe hands',
                          style: GoogleFonts.poppins(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: isDarkMode
                                ? AppColors.textLight
                                : AppColors.textDark,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Your safety and comfort are our top priorities.',
                          textAlign: TextAlign.center,
                          style: GoogleFonts.poppins(
                            fontSize: 12,
                            color: AppColors.greySecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 40),
                  Text(
                    '© 2026 Planymo. All rights reserved.',
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: AppColors.greySecondary.withOpacity(0.6),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 120),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickActionChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _QuickActionChip({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 14),
        decoration: BoxDecoration(
          color: AppColors.primaryBlue.withOpacity(0.07),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.primaryBlue.withOpacity(0.15)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: AppColors.primaryBlue, size: 18),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                label,
                style: GoogleFonts.poppins(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: AppColors.primaryBlue,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
