import 'package:code/core/themes/app_colors.dart';
import 'package:code/features/discovery/presentation/providers/discovery_provider.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class PopularDestinationsSlider extends ConsumerWidget {
  const PopularDestinationsSlider({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    final destinationsAsync = ref.watch(destinationsProvider);

    return destinationsAsync.when(
      loading: () => const SizedBox(
        height: 120,
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (_, __) => const SizedBox(),
      data: (destinations) {
        if (destinations.isEmpty) return const SizedBox();
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: Text(
                'Popular Destinations',
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: isDarkMode ? AppColors.textLight : AppColors.textDark,
                ),
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 120,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 24),
                itemCount: destinations.length,
                itemBuilder: (context, index) {
                  final destination = destinations[index];
                  return Padding(
                    padding: const EdgeInsets.only(right: 20),
                    child: Column(
                      children: [
                        Container(
                          width: 70,
                          height: 70,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            image: DecorationImage(
                              image: NetworkImage(destination.imageUrl),
                              fit: BoxFit.cover,
                            ),
                            border: Border.all(
                              color: AppColors.primaryBlue.withOpacity(0.2),
                              width: 2,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          destination.name,
                          style: GoogleFonts.poppins(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            color: isDarkMode
                                ? AppColors.textLight
                                : AppColors.textDark,
                          ),
                        ),
                        Text(
                          destination.tripCount,
                          style: GoogleFonts.poppins(
                            fontSize: 10,
                            color: AppColors.greySecondary,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}
