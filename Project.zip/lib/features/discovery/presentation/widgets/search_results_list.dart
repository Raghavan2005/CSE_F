import 'package:code/core/themes/app_colors.dart';
import 'package:code/core/widgets/trip_card.dart';
import 'package:code/features/discovery/presentation/providers/discovery_provider.dart';
import 'package:code/features/discovery/presentation/providers/wishlist_provider.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class SearchResultsList extends ConsumerWidget {
  final String searchQuery;
  final VoidCallback onClear;
  final Function(String id) onTripTap;

  const SearchResultsList({
    super.key,
    required this.searchQuery,
    required this.onClear,
    required this.onTripTap,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    final packagesAsync = ref.watch(packagesProvider);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Search Results',
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: isDarkMode ? AppColors.textLight : AppColors.textDark,
              ),
            ),
            TextButton(
              onPressed: onClear,
              child: Text(
                'Clear',
                style: GoogleFonts.poppins(
                  color: AppColors.actionOrange,
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        packagesAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (_, __) => const Center(child: Text('Failed to load packages')),
          data: (trips) {
            final results = trips.where((trip) {
              final query = searchQuery.toLowerCase();
              return trip.title.toLowerCase().contains(query) ||
                  trip.location.toLowerCase().contains(query);
            }).toList();

            if (results.isEmpty) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 40),
                  child: Column(
                    children: [
                      Icon(
                        Icons.search_off_rounded,
                        size: 64,
                        color: AppColors.greySecondary.withOpacity(0.5),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'No search result',
                        style: GoogleFonts.poppins(
                          color: AppColors.greySecondary,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }

            return Column(
              children: results.map((trip) {
                final isFavorite =
                    ref.watch(wishlistProvider).any((t) => t.id == trip.id);
                return Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: TripCard(
                    title: trip.title,
                    location: trip.location,
                    price: trip.price,
                    rating: trip.rating,
                    imageUrl: trip.imageUrl,
                    isFavorite: isFavorite,
                    onTap: () => onTripTap(trip.id),
                    onFavoriteTap: () =>
                        ref.read(wishlistProvider.notifier).toggleWishlist(trip),
                  ),
                );
              }).toList(),
            );
          },
        ),
      ],
    );
  }
}
