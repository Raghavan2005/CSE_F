import 'package:code/core/providers/theme_provider.dart';
import 'package:code/core/themes/app_colors.dart';
import 'package:code/features/discovery/presentation/providers/discovery_provider.dart';
import 'package:code/features/discovery/presentation/widgets/home_banner_slider.dart';
import 'package:code/features/discovery/presentation/widgets/search_header.dart';
import 'package:code/features/discovery/presentation/widgets/search_results_list.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class SearchTab extends HookConsumerWidget {
  const SearchTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final searchController = useTextEditingController();
    final searchQuery = useState('');
    final isDarkMode = ref.watch(themeProvider) == ThemeMode.dark;
    final adultCount = useState(0);
    final childrenCount = useState(0);
    final infantCount = useState(0);

    return Scaffold(
      backgroundColor: isDarkMode
          ? AppColors.backgroundDark
          : AppColors.backgroundLight,
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Modular Redbus-style Header
            SearchHeader(
              controller: searchController,
              onSubmitted: (value) => searchQuery.value = value,
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Travel Dates
                  _buildSectionTitle('Travel Dates', isDarkMode),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: isDarkMode ? AppColors.cardDark : Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.03),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: _buildDateField('Start Date', isDarkMode),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: _buildDateField('End Date', isDarkMode),
                        ),
                        const SizedBox(width: 8),
                        const Icon(
                          Icons.calendar_today_rounded,
                          color: AppColors.actionOrange,
                          size: 20,
                        ),
                      ],
                    ),
                  ),

                  // Travelers
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildSectionTitle('Number of Travelers', isDarkMode),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.primaryBlue,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '${adultCount.value + childrenCount.value + infantCount.value}'
                              .padLeft(2, '0'),
                          style: GoogleFonts.poppins(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 11,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: _buildCounter('Adult', adultCount, isDarkMode),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: _buildCounter(
                          'Children',
                          childrenCount,
                          isDarkMode,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: _buildCounter('Infant', infantCount, isDarkMode),
                      ),
                    ],
                  ),

                  const SizedBox(height: 18),

                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        searchQuery.value = searchController.text;
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.actionOrange,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        elevation: 0,
                      ),
                      child: Text(
                        'Let’s Explore',
                        style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 28),

                  // Content based on search state
                  if (searchQuery.value.isEmpty) ...[
                    const SizedBox(height: 40),
                    // Home-style Banner Slider
                    ref.watch(bannersProvider).when(
                      data: (banners) => banners.isEmpty
                          ? const SizedBox()
                          : HomeBannerSlider(banners: banners),
                      loading: () => const SizedBox(
                        height: 200,
                        child: Center(child: CircularProgressIndicator()),
                      ),
                      error: (_, __) => const SizedBox(),
                    ),
                  ] else ...[
                    // Modular Search Results List
                    SearchResultsList(
                      searchQuery: searchQuery.value,
                      onClear: () {
                        searchQuery.value = '';
                        searchController.clear();
                      },
                      onTripTap: (id) => context.push('/trip-details/$id'),
                    ),
                  ],
                  const SizedBox(height: 32),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCounter(
    String label,
    ValueNotifier<int> counter,
    bool isDarkMode,
  ) {
    return Column(
      children: [
        Text(
          label,
          style: GoogleFonts.poppins(
            fontSize: 12,
            color: AppColors.greySecondary,
          ),
        ),
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: isDarkMode ? AppColors.backgroundDark : Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.primaryBlue.withOpacity(0.1)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              InkWell(
                onTap: () => counter.value > 0 ? counter.value-- : null,
                borderRadius: BorderRadius.circular(20),
                child: Padding(
                  padding: const EdgeInsets.all(4),
                  child: Icon(
                    Icons.remove_circle_outline_rounded,
                    size: 18,
                    color: AppColors.greySecondary.withOpacity(0.5),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(
                  '${counter.value}',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
              ),
              InkWell(
                onTap: () => counter.value++,
                borderRadius: BorderRadius.circular(20),
                child: const Padding(
                  padding: EdgeInsets.all(4),
                  child: Icon(
                    Icons.add_circle_outline_rounded,
                    size: 18,
                    color: AppColors.primaryBlue,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDateField(String hint, bool isDarkMode) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.primaryBlue.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.primaryBlue.withOpacity(0.2)),
      ),
      child: Text(
        hint,
        style: GoogleFonts.poppins(
          fontSize: 13,
          color: AppColors.greySecondary,
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title, bool isDarkMode) {
    return Text(
      title,
      style: GoogleFonts.poppins(
        fontSize: 14,
        fontWeight: FontWeight.w600,
        color: isDarkMode ? AppColors.textLight : Colors.grey.shade700,
      ),
    );
  }
}
