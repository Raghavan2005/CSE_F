import 'package:code/core/themes/app_colors.dart';
import 'package:code/core/widgets/trip_card.dart';
import 'package:code/features/discovery/presentation/providers/discovery_provider.dart';
import 'package:code/features/discovery/presentation/providers/wishlist_provider.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class TrendingNowSlider extends ConsumerWidget {
  final String selectedCategory;
  final String searchQuery;

  const TrendingNowSlider({
    super.key,
    required this.selectedCategory,
    required this.searchQuery,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    final packagesAsync = ref.watch(packagesProvider);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Trending Now',
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: isDarkMode ? AppColors.textLight : AppColors.textDark,
                ),
              ),
              TextButton(
                onPressed: () {},
                child: Text(
                  'See All',
                  style: GoogleFonts.poppins(color: AppColors.primaryBlue),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        packagesAsync.when(
          loading: () => const SizedBox(
            height: 320,
            child: Center(child: CircularProgressIndicator()),
          ),
          error: (_, __) => const SizedBox(
            height: 100,
            child: Center(child: Text('Failed to load packages')),
          ),
          data: (trips) {
            final filtered = trips.where((t) {
              final matchesCategory =
                  selectedCategory == 'All' || t.location.toLowerCase().contains(selectedCategory.toLowerCase());
              final matchesSearch = searchQuery.isEmpty ||
                  t.title.toLowerCase().contains(searchQuery.toLowerCase()) ||
                  t.location.toLowerCase().contains(searchQuery.toLowerCase());
              return matchesCategory && matchesSearch;
            }).take(5).toList();

            if (filtered.isEmpty) {
              return const SizedBox(
                height: 100,
                child: Center(child: Text('No packages found')),
              );
            }

            return SizedBox(
              height: 320,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 24),
                itemCount: filtered.length,
                itemBuilder: (context, index) {
                  final trip = filtered[index];
                  final isFavorite =
                      ref.watch(wishlistProvider).any((t) => t.id == trip.id);

                  return Padding(
                    padding: const EdgeInsets.only(right: 20),
                    child: TripCard(
                      title: trip.title,
                      location: trip.location,
                      price: trip.price,
                      rating: trip.rating,
                      imageUrl: trip.imageUrl,
                      isFavorite: isFavorite,
                      onTap: () => context.push('/trip-details/${trip.id}'),
                      onFavoriteTap: () =>
                          ref.read(wishlistProvider.notifier).toggleWishlist(trip),
                    ),
                  );
                },
              ),
            );
          },
        ),
      ],
    );
  }
}
