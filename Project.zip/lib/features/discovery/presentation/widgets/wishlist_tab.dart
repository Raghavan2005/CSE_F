import 'package:code/core/providers/theme_provider.dart';
import 'package:code/core/themes/app_colors.dart';
import 'package:code/core/widgets/trip_card.dart';
import 'package:code/features/discovery/presentation/providers/wishlist_provider.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class WishlistTab extends ConsumerWidget {
  const WishlistTab({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final wishlist = ref.watch(wishlistProvider);
    final isDarkMode = ref.watch(themeProvider) == ThemeMode.dark;

    return Scaffold(
      backgroundColor: isDarkMode
          ? AppColors.backgroundDark
          : AppColors.backgroundLight,
      appBar: AppBar(
        title: Text(
          'Saved Trips',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: isDarkMode ? AppColors.textLight : AppColors.textDark,
          ),
        ),
        backgroundColor: isDarkMode ? AppColors.backgroundDark : Colors.white,
        elevation: 0,
      ),
      body: wishlist.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.favorite_border_rounded,
                    size: 80,
                    color: AppColors.greySecondary.withAlpha(50),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Your wishlist is empty',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      color: AppColors.greySecondary,
                    ),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(24),
              itemCount: wishlist.length,
              itemBuilder: (context, index) {
                final trip = wishlist[index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 20),
                  child: TripCard(
                    title: trip.title,
                    location: trip.location,
                    price: trip.price,
                    rating: trip.rating,
                    imageUrl: trip.imageUrl,
                    isFavorite: true,
                    onTap: () => context.push('/trip-details/${trip.id}'),
                    onFavoriteTap: () => ref
                        .read(wishlistProvider.notifier)
                        .toggleWishlist(trip),
                  ),
                );
              },
            ),
    );
  }
}
