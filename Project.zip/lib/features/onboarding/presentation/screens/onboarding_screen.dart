import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../core/themes/app_colors.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../auth/presentation/providers/auth_provider.dart';

class OnboardingData {
  final String title;
  final String description;
  final IconData icon;

  OnboardingData({
    required this.title,
    required this.description,
    required this.icon,
  });
}

class OnboardingScreen extends HookConsumerWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final pageController = usePageController();
    final currentPage = useState(0);

    final onboardingPages = [
      OnboardingData(
        title: 'Book curated trips in minutes',
        description:
            'Get personalized travel plans designed just for you by our expert assistants.',
        icon: Icons.travel_explore_rounded,
      ),
      OnboardingData(
        title: 'Verified agents. Real reviews.',
        description:
            'Access a network of verified travel agencies with transparent traveler feedback.',
        icon: Icons.verified_user_rounded,
      ),
      OnboardingData(
        title: 'Designed for Gen Z, Couples & Families',
        description:
            'Whether you are traveling solo or with loved ones, we have the perfect plan.',
        icon: Icons.family_restroom_rounded,
      ),
    ];

    void onNext() {
      if (currentPage.value < onboardingPages.length - 1) {
        pageController.nextPage(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
        );
      } else {
        ref.read(authProvider.notifier).completeOnboarding();
        context.go('/auth/login');
      }
    }

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.topRight,
              child: TextButton(
                onPressed: () => context.go('/'),
                child: Text(
                  'Skip',
                  style: GoogleFonts.poppins(
                    color: AppColors.greySecondary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: pageController,
                onPageChanged: (index) => currentPage.value = index,
                itemCount: onboardingPages.length,
                itemBuilder: (context, index) {
                  final data = onboardingPages[index];
                  return Padding(
                    padding: const EdgeInsets.all(40.0),
                    child: Center(
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                                  data.icon,
                                  size: 150,
                                  color: AppColors.primaryBlue,
                                )
                                .animate()
                                .scale(
                                  duration: const Duration(milliseconds: 500),
                                  curve: Curves.easeOutBack,
                                )
                                .fadeIn(),
                            const SizedBox(height: 60),
                            Text(
                                  data.title,
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.poppins(
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                    color: AppColors.textDark,
                                  ),
                                )
                                .animate()
                                .fadeIn(
                                  delay: const Duration(milliseconds: 200),
                                )
                                .slideY(begin: 0.2),
                            const SizedBox(height: 16),
                            Text(
                                  data.description,
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.poppins(
                                    fontSize: 16,
                                    color: AppColors.greySecondary,
                                  ),
                                )
                                .animate()
                                .fadeIn(
                                  delay: const Duration(milliseconds: 400),
                                )
                                .slideY(begin: 0.2),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      onboardingPages.length,
                      (index) => AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        margin: const EdgeInsets.only(right: 8),
                        height: 8,
                        width: currentPage.value == index ? 24 : 8,
                        decoration: BoxDecoration(
                          color: currentPage.value == index
                              ? AppColors.actionOrange
                              : Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 40),
                  AppButton(
                    text: currentPage.value == onboardingPages.length - 1
                        ? "Let's begin the journey →"
                        : 'Next',
                    onPressed: onNext,
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
