import '../../../../core/services/api_service.dart';

class ProfileDataSource {
  ProfileDataSource();

  Future<void> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    await ApiService.dio.post(
      '/auth/user/change-password/',
      data: {'current_password': currentPassword, 'new_password': newPassword},
    );
  }

  Future<Map<String, dynamic>> getProfile() async {
    final response = await ApiService.dio.get('/auth/user/profile/');
    return response.data;
  }

  Future<Map<String, dynamic>> updateProfile(Map<String, dynamic> data) async {
    final response = await ApiService.dio.put(
      '/auth/user/profile/update/',
      data: data,
    );
    return response.data;
  }

  Future<Map<String, dynamic>> rateUser(String userId, double score) async {
    final response = await ApiService.dio.post(
      '/auth/user/$userId/rate/',
      data: {'score': score},
    );
    return response.data;
  }
}
