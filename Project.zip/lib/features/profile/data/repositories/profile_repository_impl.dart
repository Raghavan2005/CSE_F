import '../../../../core/services/storage_service.dart';
import '../../domain/entities/user_profile.dart';
import '../data_sources/profile_data_source.dart';

class ProfileRepositoryImpl {
  final ProfileDataSource dataSource;

  ProfileRepositoryImpl(this.dataSource);

  Future<void> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    await dataSource.changePassword(
      currentPassword: currentPassword,
      newPassword: newPassword,
    );
    // All sessions revoked on password change
    await StorageService.clearTokens();
  }

  Future<void> rateUser(String userId, double score) async {
    await dataSource.rateUser(userId, score);
  }

  Future<UserProfile> getProfile() async {
    final data = await dataSource.getProfile();
    final profile = UserProfile.fromJson(data);
    await StorageService.saveUser(profile);
    return profile;
  }

  Future<UserProfile> updateProfile({
    String? name,
    String? email,
    String? phone,
  }) async {
    final updateData = <String, dynamic>{};
    if (name != null) updateData['name'] = name;
    if (email != null) updateData['email'] = email;

    final data = await dataSource.updateProfile(updateData);
    final profile = UserProfile.fromJson(data);
    await StorageService.saveUser(profile);
    return profile;
  }
}
