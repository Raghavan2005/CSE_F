class UserProfile {
  final String? userId;
  final String name;
  final String? email;
  final String phone;
  final String? profileImageUrl;

  UserProfile({
    this.userId,
    required this.name,
    this.email,
    required this.phone,
    this.profileImageUrl,
  });

  UserProfile copyWith({
    String? userId,
    String? name,
    String? email,
    String? phone,
    String? profileImageUrl,
  }) {
    return UserProfile(
      userId: userId ?? this.userId,
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      profileImageUrl: profileImageUrl ?? this.profileImageUrl,
    );
  }

  Map<String, dynamic> toJson() => {
        'userId': userId,
        'name': name,
        'email': email,
        'phone': phone,
        'profileImageUrl': profileImageUrl,
      };

  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
        userId: json['userId'] ?? json['user_id']?.toString() ?? json['id']?.toString(),
        name: json['name'],
        email: json['email'],
        phone: json['phone'],
        profileImageUrl: json['profileImageUrl'],
      );
}
