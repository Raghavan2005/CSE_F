import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/data_sources/profile_data_source.dart';
import '../../data/repositories/profile_repository_impl.dart';

final profileDataSourceProvider = Provider<ProfileDataSource>((ref) {
  return ProfileDataSource();
});

final profileRepositoryProvider = Provider<ProfileRepositoryImpl>((ref) {
  final dataSource = ref.watch(profileDataSourceProvider);
  return ProfileRepositoryImpl(dataSource);
});
