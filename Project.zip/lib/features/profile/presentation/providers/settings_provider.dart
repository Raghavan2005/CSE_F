import 'package:hooks_riverpod/hooks_riverpod.dart';

final settingsProvider = StateNotifierProvider<SettingsNotifier, SettingsState>(
  (ref) {
    return SettingsNotifier();
  },
);

class SettingsNotifier extends StateNotifier<SettingsState> {
  SettingsNotifier()
    : super(
        SettingsState(
          language: 'English',
          currency: 'USD (\$)',
          notificationsEnabled: true,
        ),
      );

  void setCurrency(String currency) {
    state = state.copyWith(currency: currency);
  }

  void setLanguage(String language) {
    state = state.copyWith(language: language);
  }

  void toggleNotifications() {
    state = state.copyWith(notificationsEnabled: !state.notificationsEnabled);
  }
}

class SettingsState {
  final String language;
  final String currency;
  final bool notificationsEnabled;

  SettingsState({
    required this.language,
    required this.currency,
    required this.notificationsEnabled,
  });

  SettingsState copyWith({
    String? language,
    String? currency,
    bool? notificationsEnabled,
  }) {
    return SettingsState(
      language: language ?? this.language,
      currency: currency ?? this.currency,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
    );
  }
}
