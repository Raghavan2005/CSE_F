import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/services/api_service.dart';
import '../../../../core/services/storage_service.dart';
import '../../domain/entities/user_profile.dart';

import '../../data/repositories/profile_repository_impl.dart';
import 'profile_providers.dart';

class ProfileState {
  final UserProfile user;
  final bool isLoading;
  final String? errorMessage;

  ProfileState({
    required this.user,
    this.isLoading = false,
    this.errorMessage,
  });

  ProfileState copyWith({
    UserProfile? user,
    bool? isLoading,
    String? errorMessage,
  }) {
    return ProfileState(
      user: user ?? this.user,
      isLoading: isLoading ?? this.isLoading,
      errorMessage: errorMessage,
    );
  }
}

final userProvider = StateNotifierProvider<UserNotifier, ProfileState>((ref) {
  final repository = ref.watch(profileRepositoryProvider);
  return UserNotifier(repository);
});

class UserNotifier extends StateNotifier<ProfileState> {
  final ProfileRepositoryImpl _repository;

  UserNotifier(this._repository)
    : super(ProfileState(user: UserProfile(name: '', email: '', phone: ''))) {
    _loadUser();
  }

  Future<void> refreshProfile() async {
    await _loadUser(isRefreshing: true);
  }

  Future<bool> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    try {
      await _repository.changePassword(
        currentPassword: currentPassword,
        newPassword: newPassword,
      );
      await StorageService.clearTokens();
      return true;
    } catch (e) {
      rethrow;
    }
  }

  Future<void> updateProfile({
    String? name,
    String? email,
    String? phone,
  }) async {
    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      final updatedUser = await _repository.updateProfile(
        name: name,
        email: email,
        phone: phone,
      );
      state = state.copyWith(user: updatedUser, isLoading: false);
    } on DioException catch (e) {
      print('USER_DEBUG: Dio error updating profile: ${e.response?.data}');
      state = state.copyWith(
        isLoading: false,
        errorMessage: ApiService.extractError(e.response?.data),
      );
    } catch (e) {
      print('USER_DEBUG: Unexpected error updating profile: $e');
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Failed to update profile.',
      );
    }
  }

  Future<void> _loadUser({bool isRefreshing = false}) async {
    if (!isRefreshing) {
      // First try to load from local storage
      final localUser = await StorageService.loadUser();
      if (localUser != null) {
        state = state.copyWith(user: localUser);
      }
    }

    state = state.copyWith(isLoading: true, errorMessage: null);
    try {
      final remoteUser = await _repository.getProfile();
      print('USER_DEBUG: Remote profile fetched: ${remoteUser.toJson()}');
      state = state.copyWith(user: remoteUser, isLoading: false);
    } on DioException catch (e) {
      print('USER_DEBUG: Dio error loading profile: ${e.response?.data}');
      state = state.copyWith(
        isLoading: false,
        errorMessage: ApiService.extractError(e.response?.data),
      );
    } catch (e) {
      print('USER_DEBUG: Unexpected error loading profile: $e');
      state = state.copyWith(
        isLoading: false,
        errorMessage: 'Failed to fetch remote profile.',
      );
    }
  }
}
