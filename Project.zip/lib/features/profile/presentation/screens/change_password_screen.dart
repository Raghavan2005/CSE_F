import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../core/services/api_service.dart';
import '../../../../core/themes/app_colors.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../auth/auth.dart';
import '../providers/user_provider.dart';

class ChangePasswordScreen extends HookConsumerWidget {
  const ChangePasswordScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final formKey = useMemoized(() => GlobalKey<FormState>());
    final currentPasswordController = useTextEditingController();
    final newPasswordController = useTextEditingController();
    final confirmPasswordController = useTextEditingController();
    final isLoading = useState(false);
    final errorMessage = useState<String?>(null);

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: Text(
          'Change Password',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: AppColors.textDark,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppColors.textDark),
          onPressed: () => context.pop(),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Security',
                style: GoogleFonts.poppins(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: AppColors.greySecondary,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Changing your password will log you out from all active sessions.',
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  color: AppColors.greySecondary,
                ),
              ),
               const SizedBox(height: 32),
              if (errorMessage.value != null)
                Container(
                  padding: const EdgeInsets.all(12),
                  margin: const EdgeInsets.only(bottom: 24),
                  decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.red.shade200),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.error_outline, color: Colors.red),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          errorMessage.value!,
                          style: GoogleFonts.poppins(
                            color: Colors.red.shade700,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              Form(
                key: formKey,
                child: Column(
                  children: [
                    AppTextField(
                      controller: currentPasswordController,
                      label: 'Current Password',
                      hint: 'Enter your old password',
                      isPassword: true,
                      prefixIcon: Icons.lock_outline_rounded,
                    ),
                    const SizedBox(height: 20),
                    AppTextField(
                      controller: newPasswordController,
                      label: 'New Password',
                      hint: 'At least 8 chars, 1 uppercase, 1 digit',
                      isPassword: true,
                      prefixIcon: Icons.lock_reset_rounded,
                      validator: AuthValidator.validatePassword,
                    ),
                    const SizedBox(height: 20),
                    AppTextField(
                      controller: confirmPasswordController,
                      label: 'Confirm New Password',
                      hint: 'Repeat your new password',
                      isPassword: true,
                      prefixIcon: Icons.lock_reset_rounded,
                      validator: (val) => AuthValidator.validateConfirmPassword(
                        val,
                        newPasswordController.text,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 40),
               AppButton(
                text: 'Update Password',
                isLoading: isLoading.value,
                onPressed: () async {
                  if (formKey.currentState?.validate() ?? false) {
                    errorMessage.value = null;
                    isLoading.value = true;
                    try {
                      final success = await ref
                          .read(userProvider.notifier)
                          .changePassword(
                            currentPassword: currentPasswordController.text,
                            newPassword: newPasswordController.text,
                          );
                      if (success && context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text(
                              'Password updated. Please login again.',
                            ),
                            backgroundColor: Colors.green,
                          ),
                        );
                        context.go('/auth/login');
                      }
                    } on DioException catch (e) {
                      errorMessage.value = ApiService.extractError(e.response?.data);
                    } catch (e) {
                      errorMessage.value = 'Failed to update password.';
                    } finally {
                      isLoading.value = false;
                    }
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
