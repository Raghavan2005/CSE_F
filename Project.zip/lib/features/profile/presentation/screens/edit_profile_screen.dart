import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../../../../core/services/api_service.dart';
import '../../../../core/themes/app_colors.dart';
import '../../../../core/widgets/app_button.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../auth/auth.dart';
import '../providers/user_provider.dart';

class EditProfileScreen extends HookConsumerWidget {
  const EditProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final formKey = useMemoized(() => GlobalKey<FormState>());
    final profileState = ref.watch(userProvider);
    final user = profileState.user;
    final nameController = useTextEditingController(text: user.name);
    final phoneController = useTextEditingController(text: user.phone);
    final emailController = useTextEditingController(text: user.email ?? '');
    final isLoading = useState(false);
    final errorMessage = useState<String?>(null);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(
          'Edit Profile',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: AppColors.textDark,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            color: AppColors.textDark,
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Center(
              child: Stack(
                children: [
                  Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      color: AppColors.primaryBlue.withValues(alpha: 0.1),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: AppColors.primaryBlue,
                        width: 2,
                      ),
                    ),
                    child: const Icon(
                      Icons.person_rounded,
                      size: 70,
                      color: AppColors.primaryBlue,
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: const BoxDecoration(
                        color: AppColors.actionOrange,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.camera_alt_rounded,
                        color: Colors.white,
                        size: 18,
                      ),
                    ),
                  ),
                ],
              ),
            ),
             const SizedBox(height: 40),
            if (errorMessage.value != null)
              Container(
                padding: const EdgeInsets.all(12),
                margin: const EdgeInsets.only(bottom: 24),
                decoration: BoxDecoration(
                  color: Colors.red.shade50,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.red.shade200),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.error_outline, color: Colors.red),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        errorMessage.value!,
                        style: GoogleFonts.poppins(
                          color: Colors.red.shade700,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            Form(
              key: formKey,
              child: Column(
                children: [
                  AppTextField(
                    label: 'Full Name',
                    hint: 'John Doe',
                    controller: nameController,
                    validator: AuthValidator.validateName,
                  ),
                  const SizedBox(height: 20),
                  AppTextField(
                    label: 'Mobile Number',
                    hint: '10 digit number',
                    controller: phoneController,
                    enabled: false, // Phone usually not editable without OTP verification
                    prefixIcon: Icons.phone_android_rounded,
                  ),
                  const SizedBox(height: 20),
                  AppTextField(
                    label: 'Email Address',
                    hint: 'john.doe@example.com',
                    controller: emailController,
                    validator: AuthValidator.validateEmail,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
             AppButton(
              text: 'Save Changes',
              isLoading: isLoading.value,
              onPressed: () async {
                if (formKey.currentState?.validate() ?? false) {
                  errorMessage.value = null;
                  isLoading.value = true;
                  try {
                    await ref.read(userProvider.notifier).updateProfile(
                          name: nameController.text,
                          email: emailController.text,
                        );
                    if (context.mounted) {
                      Navigator.pop(context);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                            'Profile updated successfully!',
                            style: GoogleFonts.poppins(),
                          ),
                          backgroundColor: Colors.green,
                        ),
                      );
                    }
                  } on DioException catch (e) {
                    errorMessage.value =
                        ApiService.extractError(e.response?.data);
                  } catch (e) {
                    errorMessage.value = 'Failed to update profile.';
                  } finally {
                    isLoading.value = false;
                  }
                }
              },
            ),
            const SizedBox(height: 24),
            TextButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text(
                      'Deactivate Account',
                      style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
                    ),
                    content: Text(
                      'Are you sure you want to deactivate your account? This will log you out and set your account as inactive.',
                      style: GoogleFonts.poppins(),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text(
                          'Cancel',
                          style: GoogleFonts.poppins(color: AppColors.greySecondary),
                        ),
                      ),
                      TextButton(
                        onPressed: () async {
                          Navigator.pop(context);
                          await ref.read(authProvider.notifier).deactivateAccount();
                          if (context.mounted) {
                            context.go('/auth/login');
                          }
                        },
                        child: Text(
                          'Deactivate',
                          style: GoogleFonts.poppins(color: Colors.red, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                );
              },
              child: Text(
                'Deactivate Account',
                style: GoogleFonts.poppins(
                  color: Colors.red,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
