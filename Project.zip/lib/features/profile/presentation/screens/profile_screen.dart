import 'package:code/core/providers/navigation_provider.dart';
import 'package:code/core/providers/theme_provider.dart';
import 'package:code/core/themes/app_colors.dart';
import 'package:code/core/widgets/settings_list_tile.dart';
import 'package:code/features/auth/presentation/providers/auth_provider.dart';
import 'package:code/features/profile/presentation/providers/settings_provider.dart';
import 'package:code/features/profile/presentation/screens/settings_detail_screen.dart';
import 'package:code/features/profile/presentation/widgets/index.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import '../providers/user_provider.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileState = ref.watch(userProvider);
    final themeMode = ref.watch(themeProvider);
    final isDarkMode = themeMode == ThemeMode.dark;

    return Scaffold(
      backgroundColor: isDarkMode
          ? AppColors.backgroundDark
          : AppColors.backgroundLight,
      appBar: AppBar(
        title: Text(
          'My Profile',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: isDarkMode ? AppColors.textLight : AppColors.textDark,
          ),
        ),
        backgroundColor: isDarkMode ? AppColors.backgroundDark : Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
       body: RefreshIndicator(
        onRefresh: () => ref.read(userProvider.notifier).refreshProfile(),
        color: AppColors.primaryBlue,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            children: [
              if (profileState.isLoading)
                const LinearProgressIndicator(
                  minHeight: 2,
                  backgroundColor: Colors.transparent,
                  valueColor: AlwaysStoppedAnimation<Color>(
                    AppColors.primaryBlue,
                  ),
                ),
              if (profileState.errorMessage != null)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  margin: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 16,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.red.shade200),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.error_outline, color: Colors.red),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          profileState.errorMessage!,
                          style: GoogleFonts.poppins(
                            color: Colors.red.shade700,
                            fontSize: 13,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              const SizedBox(height: 24),
              // Profile Header
              const ProfileHeader(),
            const SizedBox(height: 32),

            // Menu Sections
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ProfileMenuSection(
                    title: 'ACCOUNT',
                    children: [
                      SettingsListTile(
                        icon: Icons.history_rounded,
                        title: 'Booking History',
                        onTap: () {
                          ref.read(navigationProvider.notifier).state = 2;
                        },
                      ),
                      const ProfileSettingsDivider(),
                      SettingsListTile(
                        icon: Icons.favorite_border_rounded,
                        title: 'Saved Trips',
                        onTap: () => context.push('/wishlist'),
                      ),
                      const ProfileSettingsDivider(),
                      SettingsListTile(
                        icon: Icons.payment_rounded,
                        title: 'Payment Methods',
                        onTap: () => _navigateToDetail(
                          context,
                          'Payment Methods',
                          'Securely manage your saved credit cards, digital wallets, and other payment options for faster bookings.',
                        ),
                      ),
                      const ProfileSettingsDivider(),
                      SettingsListTile(
                        icon: Icons.security_rounded,
                        title: 'Account Security',
                        onTap: () => context.push('/change-password'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  ProfileMenuSection(
                    title: 'PREFERENCES',
                    children: [
                      SettingsListTile(
                        icon: isDarkMode
                            ? Icons.dark_mode_rounded
                            : Icons.light_mode_rounded,
                        title: 'Dark Mode',
                        trailing: Switch(
                          value: isDarkMode,
                          onChanged: (value) =>
                              ref.read(themeProvider.notifier).toggleTheme(),
                          activeThumbColor: AppColors.actionOrange,
                          activeTrackColor: AppColors.actionOrange.withValues(
                            alpha: 0.3,
                          ),
                        ),
                        onTap: () =>
                            ref.read(themeProvider.notifier).toggleTheme(),
                      ),
                      const ProfileSettingsDivider(),
                      SettingsListTile(
                        icon: Icons.notifications_active_outlined,
                        title: 'Notifications',
                        trailing: Switch(
                          value: ref
                              .watch(settingsProvider)
                              .notificationsEnabled,
                          onChanged: (value) => ref
                              .read(settingsProvider.notifier)
                              .toggleNotifications(),
                          activeThumbColor: AppColors.actionOrange,
                          activeTrackColor: AppColors.actionOrange.withValues(
                            alpha: 0.3,
                          ),
                        ),
                        onTap: () => ref
                            .read(settingsProvider.notifier)
                            .toggleNotifications(),
                      ),
                      const ProfileSettingsDivider(),
                      SettingsListTile(
                        icon: Icons.language_rounded,
                        title: 'Language',
                        trailing: ProfileMenuSection.buildTrailingText(
                          context,
                          ref.watch(settingsProvider).language,
                        ),
                        onTap: () => _showLanguageDialog(context, ref),
                      ),
                      const ProfileSettingsDivider(),
                      SettingsListTile(
                        icon: Icons.monetization_on_outlined,
                        title: 'Currency',
                        trailing: ProfileMenuSection.buildTrailingText(
                          context,
                          ref.watch(settingsProvider).currency,
                        ),
                        onTap: () => _showCurrencyDialog(context, ref),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  ProfileMenuSection(
                    title: 'SUPPORT & LEGAL',
                    children: [
                      SettingsListTile(
                        icon: Icons.help_outline_rounded,
                        title: 'Help & Support',
                        onTap: () => context.push('/support'),
                      ),
                      const ProfileSettingsDivider(),
                      SettingsListTile(
                        icon: Icons.privacy_tip_outlined,
                        title: 'Privacy Policy',
                        onTap: () => _navigateToDetail(
                          context,
                          'Privacy Policy',
                          'Your privacy is our priority. We are committed to protecting your personal data and being transparent about how we use it.',
                        ),
                      ),
                      const ProfileSettingsDivider(),
                      SettingsListTile(
                        icon: Icons.description_outlined,
                        title: 'Terms of Service',
                        onTap: () => _navigateToDetail(
                          context,
                          'Terms of Service',
                          'By using Planmyo, you agree to our terms. This section outlines the rules and regulations for using our platform.',
                        ),
                      ),
                      const ProfileSettingsDivider(),
                      SettingsListTile(
                        icon: Icons.info_outline_rounded,
                        title: 'About Planmyo',
                        onTap: () => _navigateToDetail(
                          context,
                          'About Planmyo',
                          'Planmyo is your ultimate travel companion. We aim to revolutionize how you discover and book your next adventure.',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 32),

            // Logout Button
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: InkWell(
                onTap: () => _showLogoutDialog(context, ref),
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    vertical: 16,
                    horizontal: 20,
                  ),
                  decoration: BoxDecoration(
                    color: isDarkMode
                        ? Colors.red.withValues(alpha: 0.1)
                        : Colors.red.shade50,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isDarkMode
                          ? Colors.red.withValues(alpha: 0.2)
                          : Colors.red.shade100,
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.logout_rounded,
                        color: isDarkMode
                            ? Colors.redAccent
                            : Colors.red.shade700,
                      ),
                      const SizedBox(width: 16),
                      Text(
                        'Logout Account',
                        style: GoogleFonts.poppins(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: isDarkMode
                              ? Colors.redAccent
                              : Colors.red.shade700,
                        ),
                      ),
                      const Spacer(),
                      Icon(
                        Icons.arrow_forward_ios_rounded,
                        size: 14,
                        color: isDarkMode
                            ? Colors.redAccent.withValues(alpha: 0.5)
                            : Colors.red.shade300,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 32),
            Text(
              'v1.0.0 (BETA)',
              style: GoogleFonts.poppins(
                fontSize: 12,
                color: AppColors.greySecondary,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 60),
          ],
        ),
      ),
    ),
  );
}

  void _navigateToDetail(BuildContext context, String title, String content) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) =>
            SettingsDetailScreen(title: title, content: content),
      ),
    );
  }

  void _showCurrencyDialog(BuildContext context, WidgetRef ref) {
    final currencies = [
      'USD (\$)',
      'EUR (€)',
      'GBP (£)',
      'JPY (¥)',
      'CAD (\$)',
    ];
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Select Currency',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: currencies.length,
            itemBuilder: (context, index) => ListTile(
              title: Text(currencies[index], style: GoogleFonts.poppins()),
              onTap: () {
                ref
                    .read(settingsProvider.notifier)
                    .setCurrency(currencies[index]);
                Navigator.pop(context);
              },
            ),
          ),
        ),
      ),
    );
  }

  void _showLanguageDialog(BuildContext context, WidgetRef ref) {
    final languages = ['English', 'Spanish', 'French', 'German', 'Chinese'];
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Select Language',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: languages.length,
            itemBuilder: (context, index) => ListTile(
              title: Text(languages[index], style: GoogleFonts.poppins()),
              onTap: () {
                ref
                    .read(settingsProvider.notifier)
                    .setLanguage(languages[index]);
                Navigator.pop(context);
              },
            ),
          ),
        ),
      ),
    );
  }

  void _showLogoutDialog(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Logout',
          style: GoogleFonts.poppins(fontWeight: FontWeight.bold),
        ),
        content: Text(
          'Are you sure you want to log out of Planmyo?',
          style: GoogleFonts.poppins(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: GoogleFonts.poppins(color: AppColors.greySecondary),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              ref.read(authProvider.notifier).logout();
              context.go('/auth/login');
            },
            child: Text(
              'Logout',
              style: GoogleFonts.poppins(
                color: Colors.red,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
