import 'package:flutter/material.dart';

class ProfileSettingsDivider extends StatelessWidget {
  const ProfileSettingsDivider({super.key});

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    return Divider(
      height: 1,
      indent: 60,
      endIndent: 16,
      color: isDarkMode ? Colors.white10 : Colors.black.withValues(alpha: 0.05),
    );
  }
}
