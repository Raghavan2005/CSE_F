import 'package:dio/dio.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:code/core/services/storage_service.dart';

class ReviewDataSource {
  static Dio get _dio => Dio(BaseOptions(
        baseUrl: dotenv.get('RATINGS_SERVICE_URL', fallback: 'http://10.0.2.2:8003'),
        connectTimeout: const Duration(seconds: 10),
        receiveTimeout: const Duration(seconds: 10),
      ));

  Future<Options> _userOptions() async {
    final user = await StorageService.loadUser();
    final userId = user?.userId ?? '';
    return Options(headers: {
      'x-user-id': userId,
      'x-user-role': 'user',
    });
  }

  Future<Map<String, dynamic>> createReview({
    required String bookingId,
    required int rating,
    String comment = '',
  }) async {
    final options = await _userOptions();
    final response = await _dio.post(
      '/api/v1/reviews/',
      data: {
        'booking_id': bookingId,
        'rating': rating,
        if (comment.isNotEmpty) 'comment': comment,
      },
      options: options,
    );
    return response.data;
  }

  Future<List<Map<String, dynamic>>> getPackageReviews(String packageId) async {
    final response = await _dio.get(
      '/api/v1/reviews/',
      queryParameters: {'package_id': packageId},
    );
    return List<Map<String, dynamic>>.from(response.data);
  }

  Future<List<Map<String, dynamic>>> listMyReviews() async {
    final options = await _userOptions();
    final response = await _dio.get('/api/v1/reviews/', options: options);
    return List<Map<String, dynamic>>.from(response.data);
  }
}
