import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:code/features/review/data/datasources/review_data_source.dart';
import 'package:code/features/review/domain/entities/review.dart';

class ReviewRepository {
  final ReviewDataSource _dataSource;

  ReviewRepository(this._dataSource);

  Future<Review> createReview({
    required String bookingId,
    required int rating,
    String comment = '',
  }) async {
    final json = await _dataSource.createReview(
      bookingId: bookingId,
      rating: rating,
      comment: comment,
    );
    return Review.fromJson(json);
  }

  Future<List<Review>> getPackageReviews(String packageId) async {
    final list = await _dataSource.getPackageReviews(packageId);
    return list.map((j) => Review.fromJson(j)).toList();
  }

  Future<List<Review>> listMyReviews() async {
    final list = await _dataSource.listMyReviews();
    return list.map((j) => Review.fromJson(j)).toList();
  }
}

final reviewRepositoryProvider = Provider<ReviewRepository>((ref) {
  return ReviewRepository(ReviewDataSource());
});
