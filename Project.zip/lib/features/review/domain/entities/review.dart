class Review {
  final String id;
  final String bookingId;
  final String userId;
  final String vendorId;
  final String packageId;
  final int rating;
  final String comment;
  final String createdAt;

  Review({
    required this.id,
    required this.bookingId,
    required this.userId,
    required this.vendorId,
    required this.packageId,
    required this.rating,
    required this.comment,
    required this.createdAt,
  });

  factory Review.fromJson(Map<String, dynamic> json) => Review(
        id: json['id'].toString(),
        bookingId: json['booking_id'].toString(),
        userId: json['user_id'].toString(),
        vendorId: json['vendor_id']?.toString() ?? '',
        packageId: json['package_id']?.toString() ?? '',
        rating: json['rating'] as int,
        comment: json['comment'] ?? '',
        createdAt: json['created_at']?.toString() ?? '',
      );
}
