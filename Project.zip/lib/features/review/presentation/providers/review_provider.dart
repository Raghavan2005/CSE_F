import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:code/features/review/data/repositories/review_repository.dart';
import 'package:code/features/review/domain/entities/review.dart';

final packageReviewsProvider =
    FutureProvider.family<List<Review>, String>((ref, packageId) async {
  return ref.read(reviewRepositoryProvider).getPackageReviews(packageId);
});

final myReviewsProvider = FutureProvider<List<Review>>((ref) async {
  return ref.read(reviewRepositoryProvider).listMyReviews();
});

final reviewSubmissionProvider =
    StateNotifierProvider<ReviewSubmissionNotifier, AsyncValue<Review?>>((ref) {
  return ReviewSubmissionNotifier(ref.read(reviewRepositoryProvider));
});

class ReviewSubmissionNotifier extends StateNotifier<AsyncValue<Review?>> {
  final ReviewRepository _repository;

  ReviewSubmissionNotifier(this._repository) : super(const AsyncValue.data(null));

  Future<Review?> submit({
    required String bookingId,
    required int rating,
    String comment = '',
  }) async {
    state = const AsyncValue.loading();
    try {
      final review = await _repository.createReview(
        bookingId: bookingId,
        rating: rating,
        comment: comment,
      );
      state = AsyncValue.data(review);
      return review;
    } catch (e, st) {
      state = AsyncValue.error(e, st);
      return null;
    }
  }

  void reset() => state = const AsyncValue.data(null);
}
