import 'package:code/core/themes/app_colors.dart';
import 'package:code/features/review/domain/entities/review.dart';
import 'package:code/features/review/presentation/providers/review_provider.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:intl/intl.dart';

class PackageReviewsList extends ConsumerWidget {
  final String packageId;

  const PackageReviewsList({super.key, required this.packageId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final reviewsAsync = ref.watch(packageReviewsProvider(packageId));

    return reviewsAsync.when(
      loading: () => const Padding(
        padding: EdgeInsets.symmetric(vertical: 24),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (_, __) => const SizedBox.shrink(),
      data: (reviews) {
        if (reviews.isEmpty) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Text(
              'No reviews yet. Be the first!',
              style: GoogleFonts.poppins(
                color: AppColors.greySecondary,
                fontSize: 13,
              ),
            ),
          );
        }
        return Column(
          children: reviews.map((r) => _ReviewTile(review: r)).toList(),
        );
      },
    );
  }
}

class _ReviewTile extends StatelessWidget {
  final Review review;
  const _ReviewTile({required this.review});

  @override
  Widget build(BuildContext context) {
    String formattedDate = review.createdAt;
    try {
      final dt = DateTime.parse(review.createdAt);
      formattedDate = DateFormat('dd MMM yyyy').format(dt);
    } catch (_) {}

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.shade100),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Row(
                children: List.generate(5, (i) => Icon(
                  i < review.rating ? Icons.star_rounded : Icons.star_outline_rounded,
                  color: AppColors.actionOrange,
                  size: 16,
                )),
              ),
              const Spacer(),
              Text(
                formattedDate,
                style: GoogleFonts.poppins(
                  fontSize: 11,
                  color: AppColors.greySecondary,
                ),
              ),
            ],
          ),
          if (review.comment.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(
              review.comment,
              style: GoogleFonts.poppins(
                fontSize: 13,
                color: AppColors.textDark,
                height: 1.5,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
