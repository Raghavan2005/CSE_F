import 'package:code/core/themes/app_colors.dart';
import 'package:code/core/widgets/app_button.dart';
import 'package:code/features/review/presentation/providers/review_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class WriteReviewSheet extends HookConsumerWidget {
  final String bookingId;
  final String packageTitle;
  final VoidCallback onSuccess;

  const WriteReviewSheet({
    super.key,
    required this.bookingId,
    required this.packageTitle,
    required this.onSuccess,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final rating = useState(0);
    final commentController = useTextEditingController();
    final isSubmitting = useState(false);
    final errorMsg = useState<String?>(null);

    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Rate Your Experience',
              style: GoogleFonts.poppins(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: AppColors.textDark,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              packageTitle,
              style: GoogleFonts.poppins(
                fontSize: 13,
                color: AppColors.greySecondary,
              ),
            ),
            const SizedBox(height: 20),
            // Star rating row
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(5, (i) {
                final filled = i < rating.value;
                return GestureDetector(
                  onTap: () => rating.value = i + 1,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    child: Icon(
                      filled ? Icons.star_rounded : Icons.star_outline_rounded,
                      color: AppColors.actionOrange,
                      size: 40,
                    ),
                  ),
                );
              }),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: commentController,
              maxLines: 3,
              decoration: InputDecoration(
                hintText: 'Share your experience (optional)',
                hintStyle: GoogleFonts.poppins(
                  color: AppColors.greySecondary,
                  fontSize: 13,
                ),
                filled: true,
                fillColor: Colors.grey.shade50,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey.shade200),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.grey.shade200),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: AppColors.primaryBlue),
                ),
              ),
            ),
            if (errorMsg.value != null) ...[
              const SizedBox(height: 10),
              Text(
                errorMsg.value!,
                style: GoogleFonts.poppins(color: Colors.red, fontSize: 13),
              ),
            ],
            const SizedBox(height: 20),
            AppButton(
              text: 'Submit Review',
              isLoading: isSubmitting.value,
              onPressed: () async {
                if (isSubmitting.value) return;
                if (rating.value == 0) {
                  errorMsg.value = 'Please select a star rating.';
                  return;
                }
                errorMsg.value = null;
                isSubmitting.value = true;

                final review = await ref
                    .read(reviewSubmissionProvider.notifier)
                    .submit(
                      bookingId: bookingId,
                      rating: rating.value,
                      comment: commentController.text.trim(),
                    );

                isSubmitting.value = false;

                if (review != null && context.mounted) {
                  Navigator.pop(context);
                  onSuccess();
                } else if (context.mounted) {
                  final err = ref.read(reviewSubmissionProvider);
                  errorMsg.value = err.hasError ? 'Failed to submit. Try again.' : null;
                }
              },
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
