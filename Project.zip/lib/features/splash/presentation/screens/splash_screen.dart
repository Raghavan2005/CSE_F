import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/themes/app_colors.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/services/storage_service.dart';

class SplashScreen extends HookWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    useEffect(() {
      Future.delayed(const Duration(seconds: 2), () async {
        if (!context.mounted) return;

        final hasSeenOnboarding = await StorageService.hasSeenOnboarding();
        final accessToken = await StorageService.getAccessToken();

        if (context.mounted) {
          if (!hasSeenOnboarding) {
            context.go('/onboarding');
          } else if (accessToken != null) {
            context.go('/');
          } else {
            context.go('/auth/login');
          }
        }
      });
      return null;
    }, []);

    return Scaffold(
      backgroundColor: AppColors.primaryBlue,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Logo Placeholder
            const Icon(
              Icons.travel_explore,
              size: 100,
              color: Colors.white,
            ),
            const SizedBox(height: 24),
            Text(
              AppConstants.appName,
              style: Theme.of(context).textTheme.displaySmall?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Your Travel, Simplified.',
              style: TextStyle(
                color: Colors.white70,
                fontSize: 16,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
