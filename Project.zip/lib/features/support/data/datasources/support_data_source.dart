import 'package:dio/dio.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:code/core/services/storage_service.dart';

class SupportDataSource {
  static Dio get _dio => Dio(BaseOptions(
        baseUrl: dotenv.get('SUPPORT_SERVICE_URL', fallback: 'http://10.0.2.2:8004'),
        connectTimeout: const Duration(seconds: 10),
        receiveTimeout: const Duration(seconds: 10),
      ));

  Future<Options> _userOptions() async {
    final user = await StorageService.loadUser();
    final userId = user?.userId ?? '';
    return Options(headers: {
      'x-user-id': userId,
      'x-user-role': 'user',
    });
  }

  Future<List<Map<String, dynamic>>> listMyTickets() async {
    final options = await _userOptions();
    final response = await _dio.get('/api/v1/tickets/my/', options: options);
    return List<Map<String, dynamic>>.from(response.data);
  }

  Future<Map<String, dynamic>> getTicket(String ticketId) async {
    final options = await _userOptions();
    final response = await _dio.get('/api/v1/tickets/$ticketId/', options: options);
    return response.data;
  }

  Future<Map<String, dynamic>> createTicket({
    required String bookingId,
    required String subject,
    required String message,
  }) async {
    final options = await _userOptions();
    final response = await _dio.post(
      '/api/v1/tickets/',
      data: {
        'booking_id': bookingId,
        'subject': subject,
        'message': message,
      },
      options: options,
    );
    return response.data;
  }

  Future<void> addResponse(String ticketId, String message) async {
    final options = await _userOptions();
    await _dio.post(
      '/api/v1/tickets/$ticketId/responses/',
      data: {'message': message},
      options: options,
    );
  }
}
