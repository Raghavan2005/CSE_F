import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:code/features/support/data/datasources/support_data_source.dart';
import 'package:code/features/support/domain/entities/support_ticket.dart';

class SupportRepository {
  final SupportDataSource _dataSource;
  SupportRepository(this._dataSource);

  Future<List<SupportTicket>> listMyTickets() async {
    final list = await _dataSource.listMyTickets();
    return list.map((j) => SupportTicket.fromJson(j)).toList();
  }

  Future<SupportTicket> getTicket(String ticketId) async {
    final json = await _dataSource.getTicket(ticketId);
    return SupportTicket.fromJson(json);
  }

  Future<String> createTicket({
    required String bookingId,
    required String subject,
    required String message,
  }) async {
    final json = await _dataSource.createTicket(
      bookingId: bookingId,
      subject: subject,
      message: message,
    );
    return json['ticket_id'].toString();
  }

  Future<void> addResponse(String ticketId, String message) async {
    await _dataSource.addResponse(ticketId, message);
  }
}

final supportRepositoryProvider = Provider<SupportRepository>((ref) {
  return SupportRepository(SupportDataSource());
});
