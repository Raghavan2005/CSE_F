class SupportResponse {
  final String id;
  final String authorId;
  final String authorRole;
  final String message;
  final String createdAt;

  SupportResponse({
    required this.id,
    required this.authorId,
    required this.authorRole,
    required this.message,
    required this.createdAt,
  });

  factory SupportResponse.fromJson(Map<String, dynamic> json) => SupportResponse(
        id: json['id'].toString(),
        authorId: json['author_id'].toString(),
        authorRole: json['author_role'] ?? '',
        message: json['message'] ?? '',
        createdAt: json['created_at']?.toString() ?? '',
      );
}

class SupportTicket {
  final String id;
  final String bookingId;
  final String subject;
  final String message;
  final String status;
  final String createdAt;
  final List<SupportResponse> responses;

  SupportTicket({
    required this.id,
    required this.bookingId,
    required this.subject,
    required this.message,
    required this.status,
    required this.createdAt,
    required this.responses,
  });

  factory SupportTicket.fromJson(Map<String, dynamic> json) => SupportTicket(
        id: json['id'].toString(),
        bookingId: json['booking_id'].toString(),
        subject: json['subject'] ?? '',
        message: json['message'] ?? '',
        status: json['status'] ?? 'open',
        createdAt: json['created_at']?.toString() ?? '',
        responses: (json['responses'] as List<dynamic>? ?? [])
            .map((r) => SupportResponse.fromJson(r as Map<String, dynamic>))
            .toList(),
      );
}
