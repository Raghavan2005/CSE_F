import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:code/features/support/data/repositories/support_repository.dart';
import 'package:code/features/support/domain/entities/support_ticket.dart';

final myTicketsProvider = FutureProvider<List<SupportTicket>>((ref) async {
  return ref.read(supportRepositoryProvider).listMyTickets();
});

final ticketDetailProvider =
    FutureProvider.family<SupportTicket, String>((ref, ticketId) async {
  return ref.read(supportRepositoryProvider).getTicket(ticketId);
});

final ticketCreationProvider =
    StateNotifierProvider<TicketCreationNotifier, AsyncValue<String?>>((ref) {
  return TicketCreationNotifier(ref.read(supportRepositoryProvider));
});

class TicketCreationNotifier extends StateNotifier<AsyncValue<String?>> {
  final SupportRepository _repository;
  TicketCreationNotifier(this._repository) : super(const AsyncValue.data(null));

  Future<String?> create({
    required String bookingId,
    required String subject,
    required String message,
  }) async {
    state = const AsyncValue.loading();
    try {
      final ticketId = await _repository.createTicket(
        bookingId: bookingId,
        subject: subject,
        message: message,
      );
      state = AsyncValue.data(ticketId);
      return ticketId;
    } catch (e, st) {
      state = AsyncValue.error(e, st);
      return null;
    }
  }

  void reset() => state = const AsyncValue.data(null);
}

final ticketReplyProvider =
    StateNotifierProvider<TicketReplyNotifier, AsyncValue<void>>((ref) {
  return TicketReplyNotifier(ref.read(supportRepositoryProvider));
});

class TicketReplyNotifier extends StateNotifier<AsyncValue<void>> {
  final SupportRepository _repository;
  TicketReplyNotifier(this._repository) : super(const AsyncValue.data(null));

  Future<bool> reply(String ticketId, String message) async {
    state = const AsyncValue.loading();
    try {
      await _repository.addResponse(ticketId, message);
      state = const AsyncValue.data(null);
      return true;
    } catch (e, st) {
      state = AsyncValue.error(e, st);
      return false;
    }
  }
}
