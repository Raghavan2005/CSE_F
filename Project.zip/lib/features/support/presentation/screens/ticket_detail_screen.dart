import 'package:code/core/themes/app_colors.dart';
import 'package:code/features/support/domain/entities/support_ticket.dart';
import 'package:code/features/support/presentation/providers/support_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:intl/intl.dart';

class TicketDetailScreen extends HookConsumerWidget {
  final String ticketId;
  const TicketDetailScreen({super.key, required this.ticketId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final ticketAsync = ref.watch(ticketDetailProvider(ticketId));
    final replyController = useTextEditingController();
    final isSending = useState(false);

    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      appBar: AppBar(
        title: Text(
          'Ticket Details',
          style: GoogleFonts.poppins(
            fontWeight: FontWeight.bold,
            color: AppColors.textDark,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: AppColors.textDark),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => ref.invalidate(ticketDetailProvider(ticketId)),
          ),
        ],
      ),
      body: ticketAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(
          child: Text('Failed to load ticket', style: GoogleFonts.poppins()),
        ),
        data: (ticket) => Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _TicketHeader(ticket: ticket),
                  const SizedBox(height: 16),
                  // Original message
                  _MessageBubble(
                    message: ticket.message,
                    isUser: true,
                    time: ticket.createdAt,
                    label: 'You',
                  ),
                  const SizedBox(height: 12),
                  // Responses thread
                  ...ticket.responses.map((r) => Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: _MessageBubble(
                          message: r.message,
                          isUser: r.authorRole == 'user',
                          time: r.createdAt,
                          label: r.authorRole == 'user'
                              ? 'You'
                              : r.authorRole == 'vendor'
                                  ? 'Vendor'
                                  : 'Support',
                        ),
                      )),
                  if (ticket.status == 'resolved' || ticket.status == 'closed')
                    Container(
                      margin: const EdgeInsets.only(top: 8),
                      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                      decoration: BoxDecoration(
                        color: Colors.green.shade50,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.green.shade200),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.check_circle_outline,
                              color: Colors.green, size: 18),
                          const SizedBox(width: 8),
                          Text(
                            'This ticket is ${ticket.status}.',
                            style: GoogleFonts.poppins(
                              fontSize: 13,
                              color: Colors.green.shade700,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            // Reply box — only if ticket is open or in_progress
            if (ticket.status == 'open' || ticket.status == 'in_progress')
              _ReplyBox(
                controller: replyController,
                isSending: isSending.value,
                onSend: () async {
                  final text = replyController.text.trim();
                  if (text.isEmpty) return;
                  isSending.value = true;
                  final ok = await ref
                      .read(ticketReplyProvider.notifier)
                      .reply(ticketId, text);
                  isSending.value = false;
                  if (ok) {
                    replyController.clear();
                    ref.invalidate(ticketDetailProvider(ticketId));
                  } else if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Failed to send reply.')),
                    );
                  }
                },
              ),
          ],
        ),
      ),
    );
  }
}

class _TicketHeader extends StatelessWidget {
  final SupportTicket ticket;
  const _TicketHeader({required this.ticket});

  Color get _statusColor {
    switch (ticket.status) {
      case 'open':
        return AppColors.primaryBlue;
      case 'in_progress':
        return AppColors.actionOrange;
      case 'resolved':
        return Colors.green;
      default:
        return AppColors.greySecondary;
    }
  }

  @override
  Widget build(BuildContext context) {
    String formattedDate = ticket.createdAt;
    try {
      final dt = DateTime.parse(ticket.createdAt);
      formattedDate = DateFormat('dd MMM yyyy, hh:mm a').format(dt);
    } catch (_) {}

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  ticket.subject,
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textDark,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _statusColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  ticket.status.replaceAll('_', ' ').toUpperCase(),
                  style: GoogleFonts.poppins(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: _statusColor,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'Created $formattedDate',
            style: GoogleFonts.poppins(fontSize: 11, color: AppColors.greySecondary),
          ),
        ],
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final String message;
  final bool isUser;
  final String time;
  final String label;

  const _MessageBubble({
    required this.message,
    required this.isUser,
    required this.time,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    String formattedTime = time;
    try {
      final dt = DateTime.parse(time);
      formattedTime = DateFormat('hh:mm a, dd MMM').format(dt);
    } catch (_) {}

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.78,
        ),
        child: Column(
          crossAxisAlignment:
              isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: GoogleFonts.poppins(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: isUser ? AppColors.primaryBlue : AppColors.actionOrange,
              ),
            ),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: isUser ? AppColors.primaryBlue : Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: isUser
                      ? const Radius.circular(16)
                      : const Radius.circular(4),
                  bottomRight: isUser
                      ? const Radius.circular(4)
                      : const Radius.circular(16),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.06),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Text(
                message,
                style: GoogleFonts.poppins(
                  fontSize: 13,
                  color: isUser ? Colors.white : AppColors.textDark,
                  height: 1.5,
                ),
              ),
            ),
            const SizedBox(height: 3),
            Text(
              formattedTime,
              style: GoogleFonts.poppins(
                fontSize: 10,
                color: AppColors.greySecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ReplyBox extends StatelessWidget {
  final TextEditingController controller;
  final bool isSending;
  final VoidCallback onSend;

  const _ReplyBox({
    required this.controller,
    required this.isSending,
    required this.onSend,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        left: 16,
        right: 8,
        top: 12,
        bottom: 12 + MediaQuery.of(context).viewInsets.bottom,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 10,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: controller,
              maxLines: null,
              decoration: InputDecoration(
                hintText: 'Type your reply...',
                hintStyle: GoogleFonts.poppins(
                  color: AppColors.greySecondary,
                  fontSize: 13,
                ),
                filled: true,
                fillColor: Colors.grey.shade50,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          isSending
              ? const Padding(
                  padding: EdgeInsets.all(12),
                  child: SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                )
              : IconButton(
                  onPressed: onSend,
                  icon: const Icon(Icons.send_rounded),
                  color: AppColors.primaryBlue,
                  iconSize: 28,
                ),
        ],
      ),
    );
  }
}
