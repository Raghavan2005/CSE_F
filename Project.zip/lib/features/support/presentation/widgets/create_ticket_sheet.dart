import 'package:code/core/themes/app_colors.dart';
import 'package:code/core/widgets/app_button.dart';
import 'package:code/features/booking/presentation/providers/booking_provider.dart';
import 'package:code/features/support/presentation/providers/support_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class CreateTicketSheet extends HookConsumerWidget {
  final VoidCallback onSuccess;
  const CreateTicketSheet({super.key, required this.onSuccess});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final bookingsAsync = ref.watch(userBookingsProvider);
    final selectedBookingId = useState<String?>(null);
    final subjectController = useTextEditingController();
    final messageController = useTextEditingController();
    final isSubmitting = useState(false);
    final errorMsg = useState<String?>(null);

    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'New Support Ticket',
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textDark,
                ),
              ),
              const SizedBox(height: 20),
              // Booking dropdown
              bookingsAsync.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (_, __) => Text(
                  'Could not load bookings',
                  style: GoogleFonts.poppins(color: Colors.red, fontSize: 13),
                ),
                data: (bookings) {
                  if (bookings.isEmpty) {
                    return Text(
                      'You need an active booking to raise a ticket.',
                      style: GoogleFonts.poppins(
                        color: AppColors.greySecondary,
                        fontSize: 13,
                      ),
                    );
                  }
                  return DropdownButtonFormField<String>(
                    initialValue: selectedBookingId.value,
                    decoration: InputDecoration(
                      labelText: 'Related Booking',
                      labelStyle: GoogleFonts.poppins(
                        fontSize: 13,
                        color: AppColors.greySecondary,
                      ),
                      filled: true,
                      fillColor: Colors.grey.shade50,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.grey.shade200),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.grey.shade200),
                      ),
                    ),
                    hint: Text('Select a booking', style: GoogleFonts.poppins(fontSize: 13)),
                    items: bookings.map((b) => DropdownMenuItem(
                      value: b.bookingId,
                      child: Text(
                        b.packageTitle.isNotEmpty ? b.packageTitle : b.bookingId,
                        style: GoogleFonts.poppins(fontSize: 13),
                        overflow: TextOverflow.ellipsis,
                      ),
                    )).toList(),
                    onChanged: (v) => selectedBookingId.value = v,
                  );
                },
              ),
              const SizedBox(height: 14),
              TextField(
                controller: subjectController,
                decoration: InputDecoration(
                  labelText: 'Subject',
                  labelStyle: GoogleFonts.poppins(
                    fontSize: 13,
                    color: AppColors.greySecondary,
                  ),
                  filled: true,
                  fillColor: Colors.grey.shade50,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: Colors.grey.shade200),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: Colors.grey.shade200),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: AppColors.primaryBlue),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: messageController,
                maxLines: 4,
                decoration: InputDecoration(
                  labelText: 'Message',
                  alignLabelWithHint: true,
                  labelStyle: GoogleFonts.poppins(
                    fontSize: 13,
                    color: AppColors.greySecondary,
                  ),
                  filled: true,
                  fillColor: Colors.grey.shade50,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: Colors.grey.shade200),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: Colors.grey.shade200),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: AppColors.primaryBlue),
                  ),
                ),
              ),
              if (errorMsg.value != null) ...[
                const SizedBox(height: 10),
                Text(
                  errorMsg.value!,
                  style: GoogleFonts.poppins(color: Colors.red, fontSize: 13),
                ),
              ],
              const SizedBox(height: 20),
              AppButton(
                text: 'Submit Ticket',
                isLoading: isSubmitting.value,
                onPressed: () async {
                  if (isSubmitting.value) return;
                  final bookingId = selectedBookingId.value;
                  final subject = subjectController.text.trim();
                  final message = messageController.text.trim();

                  if (bookingId == null) {
                    errorMsg.value = 'Please select a booking.';
                    return;
                  }
                  if (subject.isEmpty) {
                    errorMsg.value = 'Please enter a subject.';
                    return;
                  }
                  if (message.isEmpty) {
                    errorMsg.value = 'Please enter a message.';
                    return;
                  }
                  errorMsg.value = null;
                  isSubmitting.value = true;

                  final ticketId = await ref
                      .read(ticketCreationProvider.notifier)
                      .create(
                        bookingId: bookingId,
                        subject: subject,
                        message: message,
                      );

                  isSubmitting.value = false;

                  if (ticketId != null && context.mounted) {
                    Navigator.pop(context);
                    onSuccess();
                  } else if (context.mounted) {
                    errorMsg.value = 'Failed to create ticket. Please try again.';
                  }
                },
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}
