import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

import 'core/providers/theme_provider.dart';
import 'core/router/app_router.dart';
import 'core/services/api_service.dart';
import 'core/themes/app_theme.dart';
import 'features/auth/presentation/providers/auth_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: ".env");
  runApp(const ProviderScope(child: PlanmyoApp()));
}

class PlanmyoApp extends HookConsumerWidget {
  const PlanmyoApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeProvider);

    // Initialize Global Auth Listener for session expiration
    useEffect(() {
      ApiService.onUnauthorized = () {
        ref.read(authProvider.notifier).forceLogout();
      };
      return null;
    }, []);

    // Listen for auth state changes to force redirect to login on session expiry
    ref.listen(authProvider.select((s) => s.status), (previous, next) {
      if (next == AuthStatus.unauthenticated && previous == AuthStatus.authenticated) {
        appRouter.go('/auth/login');
      }
    });

    return MaterialApp.router(
      title: 'Planmyo',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: themeMode,
      routerConfig: appRouter,
    );
  }
}
