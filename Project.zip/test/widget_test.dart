import 'package:flutter_test/flutter_test.dart';
import 'package:code/main.dart';

void main() {
  testWidgets('App starts and shows Welcome message', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const PlanmyoApp());

    // Verify that the app name is shown.
    expect(find.text('PLANMYO'), findsOneWidget);
    
    // Verify that the welcome message is shown.
    expect(find.text('Welcome to Planmyo'), findsOneWidget);
  });
}
